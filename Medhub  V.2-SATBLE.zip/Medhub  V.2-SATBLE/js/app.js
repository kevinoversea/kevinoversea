/* =============================================================================
   Medhub24 V.2 JavaScript
   Runtime role:
   - Owns SPA navigation, language switching, account journey state, upload/payment demos,
     active pc3 price comparison, profile/review flows, and generated Home detail views.
   - index.html provides stable IDs/classes and inline event hooks for demo speed.
   - css/styles.css consumes state classes such as .active, .open, data-state, and route-specific body classes.

   Backend integration notes:
   - Replace static arrays and demo constants with fetch/service functions in feature-scoped sections.
   - Keep backend responses normalized before rendering into existing DOM anchors.
   - Do not call APIs directly from HTML handlers; handlers should call functions here.

   Main execution order:
   1. Global state/constants/translations
   2. Shared navigation and language utilities
   3. Account/health/payment modules
   4. Active pc3 Price module for #screen-20
   5. Home/detail/appointment/profile/review modules
   6. DOMContentLoaded/load/resize/event synchronization
   ============================================================================= */

// ============= STATE MANAGEMENT =============
let currentLang = 'en';
let isRecording = false;
let isNavigating = false;
let selectedCare = { type: 'standard', price: 30, i18nKey: 'standard_name' };
let agreements = { 7: false, 8: false, 9: false, 10: false, 11: false };
let inquiryPending = false;
let guardianPaymentCompleted = false;
let currentScreen = 1;
let currentJourneyMode = 'match';
let currentAccountStep = 'portfolio';
let accountJourneyFrame = 0;
let matchJourneyTemplate = { rail: '', drawer: '' };
const TELEGRAM_ADMIN_HANDLE = 'medhub24_admin';
const TELEGRAM_PROFILE_URL = `https://t.me/${TELEGRAM_ADMIN_HANDLE}`;
const ABA_PAYMENT_URL = 'https://www.ababank.com/app/';
const ACCOUNT_JOURNEY = [
    {
        key: 'discovery',
        label: 'Account Home',
        count: '3 topics',
        steps: [
            { key: 'portfolio', label: 'Portfolio Home', meta: 'Identity + quick stats' },
            { key: 'coordination', label: 'Active Coordination', meta: 'Tasks + travel progress' },
            { key: 'payments', label: 'Payment Portfolio', meta: 'Spend chain + categories' }
        ]
    },
    {
        key: 'trust',
        label: 'Health Memory',
        count: '1 topic',
        steps: [
            { key: 'year-timeline', label: 'Year Timeline', meta: 'Scores + annual folders' }
        ]
    },
    {
        key: 'commit',
        label: 'AI Tools',
        count: '1 topic',
        steps: [
            { key: 'ai-scan', label: 'AI Health Scan', meta: 'Upload → extract → compare' }
        ]
    }
];
const ACCOUNT_JOURNEY_ORDER = ACCOUNT_JOURNEY.flatMap(phase => phase.steps.map(step => step.key));
const ACCOUNT_JOURNEY_LOOKUP = ACCOUNT_JOURNEY.reduce((lookup, phase) => {
    phase.steps.forEach(step => {
        lookup[step.key] = { ...step, phaseKey: phase.key, phaseLabel: phase.label };
    });
    return lookup;
}, {});
const ACCOUNT_JOURNEY_SCREEN_MAP = { 19: 'year-timeline', 21: 'ai-scan' };
const COORD_PREVIEW_LABELS = {
    en: { preview: 'Preview', unpreview: 'Unpreview' },
    km: { preview: 'មើលជាមុន', unpreview: 'បិទការមើលជាមុន' },
    my: { preview: 'ကြိုကြည့်', unpreview: 'ကြိုကြည့်ပိတ်ရန်' },
    vi: { preview: 'Xem trước', unpreview: 'Ẩn xem trước' },
    zh: { preview: '预览', unpreview: '取消预览' }
};
const translations = {
    en: {
        nav_home: "Home", nav_guardian: "Guardian", nav_dashboard: "My dashboard", nav_promotion: "Promotion",
        welcome_hero: "Healthcare that <em>protects</em> you",
        welcome_hero_em: "protects",
        welcome_sub: "Your independent coordinator for cross-border medical treatment. We work for you, not the hospital.",
        next: "Next",
        voice_title: "Tell us what <em>concerns you</em>",
        voice_title_em: "concerns you",
        voice_sub: "Speak naturally in your own language. Our AI will transcribe and analyze your case. No typing needed.",
        voice_hint: "Tap to start recording",
        voice_hint_recording: "Recording... Tap to stop",
        transcript_label: "AI Transcription",
        retry: "Re-record",
        edit: "Edit Text",
        budget_label: "Budget Range (Optional)",
        timeline_label: "When are you ready for treatment?",
        analyze_btn: "Analyze My Case",
        analyzing_title: "Analyzing<br>your case",
        analyzing_sub: "Cross-referencing with partner hospital data",
        step_voice_received: "Voice input received",
        step_case_categorized: "Case categorized",
        step_matching_db: "Matching with partner database",
        step_price_range: "Estimating price range",
        result_label: "Preliminary Analysis",
        result_title: "Good news — your case <em>is treatable</em>",
        result_title_em: "is treatable",
        result_sub: "Here's an overview. Hospital names and doctor details will be revealed after our video call.",
        diagnosis_label: "Preliminary Assessment",
        diagnosis_desc: "Coronary balloon procedure with stent",
        recommended_country: "Recommended Country",
        thailand_first: "Thailand (Primary)",
        price_range: "Estimated Price Range",
        treatment_duration: "Treatment Duration",
        days_3_5: "3-5 days",
        recovery_time: "Recovery Time",
        weeks_2: "2 weeks",
        disclaimer_title: "About This Estimate",
        disclaimer_text: "This estimate is based on standard procedure data collected from our partner hospitals. <strong>The price does not include complications, special medical tools, or accessories that may be needed during treatment.</strong> Final price is confirmed after in-person evaluation.",
        book_call: "Schedule Video Consultation",
        consult_free: "30-minute video call · No cost",
        no_match_link: "Case doesn't match? Talk directly →",
        booking_label: "Schedule · Level 2",
        book_title: "Choose a time <em>that works</em>",
        book_title_em: "that works",
        book_sub: "Meet your Case Manager via video call to discuss your case in depth.",
        day_tue: "Tue",
        day_wed: "Wed",
        day_thu: "Thu",
        day_fri: "Fri",
        time_label: "Time Slot",
        confirm_time: "Confirm Schedule",
        guardian_label: "Guardian Agreement",
        guardian_title: "Before we<br>work together",
        guardian_sub: "We want you to clearly understand how we work <strong>for you</strong> — and what we ask in return.",
        four_parts: "Four Parts",
        part1_name: "1. Your Rights",
        part1_tag: "As a Patient",
        part2_name: "2. Our Duties",
        part2_tag: "As Your Coordinator",
        part3_name: "3. Working Together",
        part3_tag: "90 Days",
        part4_name: "4. Right to Exit",
        part4_tag: "Anytime",
        important: "Important",
        tap_intro: "No documents. No signatures. Just read each part and tap to agree.",
        start_reading: "Start Reading",
        tap_start_reading: "I am ready to read the agreement",
        tap_to_start: "Tap to begin the guardian intro",
        part_1_of_4: "Part 1 of 4",
        part_2_of_4: "Part 2 of 4",
        part_3_of_4: "Part 3 of 4",
        part_4_of_4: "Part 4 of 4",
        rights_title: "Your Rights<br><em>as a Patient</em>",
        rights_title_em: "as a Patient",
        rights_sub: "We protect these things for you",
        right_1: "<strong>Honest guidance</strong> — We recommend the hospital that fits your case best, not the one that pays us the most.",
        right_2: "<strong>Clear pricing</strong> — You see real prices with no hidden fees. Every dollar is explained.",
        right_3: "<strong>Protection if issues arise</strong> — If a hospital overcharges or treatment deviates from the agreed plan, we advocate for you.",
        right_4: "<strong>After-care support</strong> — 90 days of follow-up, medication coordination, and second opinions when needed.",
        tap_rights: "I understand my rights",
        tap_acknowledge: "Tap to acknowledge",
        duties_title: "Our Duties<br><em>to You</em>",
        duties_title_em: "to You",
        duties_sub: "If we break these, you can leave immediately",
        duty_1: "<strong>Truthful information</strong> — Even when the truth is not what you want to hear. We won't push unnecessary treatment.",
        duty_2: "<strong>Advocate on your behalf</strong> — We use our hospital relationships to secure the best care package for you.",
        duty_3: "<strong>Protect your privacy</strong> — Your medical information stays confidential and is never shared without your consent.",
        duty_4: "<strong>Service guarantee</strong> — If our care support service falls short, we refund the service coordination fee.",
        tap_duties: "Hold us accountable",
        tap_accountable: "We accept responsibility",
        commit_title: "Working Together<br><em>90 Days</em>",
        commit_title_em: "90 Days",
        commit_sub: "What we ask from you so we can do our job well",
        commit_1: "<strong>Work through us for 90 days</strong> — So we can negotiate for you, not against ourselves.",
        commit_2: "<strong>Tell us before deciding</strong> — If you want to switch hospitals or change plans, let us know first. We may have better options.",
        commit_3: "<strong>Accurate medical history</strong> — Correct information helps us recommend the right care.",
        commit_4: "<strong>Honest feedback</strong> — Share your experience afterwards so we can improve.",
        note: "Note:",
        commit_note: "\"90 days\" starts from the day we begin working together, not a lifetime commitment.",
        tap_commit: "I accept this commitment",
        tap_together: "We're in this together",
        exit_title: "Your Right<br><em>to Exit</em>",
        exit_title_em: "to Exit",
        exit_sub: "Most important — you can leave anytime",
        exit_1: "<strong>No cancellation fee</strong> — Exit anytime without any penalty.",
        exit_2: "<strong>Your data belongs to you</strong> — If you cancel, we delete your medical data within 7 days.",
        exit_3: "<strong>Care support deposit refund</strong> — If you cancel before treatment starts, your 10% deposit for our service is fully refundable.",
        exit_4: "<strong>No hospital lock-in</strong> — You can seek treatment elsewhere even after canceling with us.",
        exit_quote: "\"We earn your trust by doing good work — not by locking you in.\"",
        tap_exit: "I understand and agree to all",
        tap_final: "Final acknowledgment",
        confirm_agreement: "Confirm Guardian Agreement",
        welcome_inner: "Welcome to the<br><em>Inner Circle</em>",
        welcome_inner_em: "Inner Circle",
        welcome_inner_sub: "We're now working for you. Full information access unlocked.",
        now_access: "You now have access to",
        access_1: "✓ Hospital names and details",
        access_2: "✓ Negotiated pricing",
        access_3: "✓ Recommended specialists",
        access_4: "✓ Direct Case Manager contact",
        view_hospitals: "View Recommended Hospitals",
        full_disclosure_label: "Full Disclosure · Level 3",
        hospitals_title: "3 Options <em>we recommend</em>",
        hospitals_title_em: "we recommend",
        hospitals_sub: "Based on 15 years of market knowledge. Prices reflect our partner agreements.",
        estimate_note_title: "Price Estimate Note",
        estimate_note_text: "Prices shown are for the standard procedure. <strong>Does not include complications or special medical accessories.</strong> Hospital confirms final pricing after in-person evaluation.",
        recommended_tag: "Recommended",
        alternative_tag: "Alternative",
        budget_tag: "Budget Option",
        partner_price: "Partner Price",
        duration: "Duration",
        days_4: "4 days",
        days_5: "5 days",
        walk_in: "Walk-in",
        select_bumrungrad: "Select Bumrungrad",
        care_level_label: "Care Support Level",
        care_title: "Choose your <em>care support</em>",
        care_title_em: "care support",
        care_sub: "These are care support services. Medical treatment is paid separately to the hospital.",
        basic_name: "Basic Coordination",
        basic_price: "Included",
        basic_f1: "Hospital appointment booking",
        basic_f2: "Hospital staff interpreter (walk-in basis)",
        basic_f3: "Basic pre-trip information",
        standard_name: "Standard Care",
        standard_price: "$30 / day",
        std_f1: "Dedicated interpreter at hospital (8:00 AM – 4:00 PM)",
        std_f2: "Airport transportation (arrival & departure)",
        std_f3: "Hotel booking assistance if needed",
        std_f4: "On-ground coordination during treatment",
        std_f5: "One-time complete care package",
        premium_name: "Advocacy Premium",
        premium_price: "$120 flat",
        prem_f1: "All Standard Care features",
        prem_f2: "90-day post-treatment follow-up",
        prem_f3: "Priority Case Manager access",
        prem_f4: "Second opinion if symptoms arise",
        prem_f5: "Family updates in your language",
        concierge_name: "Full Concierge",
        concierge_price: "$350 flat",
        conc_f1: "All Premium features",
        conc_f2: "Case Manager accompanies you in person",
        conc_f3: "Daily family briefings",
        conc_f4: "6-month extended follow-up",
        confirm_standard: "Confirm Standard Care",
        confirm_booking: "Confirm Booking",
        booking_final_title: "Final step — <em>care deposit only</em>",
        booking_final_em: "care deposit only",
        booking_final_sub: "You only pay a small deposit for our care support service. Medical treatment is paid directly to the hospital on the first day.",
        hospital: "Hospital",
        doctor: "Specialist",
        treatment_date: "Treatment Date",
        may_15_18: "May 15-18, 2026",
        care_package: "Care Support",
        standard_4days: "Standard · 4 days",
        medical_section: "Medical Treatment",
        treatment_fee: "Treatment Package",
        pay_to: "Payment to",
        hospital_direct: "Hospital directly",
        pay_when: "Payment timing",
        first_day: "First day of treatment",
        no_medical_deposit: "✓ No deposit required for medical treatment",
        care_deposit_title: "Care Support Deposit",
        service_total: "Standard Care Total (4 days × $30)",
        deposit_10: "Deposit (10% today)",
        balance_on_day1: "Balance on first treatment day",
        deposit_terms_title: "Deposit Terms",
        term_1: "✓ Deposit applies only to care support service",
        term_2: "✓ Full balance paid on your first treatment day",
        term_3: "✓ If you cancel and cannot attend, deposit is <strong>fully refundable</strong>",
        term_4: "✓ No cancellation fee from our side",
        payment_method: "Payment Method",
        pay_12: "Pay $12 Deposit · Confirm Booking",
        deposit_security: "🔒 Secure payment · Refundable if you cancel",
        greeting: "Hello",
        active_case: "Case #8492 · Active",
        case_title: "Coronary Angioplasty<br>at Bumrungrad",
        case_subtitle: "23 days remaining · May 15-18, 2026",
        view_timeline: "View Timeline",
        chat_cm: "Chat CM",
        prep_docs: "Prepare Documents",
        docs_3_5: "3 of 5 complete",
        travel: "Travel Arrangements",
        airport_pickup: "Airport pickup arranged",
        accommodation: "Accommodation",
        hotel_sukhumvit: "Grand Sukhumvit · 4 nights",
        case_manager: "Case Manager",
        cm_pie: "Mr. Pie · Responds within 2 hours",
        restart: "Restart Demo",
        restart_short: "Restart",
        skip_dashboard: "Skip to Dashboard",
        modal_title: "Please <em>accept</em> first",
        modal_title_em: "accept",
        modal_text: "You need to tap the \"Agree\" box before continuing. This creates clear trust between us and you.",
        understood: "Understood",
        special_case: "Special Case Handling",
        nomatch_title: "Your case needs <em>personal attention</em>",
        nomatch_title_em: "personal attention",
        nomatch_sub: "Your case doesn't match our standard database. Let's connect you directly with the right specialist through a secure chat.",
        tg_title: "One-Stop Chat Group",
        tg_desc: "We'll create a private Telegram group that includes you, the hospital specialist team, and our admin — all in one place for seamless coordination.",
        tg_f1: "Direct access to hospital specialist",
        tg_f2: "Translation assistance by our admin",
        tg_f3: "Full conversation tracked for your protection",
        tg_f4: "Available 7 days a week",
        tg_f5: "Response within 24 hours from hospital",
        how_it_works: "How It Works",
        how_steps: "1. Tap \"Create Chat\" below<br>2. You'll be redirected to Telegram<br>3. Our admin creates a group with the right hospital<br>4. Start discussing your case directly",
        create_tg_group: "Create Telegram Chat Group",
        back_to_results: "← Back to Analysis",
        tg_created_title: "Chat Group<br><em>Created</em>",
        tg_created_em: "Created",
        tg_created_sub: "Your private chat with the hospital specialist team is ready.",
        members_3: "3 members · Active",
        you_member: "You (Patient)",
        hospital_rep: "Hospital Specialist Team",
        admin_observer: "Medhub24 Admin (Observer)",
        tracked: "Tracked for your protection:",
        tracked_desc: " All conversations are monitored by our admin to ensure fair pricing and protect your interests.",
        open_telegram: "Open in Telegram",
        confirm: "Confirm",
        voice_sample: "The doctor in Cambodia said I have coronary artery disease and need angioplasty. I would like a second opinion and to be treated abroad."
    },
    km: {
        nav_home: "ទំព័រដើម", nav_guardian: "អ្នកការពារ", nav_dashboard: "ផ្ទាំងគ្រប់គ្រងរបស់ខ្ញុំ", nav_promotion: "ការផ្សព្វផ្សាយ",
        tap_start_reading: "ខ្ញុំត្រៀមខ្លួនអានកិច្ចព្រមព្រៀងហើយ",
        tap_to_start: "ចុចដើម្បីចាប់ផ្តើមការណែនាំអ្នកការពារ", welcome_hero: "ការថែទាំសុខភាពដែល<em>ការពារ</em>អ្នក", welcome_hero_em: "ការពារ", welcome_sub: "អ្នកសម្របសម្រួលឯករាជ្យរបស់អ្នកសម្រាប់ការព្យាបាលវេជ្ជសាស្រ្តឆ្លងព្រំដែន។ យើងធ្វើការឱ្យអ្នក មិនមែនមន្ទីរពេទ្យទេ។", next: "បន្ទាប់", voice_title: "ប្រាប់យើងពី<em>ការព្រួយបារម្ភរបស់អ្នក</em>", voice_title_em: "ការព្រួយបារម្ភរបស់អ្នក", voice_sub: "និយាយដោយធម្មជាតិជាភាសាផ្ទាល់ខ្លួន។ AI របស់យើងនឹងបំប្លែង និងវិភាគករណីរបស់អ្នក។ មិនបាច់វាយអក្សរទេ។", voice_hint: "ចុចដើម្បីចាប់ផ្តើមថតសំឡេង", voice_hint_recording: "កំពុងថត... ចុចដើម្បីឈប់", transcript_label: "ការបំប្លែង AI", retry: "ថតម្តងទៀត", edit: "កែអត្ថបទ", budget_label: "ថវិកា (ស្រេចចិត្ត)", timeline_label: "តើអ្នកត្រៀមខ្លួនសម្រាប់ការព្យាបាលនៅពេលណា?", analyze_btn: "វិភាគករណីរបស់ខ្ញុំ", analyzing_title: "កំពុងវិភាគ<br>ករណីរបស់អ្នក", analyzing_sub: "ធៀបជាមួយទិន្នន័យមន្ទីរពេទ្យដៃគូ", step_voice_received: "ទទួលការបញ្ចូលសំឡេង", step_case_categorized: "ចាត់ថ្នាក់ករណី", step_matching_db: "ផ្គូផ្គងជាមួយមូលដ្ឋានទិន្នន័យដៃគូ", step_price_range: "ប៉ាន់ស្មានជួរតម្លៃ", result_label: "ការវិភាគដំបូង", result_title: "ដំណឹងល្អ — ករណីរបស់អ្នក<em>អាចព្យាបាលបាន</em>", result_title_em: "អាចព្យាបាលបាន", result_sub: "នេះគឺជាទិដ្ឋភាពទូទៅ។ ឈ្មោះមន្ទីរពេទ្យ និងព័ត៌មានលម្អិតរបស់គ្រូពេទ្យនឹងត្រូវបានបង្ហាញបន្ទាប់ពីការហៅវីដេអូ។", diagnosis_label: "ការវាយតម្លៃដំបូង", diagnosis_desc: "ការពង្រីកសរសៃឈាមបេះដូងដោយបាឡុន និងដាក់ស្តង់", recommended_country: "ប្រទេសដែលបានណែនាំ", thailand_first: "ថៃ (ចម្បង)", price_range: "ជួរតម្លៃប៉ាន់ស្មាន", treatment_duration: "រយៈពេលព្យាបាល", days_3_5: "៣-៥ ថ្ងៃ", recovery_time: "រយៈពេលស្តារសម្បទា", weeks_2: "២ សប្តាហ៍", disclaimer_title: "អំពីការប៉ាន់ស្មាននេះ", disclaimer_text: "ការប៉ាន់ស្មាននេះផ្អែកលើទិន្នន័យនីតិវិធីស្តង់ដារពីមន្ទីរពេទ្យដៃគូរបស់យើង។ <strong>តម្លៃមិនរាប់បញ្ចូលផលវិបាក ឧបករណ៍វេជ្ជសាស្រ្តពិសេស ឬគ្រឿងបន្លាស់ដែលអាចត្រូវការក្នុងអំឡុងពេលព្យាបាល។</strong> តម្លៃចុងក្រោយត្រូវបានបញ្ជាក់បន្ទាប់ពីការវាយតម្លៃផ្ទាល់។", book_call: "កំណត់ពេលប្រឹកសាវីដេអូ", consult_free: "ការហៅវីដេអូ ៣០ នាទី · គ្មានការចំណាយ", no_match_link: "ករណីមិនត្រូវគ្នា? និយាយដោយផ្ទាល់ →", booking_label: "កាលវិភាគ · កម្រិតទី ២", book_title: "ជ្រើសរើសពេលវេលា<em>ដែលសមរម្យ</em>", book_title_em: "ដែលសមរម្យ", book_sub: "ជួបអ្នកគ្រប់គ្រងករណីតាមរយៈការហៅវីដេអូ ដើម្បីពិភាក្សាអំពីករណីរបស់អ្នកឱ្យបានស៊ីជម្រៅ។", day_tue: "អ.", day_wed: "ពុ.", day_thu: "ព្រ.", day_fri: "សុ.", time_label: "ពេលវេលា", confirm_time: "បញ្ជាក់កាលវិភាគ", guardian_label: "កិច្ចព្រមព្រៀងអ្នកការពារ", guardian_title: "មុនពេលយើង<br>ធ្វើការជាមួយគ្នា", guardian_sub: "យើងចង់ឱ្យអ្នកយល់ច្បាស់ពីរបៀបដែលយើងធ្វើការ<strong>សម្រាប់អ្នក</strong> — និងអ្វីដែលយើងស្នើសុំមកវិញ។", four_parts: "បួនផ្នែក", part1_name: "១. សិទ្ធិរបស់អ្នក", part1_tag: "ជាអ្នកជំងឺ", part2_name: "២. កាតព្វកិច្ចរបស់យើង", part2_tag: "ជាអ្នកសម្របសម្រួល", part3_name: "៣. ធ្វើការជាមួយគ្នា", part3_tag: "៩០ ថ្ងៃ", part4_name: "៤. សិទ្ធិចាកចេញ", part4_tag: "ពេលណាក៏បាន", important: "សំខាន់", tap_intro: "គ្មានឯកសារ។ គ្មានហត្ថលេខា។ គ្រាន់តែអានផ្នែកនីមួយៗ ហើយចុចដើម្បីយល់ព្រម។", start_reading: "ចាប់ផ្តើមអាន", part_1_of_4: "ផ្នែកទី ១ នៃ ៤", part_2_of_4: "ផ្នែកទី ២ នៃ ៤", part_3_of_4: "ផ្នែកទី ៣ នៃ ៤", part_4_of_4: "ផ្នែកទី ៤ នៃ ៤", rights_title: "សិទ្ធិរបស់អ្នក<br><em>ជាអ្នកជំងឺ</em>", rights_title_em: "ជាអ្នកជំងឺ", rights_sub: "យើងការពារអ្វីទាំងនេះសម្រាប់អ្នក", right_1: "<strong>ការណែនាំស្មោះត្រង់</strong> — យើងណែនាំមន្ទីរពេទ្យដែលសមនឹងករណីរបស់អ្នកបំផុត មិនមែនមន្ទីរពេទ្យដែលបង់ឱ្យយើងច្រើនបំផុតនោះទេ។", right_2: "<strong>តម្លៃច្បាស់លាស់</strong> — អ្នកឃើញតម្លៃពិតដោយគ្មានតម្លៃលាក់កំបាំង។ រាល់ដុល្លារត្រូវបានពន្យល់។", right_3: "<strong>ការការពារប្រសិនបើមានបញ្ហា</strong> — ប្រសិនបើមន្ទីរពេទ្យគិតថ្លៃលើស ឬការព្យាបាលខុសពីផែនការដែលបានព្រមព្រៀង យើងការពារអ្នក។", right_4: "<strong>ការគាំទ្របន្ទាប់ពីការព្យាបាល</strong> — ៩០ ថ្ងៃនៃការតាមដាន ការសម្របសម្រួលថ្នាំ និងមតិទីពីរនៅពេលចាំបាច់។", tap_rights: "ខ្ញុំយល់ពីសិទ្ធិរបស់ខ្ញុំ", tap_acknowledge: "ចុចដើម្បីទទួលស្គាល់", duties_title: "កាតព្វកិច្ចរបស់យើង<br><em>ចំពោះអ្នក</em>", duties_title_em: "ចំពោះអ្នក", duties_sub: "ប្រសិនបើយើងបំពានទាំងនេះ អ្នកអាចចាកចេញភ្លាមៗ", duty_1: "<strong>ព័ត៌មានស្មោះត្រង់</strong> — សូម្បីតែពេលដែលការពិតមិនមែនជាអ្វីដែលអ្នកចង់ឮក៏ដោយ។ យើងនឹងមិនជំរុញការព្យាបាលដែលមិនចាំបាច់ឡើយ។", duty_2: "<strong>តស៊ូមតិជំនួសអ្នក</strong> — យើងប្រើទំនាក់ទំនងមន្ទីរពេទ្យរបស់យើង ដើម្បីទទួលបានកញ្ចប់ថែទាំល្អបំផុតសម្រាប់អ្នក។", duty_3: "<strong>ការពារឯកជនភាពរបស់អ្នក</strong> — ព័ត៌មានវេជ្ជសាស្រ្តរបស់អ្នកត្រូវបានរក្សាការសម្ងាត់ និងមិនត្រូវបានចែករំលែកដោយគ្មានការយល់ព្រមពីអ្នកឡើយ។", duty_4: "<strong>ការធានាសេវាកម្ម</strong> — ប្រសិនបើសេវាគាំទ្រការថែទាំរបស់យើងខ្វះខាត យើងសងថ្លៃសម្របសម្រួលសេវាកម្មវិញ។", tap_duties: "ឱ្យយើងទទួលខុសត្រូវ", tap_accountable: "យើងទទួលយកការទទួលខុសត្រូវ", commit_title: "ធ្វើការជាមួយគ្នា<br><em>៩០ ថ្ងៃ</em>", commit_title_em: "៩០ ថ្ងៃ", commit_sub: "អ្វីដែលយើងស្នើសុំពីអ្នក ដើម្បីឱ្យយើងអាចបំពេញការងារបានល្អ", commit_1: "<strong>ធ្វើការតាមរយៈយើងរយៈពេល ៩០ ថ្ងៃ</strong> — ដើម្បីឱ្យយើងអាចចរចាសម្រាប់អ្នក មិនមែនប្រឆាំងនឹងខ្លួនយើងទេ។", commit_2: "<strong>ប្រាប់យើងមុនពេលសម្រេចចិត្ត</strong> — ប្រសិនបើអ្នកចង់ប្តូរមន្ទីរពេទ្យ ឬប្តូរផែនការ សូមប្រាប់យើងមុន។ យើងអាចមានជម្រើសល្អជាង។", commit_3: "<strong>ប្រវត្តិវេជ្ជសាស្រ្តត្រឹមត្រូវ</strong> — ព័ត៌មានត្រឹមត្រូវជួយយើងណែនាំការថែទាំដែលត្រឹមត្រូវ។", commit_4: "<strong>មតិស្មោះត្រង់</strong> — ចែករំលែកបទពិសោធន៍របស់អ្នកបន្ទាប់ពីនោះ ដើម្បីឱ្យយើងអាចកែលម្អបាន។", note: "ចំណាំ៖", commit_note: "\"៩០ ថ្ងៃ\" ចាប់ផ្តើមពីថ្ងៃដែលយើងចាប់ផ្តើមធ្វើការជាមួយគ្នា មិនមែនជាការប្តេជ្ញាចិត្តពេញមួយជីវិតទេ។", tap_commit: "ខ្ញុំទទួលយកការប្តេជ្ញាចិត្តនេះ", tap_together: "យើងនៅជាមួយគ្នា", exit_title: "សិទ្ធិរបស់អ្នក<br><em>ក្នុងការចាកចេញ</em>", exit_title_em: "ក្នុងការចាកចេញ", exit_sub: "សំខាន់បំផុត — អ្នកអាចចាកចេញពេលណាក៏បាន", exit_1: "<strong>គ្មានថ្លៃលុបចោល</strong> — ចាកចេញពេលណាក៏បានដោយគ្មានការផាកពិន័យ។", exit_2: "<strong>ទិន្នន័យរបស់អ្នកជារបស់អ្នក</strong> — ប្រសិនបើអ្នកលុបចោល យើងលុបទិន្នន័យវេជ្ជសាស្រ្តរបស់អ្នកក្នុងរយៈពេល ៧ ថ្ងៃ។", exit_3: "<strong>ការសងប្រាក់កក់ការថែទាំវិញ</strong> — ប្រសិនបើអ្នកលុបចោលមុនពេលការព្យាបាលចាប់ផ្តើម ប្រាក់កក់ ១០% សម្រាប់សេវាកម្មរបស់យើងត្រូវបានសងវិញទាំងស្រុង។", exit_4: "<strong>គ្មានការចាក់សោជាមួយមន្ទីរពេទ្យ</strong> — អ្នកអាចស្វែងរកការព្យាបាលនៅកន្លែងផ្សេងទៀត ទោះបីជាបានលុបចោលជាមួយយើងក៏ដោយ។", exit_quote: "\"យើងទទួលបានការជឿទុកចិត្តរបស់អ្នកដោយធ្វើការងារល្អ — មិនមែនដោយការចាក់សោអ្នកទុកនោះទេ។\"", tap_exit: "ខ្ញុំយល់ និងយល់ព្រមទាំងអស់", tap_final: "ការទទួលស្គាល់ចុងក្រោយ", confirm_agreement: "បញ្ជាក់កិច្ចព្រមព្រៀងអ្នកការពារ", welcome_inner: "សូមស្វាគមន៍មកកាន់<br><em>រង្វង់ផ្ទៃក្នុង</em>", welcome_inner_em: "រង្វង់ផ្ទៃក្នុង", welcome_inner_sub: "ឥឡូវនេះយើងកំពុងធ្វើការឱ្យអ្នកហើយ។ ការចូលប្រើព័ត៌មានពេញលេញត្រូវបានដោះសោ។", now_access: "ឥឡូវនេះអ្នកមានសិទ្ធិចូលប្រើ", access_1: "✓ ឈ្មោះ និងព័ត៌មានលម្អិតរបស់មន្ទីរពេទ្យ", access_2: "✓ តម្លៃដែលបានចរចា", access_3: "✓ គ្រូពេទ្យឯកទេសដែលបានណែនាំ", access_4: "✓ ទំនាក់ទំនងផ្ទាល់ជាមួយអ្នកគ្រប់គ្រងករណី", view_hospitals: "មើលមន្ទីរពេទ្យដែលបានណែនាំ", full_disclosure_label: "ការបង្ហាញពេញលេញ · កម្រិតទី ៣", hospitals_title: "៣ ជម្រើសដែល<em>យើងណែនាំ</em>", hospitals_title_em: "យើងណែនាំ", hospitals_sub: "ផ្អែកលើចំណេះដឹងទីផ្សារ ១៥ ឆ្នាំ។ តម្លៃឆ្លុះបញ្ចាំងពីកិច្ចព្រមព្រៀងដៃគូរបស់យើង។", estimate_note_title: "ចំណាំតម្លៃប៉ាន់ស្មាន", estimate_note_text: "តម្លៃដែលបានបង្ហាញគឺសម្រាប់នីតិវិធីស្តង់ដារ។ <strong>មិនរាប់បញ្ចូលផលវិបាក ឬឧបករណ៍វេជ្ជសាស្រ្តពិសេស។</strong> មន្ទីរពេទ្យបញ្ជាក់តម្លៃចុងក្រោយបន្ទាប់ពីការវាយតម្លៃផ្ទាល់។", recommended_tag: "បានណែនាំ", alternative_tag: "ជម្រើសផ្សេង", budget_tag: "ជម្រើសសន្សំ", partner_price: "តម្លៃដៃគូ", duration: "រយៈពេល", days_4: "៤ ថ្ងៃ", days_5: "៥ ថ្ងៃ", walk_in: "តម្លៃធម្មតា", select_bumrungrad: "ជ្រើសរើស Bumrungrad", care_level_label: "កម្រិតគាំទ្រការថែទាំ", care_title: "ជ្រើសរើស<em>ការគាំទ្រការថែទាំ</em>របស់អ្នក", care_title_em: "ការគាំទ្រការថែទាំ", care_sub: "ទាំងនេះគឺជាសេវាកម្មគាំទ្រការថែទាំ។ ការព្យាបាលវេជ្ជសាស្រ្តត្រូវបានបង់ដាច់ដោយឡែកទៅមន្ទីរពេទ្យ។", basic_name: "ការសម្របសម្រួលមូលដ្ឋាន", basic_price: "រួមបញ្ចូល", basic_f1: "ការកក់ការណាត់ជួបមន្ទីរពេទ្យ", basic_f2: "អ្នកបកប្រែបុគ្គលិកមន្ទីរពេទ្យ (មូលដ្ឋាន)", basic_f3: "ព័ត៌មានមូលដ្ឋានមុនពេលធ្វើដំណើរ", standard_name: "ការថែទាំស្តង់ដារ", standard_price: "$៣០ / ថ្ងៃ", std_f1: "អ្នកបកប្រែឯកទេសនៅមន្ទីរពេទ្យ (៨:០០ ព្រឹក – ៤:០០ រសៀល)", std_f2: "ការដឹកជញ្ជូនព្រលានយន្តហោះ (មកដល់ និងចាកចេញ)", std_f3: "ជំនួយការកក់សណ្ឋាគារប្រសិនបើត្រូវការ", std_f4: "ការសម្របសម្រួលនៅនឹងកន្លែងក្នុងអំឡុងពេលព្យាបាល", std_f5: "កញ្ចប់ថែទាំពេញលេញតែម្តង", premium_name: "ការតស៊ូមតិកម្រិតខ្ពស់", premium_price: "$១២០ ថេរ", prem_f1: "លក្ខណៈពិសេសការថែទាំស្តង់ដារទាំងអស់", prem_f2: "ការតាមដាន ៩០ ថ្ងៃបន្ទាប់ពីការព្យាបាល", prem_f3: "ការចូលជួបអ្នកគ្រប់គ្រងករណីអាទិភាព", prem_f4: "មតិទីពីរប្រសិនបើរោគសញ្ញាកើតឡើង", prem_f5: "ការជូនដំណឹងដល់គ្រួសារជាភាសារបស់អ្នក", concierge_name: "Concierge ពេញលេញ", concierge_price: "$៣៥០ ថេរ", conc_f1: "លក្ខណៈពិសេសកម្រិតខ្ពស់ទាំងអស់", conc_f2: "អ្នកគ្រប់គ្រងករណីអមដំណើរផ្ទាល់", conc_f3: "ការសង្ខេបព័ត៌មានដល់គ្រួសារប្រចាំថ្ងៃ", conc_f4: "ការតាមដានបន្ថែមរយៈពេល ៦ ខែ", confirm_standard: "បញ្ជាក់ការថែទាំស្តង់ដារ", confirm_booking: "បញ្ជាក់ការកក់", booking_final_title: "ជំហានចុងក្រោយ — <em>ប្រាក់កក់ការថែទាំតែប៉ុណ្ណោះ</em>", booking_final_em: "ប្រាក់កក់ការថែទាំតែប៉ុណ្ណោះ", booking_final_sub: "អ្នកបង់តែប្រាក់កក់តូចមួយសម្រាប់សេវាគាំទ្រការថែទាំរបស់យើងប៉ុណ្ណោះ។ ការព្យាបាលវេជ្ជសាស្រ្តត្រូវបានបង់ផ្ទាល់ទៅមន្ទីរពេទ្យនៅថ្ងៃដំបូង។", hospital: "មន្ទីរពេទ្យ", doctor: "គ្រូពេទ្យឯកទេស", treatment_date: "កាលបរិច្ឆេទព្យាបាល", may_15_18: "១៥-១៨ ឧសភា ២០២៦", care_package: "ការគាំទ្រការថែទាំ", standard_4days: "ស្តង់ដារ · ៤ ថ្ងៃ", medical_section: "ការព្យាបាលវេជ្ជសាស្ត្រ", treatment_fee: "កញ្ចប់ការព្យាបាល", pay_to: "ការបង់ប្រាក់ទៅ", hospital_direct: "មន្ទីរពេទ្យដោយផ្ទាល់", pay_when: "ពេលវេលាបង់ប្រាក់", first_day: "ថ្ងៃដំបូងនៃការព្យាបាល", no_medical_deposit: "✓ មិនតម្រូវឱ្យមានប្រាក់កក់សម្រាប់ការព្យាបាលវេជ្ជសាស្ត្រទេ", care_deposit_title: "ប្រាក់កក់ការថែទាំ", service_total: "សរុបការថែទាំស្តង់ដារ (៤ ថ្ងៃ × $៣០)", deposit_10: "ប្រាក់កក់ (១០% ថ្ងៃនេះ)", balance_on_day1: "សមតុល្យនៅថ្ងៃព្យាបាលដំបូង", deposit_terms_title: "លក្ខខណ្ឌប្រាក់កក់", term_1: "✓ ប្រាក់កក់អនុវត្តតែចំពោះសេវាគាំទ្រការថែទាំប៉ុណ្ណោះ", term_2: "✓ សមតុល្យពេញលេញត្រូវបង់នៅថ្ងៃព្យាបាលដំបូង", term_3: "✓ ប្រសិនបើអ្នកលុបចោល និងមិនអាចមកបាន ប្រាក់កក់ត្រូវបាន<strong>សងវិញពេញលេញ</strong>", term_4: "✓ គ្មានថ្លៃលុបចោលពីខាងយើងទេ", payment_method: "វិធីសាស្រ្តបង់ប្រាក់", pay_12: "បង់ប្រាក់កក់ $១២ · បញ្ជាក់ការកក់", deposit_security: "🔒 ការបង់ប្រាក់មានសុវត្ថិភាព · សងវិញប្រសិនបើអ្នកលុបចោល", greeting: "សួស្តី", active_case: "ករណី #8492 · សកម្ម", case_title: "ការពង្រីកសរសៃឈាមបេះដូង<br>នៅ Bumrungrad", case_subtitle: "នៅសល់ ២៣ ថ្ងៃ · ១៥-១៨ ឧសភា ២០២៦", view_timeline: "មើលពេលវេលា", chat_cm: "ជជែកជាមួយ CM", prep_docs: "រៀបចំឯកសារ", docs_3_5: "៣ ក្នុងចំណោម ៥ រួចរាល់", travel: "ការរៀបចំការធ្វើដំណើរ", airport_pickup: "បានរៀបចំការទទួលនៅព្រលានយន្តហោះ", accommodation: "កន្លែងស្នាក់នៅ", hotel_sukhumvit: "Grand Sukhumvit · ៤ យប់", case_manager: "អ្នកគ្រប់គ្រងករណី", cm_pie: "លោក Pie · ឆ្លើយតបក្នុងរយៈពេល ២ ម៉ោង", restart: "ចាប់ផ្តើម Demo ឡើងវិញ", restart_short: "ឡើងវិញ", skip_dashboard: "រំលងទៅ Dashboard", modal_title: "សូម<em>យល់ព្រម</em>ជាមុន", modal_title_em: "យល់ព្រម", modal_text: "អ្នកត្រូវចុចប្រអប់ \"យល់ព្រម\" មុននឹងបន្ត។ នេះបង្កើតទំនុកចិត្តច្បាស់លាស់រវាងយើង និងអ្នក។", understood: "យល់ព្រម", special_case: "ការគ្រប់គ្រងករណីពិសេស", nomatch_title: "ករណីរបស់អ្នកត្រូវការ<em>ការយកចិត្តទុកដាក់ផ្ទាល់ខ្លួន</em>", nomatch_title_em: "ការយកចិត្តទុកដាក់ផ្ទាល់ខ្លួន", nomatch_sub: "ករណីរបស់អ្នកមិនត្រូវគ្នានឹងមូលដ្ឋានទិន្នន័យស្តង់ដាររបស់យើងទេ។ តោះភ្ជាប់ទំនាក់ទំនងអ្នកផ្ទាល់ជាមួយគ្រូពេទ្យឯកទេសតាមរយៈការជជែកដែលមានសុវត្ថិភាព។", tg_title: "ក្រុមជជែកមួយកន្លែង", tg_desc: "យើងនឹងបង្កើតក្រុម Telegram ឯកជនមួយដែលរួមមានអ្នក ក្រុមគ្រូពេទ្យឯកទេសនៃមន្ទីរពេទ្យ និងអ្នកគ្រប់គ្រងរបស់យើង — ទាំងអស់នៅក្នុងកន្លែងតែមួយសម្រាប់ការសម្របសម្រួលដ៏រលូន។", tg_f1: "ចូលជួបផ្ទាល់ជាមួយគ្រូពេទ្យឯកទេសមន្ទីរពេទ្យ", tg_f2: "ជំនួយការបកប្រែដោយអ្នកគ្រប់គ្រងរបស់យើង", tg_f3: "ការសន្ទនាពេញលេញត្រូវបានតាមដានដើម្បីការពារអ្នក", tg_f4: "អាចប្រើបាន ៧ ថ្ងៃក្នុងមួយសប្តាហ៍", tg_f5: "ឆ្លើយតបក្នុងរយៈពេល ២៤ ម៉ោងពីមន្ទីរពេទ្យ", how_it_works: "របៀបដែលវាដំណើរការ", how_steps: "១. ចុច \"បង្កើតការជជែក\" ខាងក្រោម<br>២. អ្នកនឹងត្រូវបានបញ្ជូនទៅ Telegram<br>៣. អ្នកគ្រប់គ្រងរបស់យើងបង្កើតក្រុមជាមួយមន្ទីរពេទ្យដែលត្រឹមត្រូវ<br>៤. ចាប់ផ្តើមពិភាក្សាករណីរបស់អ្នកដោយផ្ទាល់", create_tg_group: "បង្កើតក្រុមជជែក Telegram", back_to_results: "← ត្រឡប់ទៅការវិភាគ", tg_created_title: "ក្រុមជជែក<br><em>ត្រូវបានបង្កើត</em>", tg_created_em: "ត្រូវបានបង្កើត", tg_created_sub: "ការជជែកផ្ទាល់ខ្លួនរបស់អ្នកជាមួយក្រុមគ្រូពេទ្យឯកទេសមន្ទីរពេទ្យបានរួចរាល់ហើយ។", members_3: "សមាជិក ៣ នាក់ · សកម្ម", you_member: "អ្នក (អ្នកជំងឺ)", hospital_rep: "ក្រុមគ្រូពេទ្យឯកទេសមន្ទីរពេទ្យ", admin_observer: "អ្នកគ្រប់គ្រង Medhub24 (អ្នកសង្កេតការណ៍)", tracked: "តាមដានដើម្បីការពារអ្នក៖", tracked_desc: " រាល់ការសន្ទនាត្រូវបានត្រួតពិនិត្យដោយអ្នកគ្រប់គ្រងរបស់យើង ដើម្បីធានាតម្លៃសមរម្យ និងការពារផលប្រយោជន៍របស់អ្នក។", open_telegram: "បើកក្នុង Telegram",
        confirm: "បញ្ជាក់",
        voice_sample: "គ្រូពេទ្យនៅកម្ពុជាបាននិយាយថា ខ្ញុំមានជំងឺសរសៃឈាមបេះដូង និងត្រូវការការពង្រីកបាឡុន។ ខ្ញុំចង់បានមតិទីពីរ និងទទួលការព្យាបាលនៅបរទេស。"
    },
    my: {
        nav_home: "ပင်မစာမျက်နှာ", nav_guardian: "အစောင့်အရှောက်", nav_dashboard: "ကျွန်ုပ်၏ဒက်ရှ်ဘုတ်", nav_promotion: "ပရိုမိုးရှင်း",
        tap_start_reading: "ကျွန်ုပ် သဘောတူညီချက်ကို ဖတ်ရန် အဆင်သင့်ဖြစ်ပါပြီ",
        tap_to_start: "ကာကွယ်သူမိတ်ဆက်ကို စတင်ရန် နှိပ်ပါ", welcome_hero: "သင့်ကို<em>ကာကွယ်</em>ပေးသော ကျန်းမာရေးစောင့်ရှောက်မှု", welcome_hero_em: "ကာကွယ်", welcome_sub: "နိုင်ငံခြားဆေးကုသမှုအတွက် လွတ်လပ်သော ညှိနှိုင်းသူ။ ကျွန်ုပ်တို့သည် ဆေးရုံအတွက်မဟုတ်ဘဲ သင့်အတွက် အလုပ်လုပ်ပေးပါသည်။", next: "ရှေ့သို့", voice_title: "သင့်<em>စိုးရိမ်မှု</em>ကို ပြောပြပါ", voice_title_em: "စိုးရိမ်မှု", voice_sub: "သင့်ဘာသာစကားဖြင့် သဘာဝအတိုင်း ပြောပါ။ ကျွန်ုပ်တို့၏ AI က စာသားအဖြစ် ပြောင်းလဲပြီး ဆန်းစစ်ပေးပါမည်။ စာရိုက်ရန် မလိုပါ။", voice_hint: "အသံဖမ်းရန် နှိပ်ပါ", voice_hint_recording: "ဖမ်းယူနေသည်... ရပ်ရန်နှိပ်ပါ", transcript_label: "AI စာသားပြောင်းခြင်း", retry: "ပြန်ဖမ်းမည်", edit: "စာသားပြင်မည်", budget_label: "ဘတ်ဂျက် (ရွေးချယ်စရာ)", timeline_label: "မည်သည့်အချိန်တွင် ကုသမှုပြုရန် အဆင်သင့်ဖြစ်သည်?", analyze_btn: "ကျွန်ုပ်၏ အမှုကို ဆန်းစစ်မည်", analyzing_title: "သင့်အမှုကို<br>ဆန်းစစ်နေသည်", analyzing_sub: "ပူးပေါင်းဆောင်ရွက်သည့် ဆေးရုံဒေတာများနှင့် နှိုင်းယှဉ်နေသည်", step_voice_received: "အသံထည့်သွင်းမှု လက်ခံရရှိ", step_case_categorized: "အမှုအမျိုးအစားခွဲခြားပြီး", step_matching_db: "မိတ်ဖက်ဒေတာဘေ့စ်နှင့် ကိုက်ညီစစ်ဆေးနေသည်", step_price_range: "စျေးနှုန်းအပိုင်းအခြား ခန့်မှန်းနေသည်", result_label: "ကနဦးဆန်းစစ်ခြင်း", result_title: "သတင်းကောင်း — သင့်အမှုကို<em>ကုသနိုင်သည်</em>", result_title_em: "ကုသနိုင်သည်", result_sub: "ဤသည်မှာ ခြုံငုံသုံးသပ်ချက်ဖြစ်သည်။", diagnosis_label: "ကနဦးဆုံးဖြတ်ချက်", diagnosis_desc: "stent ဖြင့် coronary balloon လုပ်ငန်းစဉ်", recommended_country: "အကြံပြုထားသော နိုင်ငံ", thailand_first: "ထိုင်း (အဓိက)", price_range: "ခန့်မှန်းစျေးနှုန်း", treatment_duration: "ကုသမှုကြာချိန်", days_3_5: "၃-၅ ရက်", recovery_time: "ပြန်လည်ကောင်းမွန်ချိန်", weeks_2: "၂ ပတ်", disclaimer_title: "ဤခန့်မှန်းချက်အကြောင်း", disclaimer_text: "ဤခန့်မှန်းချက်သည် ကျွန်ုပ်တို့၏ မိတ်ဖက်ဆေးရုံများမှ စုဆောင်းထားသော စံလုပ်ထုံးလုပ်နည်းဒေတာများအပေါ် အခြေခံပါသည်။ <strong>စျေးနှုန်းတွင် ရှုပ်ထွေးမှုများ၊ အထူးဆေးဘက်ဆိုင်ရာ ကိရိယာများ သို့မဟုတ် ကုသမှုအတွင်း လိုအပ်နိုင်သည့် ဆက်စပ်ပစ္စည်းများ မပါဝင်ပါ။</strong>", book_call: "ဗီဒီယိုတိုင်ပင်မှု ချိန်းဆိုမည်", consult_free: "၃၀ မိနစ် ဗီဒီယိုခေါ်ဆိုမှု · အခမဲ့", no_match_link: "အမှု မကိုက်ညီဘူးလား? တိုက်ရိုက်စကားပြော →", booking_label: "အချိန်ဇယား · အဆင့် ၂", book_title: "<em>သင့်တော်သော</em> အချိန်ရွေးပါ", book_title_em: "သင့်တော်သော", book_sub: "ဗီဒီယိုခေါ်ဆိုမှုမှတစ်ဆင့် Case Manager နှင့် တွေ့ဆုံပြီး သင့်အကြောင်းကို အသေးစိတ်ဆွေးနွေးပါ။", day_tue: "အင်္ဂါ", day_wed: "ဗုဒ္ဓ", day_thu: "ကြာသပ.", day_fri: "သောကြာ", time_label: "အချိန်", confirm_time: "အချိန်ဇယားအတည်ပြုမည်", guardian_label: "ကာကွယ်သူသဘောတူညီချက်", guardian_title: "ကျွန်ုပ်တို့<br>အတူတကွ အလုပ်မလုပ်မီ", guardian_sub: "ကျွန်ုပ်တို့<strong>သင့်အတွက်</strong> မည်သို့အလုပ်လုပ်သည်နှင့် ပြန်လည်တောင်းဆိုသည့်အရာများကို သင်ရှင်းရှင်းလင်းလင်း နားလည်စေလိုပါသည်။", four_parts: "အပိုင်း ၄ ပိုင်း", part1_name: "၁။ သင့်အခွင့်အရေးများ", part1_tag: "လူနာအနေဖြင့်", part2_name: "၂။ ကျွန်ုပ်တို့၏ တာဝန်များ", part2_tag: "ညှိနှိုင်းသူအနေဖြင့်", part3_name: "၃။ အတူတကွအလုပ်လုပ်ခြင်း", part3_tag: "၉၀ ရက်", part4_name: "၄။ ထွက်ခွာခွင့်", part4_tag: "အချိန်မရွေး", important: "အရေးကြီး", tap_intro: "စာရွက်စာတမ်းမလို၊ လက်မှတ်မလိုပါ။ အပိုင်းတစ်ခုစီကို ဖတ်ပြီး သဘောတူရန် နှိပ်ရုံသာ။", start_reading: "ဖတ်ရန်စတင်မည်", part_1_of_4: "အပိုင်း ၁/၄", part_2_of_4: "အပိုင်း ၂/၄", part_3_of_4: "အပိုင်း ၃/၄", part_4_of_4: "အပိုင်း ၄/၄", rights_title: "သင့်အခွင့်အရေးများ<br><em>လူနာအနေဖြင့်</em>", rights_title_em: "လူနာအနေဖြင့်", rights_sub: "ဤအရာများကို သင့်အတွက် ကာကွယ်ပေးပါသည်", right_1: "<strong>ရိုးသားသောလမ်းညွှန်မှု</strong> — ကျွန်ုပ်တို့ကို ငွေအများဆုံးပေးသည့်ဆေးရုံမဟုတ်ဘဲ သင့်အမှုနှင့် အကိုက်ညီဆုံး ဆေးရုံကို အကြံပြုပါမည်။", right_2: "<strong>ရှင်းလင်းသောစျေးနှုန်း</strong> — သင်သည် ဖုံးကွယ်ထားသော ဝန်ဆောင်ခများမပါဘဲ စျေးနှုန်းအမှန်ကို မြင်ရပါမည်။ ကျသင့်ငွေအားလုံးကို ရှင်းပြပေးပါမည်။", right_3: "<strong>ပြဿနာများအတွက် ကာကွယ်မှု</strong> — ဆေးရုံက လွန်ကဲစွာ ငွေတောင်းခံခြင်း သို့မဟုတ် ကုသမှုသည် သဘောတူထားသည့်အတိုင်းမဟုတ်ပါက ကျွန်ုပ်တို့က ကာကွယ်ပေးပါမည်။", right_4: "<strong>ကုသမှုပြီးနောက် အထောက်အပံ့</strong> — ၉၀ ရက် စောင့်ကြည့်ခြင်း၊ ဆေးညှိနှိုင်းခြင်းနှင့် လိုအပ်ပါက ဒုတိယထင်မြင်ချက် ရယူပေးခြင်း။", tap_rights: "ကျွန်ုပ်၏ အခွင့်အရေးများကို နားလည်ပါသည်", tap_acknowledge: "အသိအမှတ်ပြုရန် နှိပ်ပါ", duties_title: "ကျွန်ုပ်တို့၏ တာဝန်များ<br><em>သင့်ဆီသို့</em>", duties_title_em: "သင့်ဆီသို့", duties_sub: "ဤအရာများ ချိုးဖျက်ပါက သင် ချက်ချင်းထွက်ခွာနိုင်သည်", duty_1: "<strong>မှန်ကန်သောအချက်အလက်</strong> — အမှန်တရားသည် သင်ကြားချင်သည့်အရာမဟုတ်သည့်တိုင်။ မလိုအပ်သော ကုသမှုများကို တိုက်တွန်းမည်မဟုတ်ပါ။", duty_2: "<strong>သင့်ကိုယ်စား ထောက်ခံမှု</strong> — သင့်အတွက် အကောင်းဆုံး ကုသမှုပက်ကေ့ချ် ရရှိရန် ကျွန်ုပ်တို့၏ ဆေးရုံများနှင့် ဆက်ဆံရေးကို အသုံးပြုပါမည်။", duty_3: "<strong>သင့်ကိုယ်ရေးလုံခြုံမှု</strong> — သင့်ဆေးဘက်ဆိုင်ရာ အချက်အလက်များကို လျှို့ဝှက်ထားရှိမည်ဖြစ်ပြီး သင့်သဘောတူညီချက်မပါဘဲ မည်သူ့ကိုမျှ မျှဝေမည်မဟုတ်ပါ။", duty_4: "<strong>ဝန်ဆောင်မှုအာမခံ</strong> — ကျွန်ုပ်တို့၏ ဝန်ဆောင်မှု မလုံလောက်ပါက ညှိနှိုင်းခကို ပြန်လည်ပေးအပ်ပါမည်။", tap_duties: "ကျွန်ုပ်တို့ကို တာဝန်ရှိစေပါ", tap_accountable: "ကျွန်ုပ်တို့ တာဝန်ခံပါသည်", commit_title: "အတူတကွ<br><em>၉၀ ရက်</em>", commit_title_em: "၉၀ ရက်", commit_sub: "ကျွန်ုပ်တို့ ကောင်းစွာ အလုပ်လုပ်နိုင်ရန် သင့်ထံမှ တောင်းဆိုမှု", commit_1: "<strong>၉၀ ရက် ကျွန်ုပ်တို့မှတစ်ဆင့် အလုပ်လုပ်ပါ</strong> — သင့်အတွက် အကောင်းဆုံး ညှိနှိုင်းပေးနိုင်ရန် ဖြစ်သည်။", commit_2: "<strong>ဆုံးဖြတ်ချက်မချမီ ကျွန်ုပ်တို့ကို ပြောပါ</strong> — ဆေးရုံ သို့မဟုတ် အစီအစဉ်ပြောင်းလဲလိုပါက ကြိုတင်ပြောပြပါ။ ကျွန်ုပ်တို့တွင် ပိုကောင်းသော ရွေးချယ်စရာများ ရှိနိုင်ပါသည်။", commit_3: "<strong>မှန်ကန်သော ဆေးဘက်ဆိုင်ရာ သမိုင်း</strong> — မှန်ကန်သောအချက်အလက်များက မှန်ကန်သော ကုသမှုကို အကြံပြုရန် ကူညီပေးပါသည်။", commit_4: "<strong>ရိုးသားသော တုံ့ပြန်မှု</strong> — ကျွန်ုပ်တို့ တိုးတက်စေရန် သင်၏ အတွေ့အကြုံကို ပြန်လည်မျှဝေပါ။", note: "မှတ်ချက်:", commit_note: "\"၉၀ ရက်\" သည် အတူအလုပ်လုပ်စသည့်နေ့မှ စတင်ခြင်းဖြစ်ပြီး တစ်သက်တာလုံးအတွက် မဟုတ်ပါ။", tap_commit: "ဤကတိကို လက်ခံပါသည်", tap_together: "ကျွန်ုပ်တို့ အတူတူရှိပါသည်", exit_title: "သင့်အခွင့်အရေး<br><em>ထွက်ခွာရန်</em>", exit_title_em: "ထွက်ခွာရန်", exit_sub: "အရေးကြီးဆုံး — သင် အချိန်မရွေး ထွက်ခွာနိုင်သည်", exit_1: "<strong>ပယ်ဖျက်ခ မရှိ</strong> — ဒဏ်ငွေမပေးဘဲ အချိန်မရွေး ထွက်ခွာနိုင်သည်။", exit_2: "<strong>သင့်ဒေတာသည် သင့်ဥစ္စာ</strong> — ပယ်ဖျက်ပါက ၇ ရက်အတွင်း ဆေးဘက်ဆိုင်ရာ အချက်အလက်များကို ဖျက်ပစ်ပါမည်။", exit_3: "<strong>ဝန်ဆောင်မှုစရန်ငွေ ပြန်အမ်းခြင်း</strong> — ကုသမှုမစတင်မီ ပယ်ဖျက်ပါက ၁၀% စရန်ငွေကို အပြည့်အဝ ပြန်အမ်းပါမည်။", exit_4: "<strong>ဆေးရုံနှင့် ချုပ်နှောင်မှုမရှိ</strong> — ကျွန်ုပ်တို့နှင့် ပယ်ဖျက်ပြီးနောက် အခြားနေရာတွင် ကုသမှု ခံယူနိုင်သည်။", exit_quote: "\"ကျွန်ုပ်တို့သည် သင့်ကို ချုပ်နှောင်၍မဟုတ်ဘဲ ကောင်းသောလုပ်ငန်းဖြင့် ယုံကြည်မှုရရှိခြင်း ဖြစ်သည်။\"", tap_exit: "အားလုံးကို နားလည်ပြီး သဘောတူပါသည်", tap_final: "နောက်ဆုံးအသိအမှတ်ပြုမှု", confirm_agreement: "ကာကွယ်သူသဘောတူညီချက်ကို အတည်ပြုပါ", welcome_inner: "<em>အတွင်းစက်ဝိုင်း</em>သို့<br>ကြိုဆိုပါသည်", welcome_inner_em: "အတွင်းစက်ဝိုင်း", welcome_inner_sub: "ကျွန်ုပ်တို့ ယခု သင့်အတွက် အလုပ်လုပ်နေပါပြီ။ အချက်အလက်များအားလုံးကို ကြည့်ရှုနိုင်ပါပြီ။", now_access: "ယခု သင်ရရှိနိုင်သည်မှာ", access_1: "✓ ဆေးရုံအမည်များနှင့် အသေးစိတ်အချက်အလက်များ", access_2: "✓ ညှိနှိုင်းထားသော စျေးနှုန်းများ", access_3: "✓ အကြံပြုထားသော အထူးကုဆရာဝန်များ", access_4: "✓ Case Manager နှင့် တိုက်ရိုက်ဆက်သွယ်မှု", view_hospitals: "အကြံပြုထားသော ဆေးရုံများကို ကြည့်မည်", full_disclosure_label: "အပြည့်အဝ ဖော်ပြမှု · အဆင့် ၃", hospitals_title: "<em>ကျွန်ုပ်တို့ အကြံပြုသော</em> ၃ ရွေးချယ်စရာ", hospitals_title_em: "ကျွန်ုပ်တို့ အကြံပြုသော", hospitals_sub: "၁၅ နှစ်စာ စျေးကွက်အတွေ့အကြုံအပေါ် အခြေခံထားပါသည်။", estimate_note_title: "စျေးနှုန်းခန့်မှန်းမှု မှတ်ချက်", estimate_note_text: "ဖော်ပြထားသောစျေးနှုန်းများသည် စံလုပ်ထုံးလုပ်နည်းအတွက် ဖြစ်သည်။ <strong>ရှုပ်ထွေးမှုများ သို့မဟုတ် အထူးဆေးဘက်ဆိုင်ရာ ဆက်စပ်ပစ္စည်းများ မပါဝင်ပါ။</strong>", recommended_tag: "အကြံပြုထား", alternative_tag: "အခြားရွေးချယ်စရာ", budget_tag: "သက်သာသောရွေးချယ်စရာ", partner_price: "မိတ်ဖက်စျေးနှုန်း", duration: "ကြာချိန်", days_4: "၄ ရက်", days_5: "၅ ရက်", walk_in: "သာမန်စျေးနှုန်း", select_bumrungrad: "Bumrungrad ကို ရွေးမည်", care_level_label: "စောင့်ရှောက်မှုအဆင့်", care_title: "သင့်<em>စောင့်ရှောက်မှု</em>ကို ရွေးပါ", care_title_em: "စောင့်ရှောက်မှု", care_sub: "ဤအရာများသည် စောင့်ရှောက်မှု ဝန်ဆောင်မှုများ ဖြစ်သည်။ ဆေးကုသမှုအတွက် ဆေးရုံသို့ သီးခြားပေးဆောင်ရပါမည်။", basic_name: "အခြေခံညှိနှိုင်းမှု", basic_price: "ပါဝင်ပြီး", basic_f1: "ဆေးရုံချိန်းဆိုမှုများ ဆောင်ရွက်ပေးခြင်း", basic_f2: "ဆေးရုံဝန်ထမ်း စကားပြန် (သာမန်)", basic_f3: "ခရီးမသွားမီ အခြေခံအချက်အလက်များ", standard_name: "စံစောင့်ရှောက်မှု", standard_price: "$၃၀ / ရက်", std_f1: "ဆေးရုံတွင် သီးသန့်စကားပြန် (နံနက် ၈:၀၀ မှ ညနေ ၄:၀၀ အထိ)", std_f2: "လေဆိပ် အကြိုအပို့ (ဆိုက်ရောက်နှင့် ထွက်ခွာ)", std_f3: "လိုအပ်ပါက ဟိုတယ်ကြိုတင်မှာယူမှု ကူညီခြင်း", std_f4: "ကုသမှုကာလအတွင်း မြေပြင်ညှိနှိုင်းမှုများ", std_f5: "တစ်ကြိမ်စာ အပြည့်အဝ စောင့်ရှောက်မှု", premium_name: "အထူးကာကွယ်မှု", premium_price: "$၁၂၀ (တစ်ကြိမ်တည်း)", prem_f1: "Standard Care အင်္ဂါရပ်များအားလုံး ပါဝင်သည်", prem_f2: "၉၀ ရက် ကုသမှုပြီးနောက် စောင့်ကြည့်ပေးခြင်း", prem_f3: "Case Manager ကို ဦးစားပေး ဆက်သွယ်နိုင်ခြင်း", prem_f4: "ရောဂါလက္ခဏာများရှိပါက ဒုတိယထင်မြင်ချက် ရယူပေးခြင်း", prem_f5: "သင့်ဘာသာစကားဖြင့် မိသားစုထံ အကြောင်းကြားပေးခြင်း", concierge_name: "Full Concierge", concierge_price: "$၃၅၀ (တစ်ကြိမ်တည်း)", conc_f1: "Premium အင်္ဂါရပ်များအားလုံး ပါဝင်သည်", conc_f2: "Case Manager ကိုယ်တိုင် လိုက်ပါဆောင်ရွက်ပေးခြင်း", conc_f3: "နေ့စဉ် မိသားစုထံ အစီရင်ခံစာ ပေးပို့ခြင်း", conc_f4: "၆ လအထိ တိုးမြှင့်စောင့်ကြည့်ပေးခြင်း", confirm_standard: "Standard Care ကို အတည်ပြုမည်", confirm_booking: "စာရင်းပေးသွင်းမှုကို အတည်ပြုမည်", booking_final_title: "နောက်ဆုံးအဆင့် — <em>စောင့်ရှောက်မှုစရန်ငွေသာ</em>", booking_final_em: "စောင့်ရှောက်မှုစရန်ငွေသာ", booking_final_sub: "ကျွန်ုပ်တို့၏ စောင့်ရှောက်မှုဝန်ဆောင်မှုအတွက် စရန်ငွေအနည်းငယ်သာ ပေးဆောင်ရပါမည်။", hospital: "ဆေးရုံ", doctor: "အထူးကုဆရာဝန်", treatment_date: "ကုသမှုရက်စွဲ", may_15_18: "မေလ ၁၅-၁၈၊ ၂၀၂၆", care_package: "စောင့်ရှောက်မှု", standard_4days: "စံ · ၄ ရက်", medical_section: "ဆေးကုသမှု", treatment_fee: "ကုသမှုပက်ကေ့ချ်", pay_to: "ပေးဆောင်ရန်", hospital_direct: "ဆေးရုံသို့ တိုက်ရိုက်", pay_when: "ပေးဆောင်ရမည့်အချိန်", first_day: "ကုသမှု ပထမနေ့", no_medical_deposit: "✓ ဆေးကုသမှုအတွက် စရန်ငွေပေးရန် မလိုပါ", care_deposit_title: "စောင့်ရှောက်မှုစရန်ငွေ", service_total: "စံစောင့်ရှောက်မှု စုစုပေါင်း (၄ ရက် × $၃၀)", deposit_10: "စရန်ငွေ (ယနေ့အတွက် ၁၀%)", balance_on_day1: "ပထမနေ့တွင် ပေးဆောင်ရမည့် ကျန်ငွေ", deposit_terms_title: "စရန်ငွေ သဘောတူညီချက်", term_1: "✓ စရန်ငွေသည် စောင့်ရှောက်မှုဝန်ဆောင်မှုအတွက်သာ ဖြစ်သည်", term_2: "✓ ကျန်ငွေအားလုံးကို ပထမနေ့တွင် ပေးဆောင်ရမည်", term_3: "✓ အကယ်၍ သင် ပယ်ဖျက်ပြီး မလာရောက်နိုင်ပါက စရန်ငွေကို <strong>အပြည့်အဝ ပြန်အမ်းမည်</strong>", term_4: "✓ ကျွန်ုပ်တို့ဘက်မှ ပယ်ဖျက်ခ ကောက်ခံမည်မဟုတ်ပါ", payment_method: "ငွေပေးချေမှုနည်းလမ်း", pay_12: "$၁၂ စရန်ငွေပေးဆောင်မည် · အတည်ပြုမည်", deposit_security: "🔒 လုံခြုံသော ငွေပေးချေမှု · ပယ်ဖျက်ပါက ပြန်အမ်းမည်", greeting: "မင်္ဂလာပါ", active_case: "အမှု #8492 · တက်ကြွနေသည်", case_title: "Coronary Angioplasty<br>Bumrungrad တွင်", case_subtitle: "၂၃ ရက် ကျန်သေးသည် · မေလ ၁၅-၁၈၊ ၂၀၂၆", view_timeline: "အချိန်ဇယားကို ကြည့်မည်", chat_cm: "Case Manager နှင့် စကားပြောမည်", prep_docs: "စာရွက်စာတမ်းများ ပြင်ဆင်ရန်", docs_3_5: "၅ ခုအနက် ၃ ခု ပြီးစီး", travel: "ခရီးစဉ် စီစဉ်မှုများ", airport_pickup: "လေဆိပ်အကြိုအပို့ စီစဉ်ပြီး", accommodation: "တည်းခိုနေထိုင်ရေး", hotel_sukhumvit: "Grand Sukhumvit · ၄ ည", case_manager: "Case Manager", cm_pie: "Mr. Pie · ၂ နာရီအတွင်း ပြန်လည်ဖြေကြားမည်", restart: "Demo ကို ပြန်စမည်", restart_short: "ပြန်စမည်", skip_dashboard: "Dashboard သို့ ကျော်သွားမည်", modal_title: "ပထမဦးစွာ <em>သဘောတူညီချက်</em> ပေးပါ", modal_title_em: "သဘောတူညီချက်", modal_text: "ရှေ့ဆက်သွားရန် \"သဘောတူပါသည်\" ကို နှိပ်ရန် လိုအပ်ပါသည်။ ဤသည်မှာ ကျွန်ုပ်တို့နှင့် သင့်အကြား ယုံကြည်မှု တည်ဆောက်ခြင်း ဖြစ်သည်။", understood: "နားလည်ပါသည်", special_case: "အထူးကိစ္စရပ် စီမံဆောင်ရွက်ခြင်း", nomatch_title: "သင့်ကိစ္စသည် <em>အထူးဂရုပြုရန်</em> လိုအပ်ပါသည်", nomatch_title_em: "အထူးဂရုပြုရန်", nomatch_sub: "သင့်ကိစ္စသည် ကျွန်ုပ်တို့၏ စံဒေတာဘေ့စ်နှင့် မကိုက်ညီပါ။ လုံခြုံသော စကားပြောဆိုမှုမှတစ်ဆင့် သင့်ကို အထူးကုဆရာဝန်နှင့် တိုက်ရိုက် ချိတ်ဆက်ပေးပါမည်။", tg_title: "ချက်ချင်း ဆက်သွယ်နိုင်သော အဖွဲ့", tg_desc: "သင့်အတွက် သီးသန့် Telegram အဖွဲ့တစ်ခု ဖန်တီးပေးပါမည်။ ၎င်းတွင် သင်၊ ဆေးရုံအထူးကုအဖွဲ့နှင့် ကျွန်ုပ်တို့၏ Admin တို့ ပါဝင်မည် ဖြစ်သည်။", tg_f1: "ဆေးရုံအထူးကုဆရာဝန်နှင့် တိုက်ရိုက်ဆက်သွယ်နိုင်ခြင်း", tg_f2: "ကျွန်ုပ်တို့၏ Admin မှ ဘာသာပြန်ကူညီပေးခြင်း", tg_f3: "သင့်ကို ကာကွယ်ရန် ပြောဆိုမှုအားလုံးကို စောင့်ကြည့်ခြင်း", tg_f4: "တစ်ပတ်လျှင် ၇ ရက် ရရှိနိုင်ခြင်း", tg_f5: "ဆေးရုံမှ ၂၄ နာရီအတွင်း ပြန်လည်ဖြေကြားခြင်း", how_it_works: "မည်သို့ အလုပ်လုပ်သနည်း", how_steps: "၁။ အောက်ပါ \"အဖွဲ့ဖွဲ့မည်\" ကို နှိပ်ပါ<br>၂။ Telegram သို့ ရောက်ရှိသွားပါမည်<br>၃။ ကျွန်ုပ်တို့၏ Admin က သင့်လျော်သော ဆေးရုံနှင့်အတူ အဖွဲ့ဖွဲ့ပေးပါမည်<br>၄။ သင့်အကြောင်းကို တိုက်ရိုက် ဆွေးနွေးနိုင်ပါပြီ", create_tg_group: "Telegram အဖွဲ့ ဖွဲ့မည်", back_to_results: "← ဆန်းစစ်မှုသို့ ပြန်သွားမည်", tg_created_title: "စကားပြောအဖွဲ့<br><em>ဖွဲ့ပြီးပါပြီ</em>", tg_created_em: "ဖွဲ့ပြီးပါပြီ", tg_created_sub: "ဆေးရုံအထူးကုអဖွဲ့နှင့် သင့်အတွက် သီးသန့်စကားပြောခန်း អဆင်သင့် ဖြစ်ပါပြီ။", members_3: "អဖွဲ့ဝင် ៣ ဦး · តက်ကြွနေသည်", you_member: "သင် (လူနာ)", hospital_rep: "ဆေးရုံអထူးကုអဖွဲ့", admin_observer: "Medhub24 Admin (စောင့်ကြည့်သူ)", tracked: "သင့်ကို ကာကွယ်ရန် စောင့်ကြည့်နေသည်:", tracked_desc: " သင့်အကျိုးစီးပွားကို ကာကွယ်ရန် ပြောဆိုမှုအားလုံးကို ကျွန်ုပ်တို့၏ Admin က စောင့်ကြည့်ပါသည်။", open_telegram: "Telegram တွင် ဖွင့်မည်",
        confirm: "အတည်ပြုမည်",
        voice_sample: "ကမ္ဘောဒီးယားက ဆရာဝန်က ကျွန်တော့်မှာ နှလုံးသွေးကြောကျဉ်းရောဂါရှိလို့ angioplasty လုပ်ဖို့ လိုတယ်လို့ ပြောပါတယ်။ ဒုတိယထင်မြင်ချက် ရယူချင်ပြီး နိုင်ငံခြားမှာ ဆေးကုသမှု ခံယူချင်ပါတယ်။"
    },
    vi: {
        nav_home: "Trang chủ", nav_guardian: "Người bảo vệ", nav_dashboard: "Bảng điều khiển của tôi", nav_promotion: "Khuyến mãi",
        tap_start_reading: "Tôi đã sẵn sàng đọc thỏa thuận",
        tap_to_start: "Nhấn để bắt đầu giới thiệu người bảo trợ", welcome_hero: "Chăm sóc sức khỏe <em>bảo vệ</em> bạn", welcome_hero_em: "bảo vệ", welcome_sub: "Điều phối viên độc lập cho điều trị y tế xuyên biên giới.", next: "Tiếp theo", voice_title: "Hãy cho chúng tôi biết <em>mối quan tâm của bạn</em>", voice_title_em: "mối quan tâm của bạn", voice_sub: "Nói chuyện tự nhiên. AI sẽ chuyển giọng nói thành văn bản.", voice_hint: "Nhấn để bắt đầu ghi âm", voice_hint_recording: "Đang ghi... Nhấn để dừng", transcript_label: "AI Chuyển đổi", retry: "Ghi lại", edit: "Chỉnh sửa", budget_label: "Ngân sách (Tùy chọn)", timeline_label: "Khi nào bạn sẵn sàng điều trị?", analyze_btn: "Phân tích ca bệnh", analyzing_title: "Đang phân tích<br>ca bệnh", analyzing_sub: "Đối chiếu với dữ liệu bệnh viện đối tác", step_voice_received: "Đã nhận đầu vào giọng nói", step_case_categorized: "Phân loại ca bệnh", step_matching_db: "Đối chiếu cơ sở dữ liệu đối tác", step_price_range: "Ước tính khoảng giá", result_label: "Phân tích sơ bộ", result_title: "Tin tốt — ca bệnh của bạn <em>có thể điều trị</em>", result_title_em: "có thể điều trị", result_sub: "Tổng quan ban đầu.", diagnosis_label: "Đánh giá sơ bộ", diagnosis_desc: "Nong mạch vành với đặt stent", recommended_country: "Quốc gia được khuyến nghị", thailand_first: "Thái Lan (Chính)", price_range: "Khoảng giá ước tính", treatment_duration: "Thời gian điều trị", days_3_5: "3-5 ngày", recovery_time: "Thời gian phục hồi", weeks_2: "2 tuần", disclaimer_title: "Về ước tính này", disclaimer_text: "Ước tính dựa trên dữ liệu quy trình tiêu chuẩn từ bệnh viện đối tác. <strong>Giá không bao gồm biến chứng, dụng cụ y tế đặc biệt hoặc phụ kiện có thể phát sinh.</strong>", book_call: "Lịch tư vấn video", consult_free: "Gọi video 30 phút · Miễn phí", no_match_link: "Ca bệnh không khớp? Nhắn tin trực tiếp →", booking_label: "Lịch trình · Cấp 2", book_title: "Chọn thời gian <em>phù hợp</em>", book_title_em: "phù hợp", book_sub: "Gặp Quản lý ca bệnh qua video để thảo luận chi tiết.", day_tue: "T.Hai", day_wed: "T.Ba", day_thu: "T.Tư", day_fri: "T.Năm", time_label: "Khung giờ", confirm_time: "Xác nhận lịch", guardian_label: "Thỏa thuận Người bảo trợ", guardian_title: "Trước khi chúng ta<br>làm việc cùng nhau", guardian_sub: "Chúng tôi muốn bạn hiểu rõ cách chúng tôi làm việc <strong>vì bạn</strong>.", four_parts: "Bốn phần", part1_name: "1. Quyền lợi", part1_tag: "Với tư cách bệnh nhân", part2_name: "2. Nhiệm vụ", part2_tag: "Với tư cách Điều phối viên", part3_name: "3. Hợp tác", part3_tag: "90 Ngày", part4_name: "4. Quyền rút lui", part4_tag: "Bất cứ lúc nào", important: "Quan trọng", tap_intro: "Không tài liệu. Không chữ ký. Chỉ đọc và nhấn đồng ý.", start_reading: "Bắt đầu đọc", part_1_of_4: "Phần 1/4", part_2_of_4: "Phần 2/4", part_3_of_4: "Phần 3/4", part_4_of_4: "Phần 4/4", rights_title: "Quyền lợi của bạn<br><em>với tư cách bệnh nhân</em>", rights_title_em: "với tư cách bệnh nhân", rights_sub: "Chúng tôi bảo vệ những điều này cho bạn", right_1: "<strong>Hướng dẫn trung thực</strong> — Chúng tôi đề xuất bệnh viện phù hợp nhất với ca bệnh của bạn.", right_2: "<strong>Giá minh bạch</strong> — Bạn thấy giá thực tế, không phí ẩn.", right_3: "<strong>Bảo vệ khi phát sinh vấn đề</strong> — Nếu bệnh viện tính sai hoặc sai lệch phác đồ, chúng tôi bảo vệ bạn.", right_4: "<strong>Hỗ trợ sau điều trị</strong> — 90 ngày theo dõi, phối hợp thuốc và ý kiến thứ hai.", tap_rights: "Tôi hiểu quyền lợi", tap_acknowledge: "Nhấn để xác nhận", duties_title: "Nhiệm vụ của chúng tôi<br><em>với bạn</em>", duties_title_em: "với bạn", duties_sub: "Nếu chúng tôi vi phạm, bạn có thể rời đi ngay lập tức", duty_1: "<strong>Thông tin trung thực</strong> — Ngay cả khi sự thật không phải điều bạn muốn nghe.", duty_2: "<strong>Đại diện vì bạn</strong> — Sử dụng mối quan hệ bệnh viện để có gói chăm sóc tốt nhất.", duty_3: "<strong>Bảo vệ quyền riêng tư</strong> — Thông tin y tế được bảo mật tuyệt đối.", duty_4: "<strong>Đảm bảo dịch vụ</strong> — Nếu dịch vụ hỗ trợ không đạt chuẩn, chúng tôi hoàn phí điều phối.", tap_duties: "Hãy chịu trách nhiệm", tap_accountable: "Chúng tôi chấp nhận trách nhiệm", commit_title: "Hợp tác<br><em>90 Ngày</em>", commit_title_em: "90 Ngày", commit_sub: "Điều chúng tôi mong đợi để làm việc hiệu quả", commit_1: "<strong>Hợp tác 90 ngày</strong> — Để chúng tôi đàm phán tốt nhất cho bạn.", commit_2: "<strong>Báo trước khi quyết định</strong> — Nếu muốn đổi bệnh viện, hãy cho chúng tôi biết.", commit_3: "<strong>Lịch sử y tế chính xác</strong> — Thông tin đúng giúp chúng tôi tư vấn chính xác.", commit_4: "<strong>Phản hồi trung thực</strong> — Chia sẻ trải nghiệm để chúng tôi cải thiện.", note: "Lưu ý:", commit_note: "\"90 ngày\" tính từ ngày bắt đầu làm việc, không phải ràng buộc trọn đời.", tap_commit: "Tôi đồng ý cam kết", tap_together: "Chúng ta cùng đồng hành", exit_title: "Quyền rút lui<br><em>của bạn</em>", exit_title_em: "của bạn", exit_sub: "Quan trọng nhất — bạn có thể rời đi bất cứ lúc nào", exit_1: "<strong>Không phí hủy</strong> — Rời đi bất cứ lúc nào mà không bị phạt.", exit_2: "<strong>Dữ liệu thuộc về bạn</strong> — Nếu hủy, chúng tôi xóa dữ liệu y tế trong 7 ngày.", exit_3: "<strong>Hoàn tiền đặt cọc hỗ trợ</strong> — Nếu hủy trước điều trị, tiền đặt cọc 10% được hoàn toàn.", exit_4: "<strong>Không ràng buộc bệnh viện</strong> — Bạn có thể tìm nơi khác ngay cả khi hủy với chúng tôi.", exit_quote: "\"Chúng tôi kiếm niềm tin bằng việc làm tốt — không phải bằng cách khóa bạn lại.\"", tap_exit: "Tôi hiểu và đồng ý tất cả", tap_final: "Xác nhận cuối cùng", confirm_agreement: "Xác nhận Thỏa thuận", welcome_inner: "Chào mừng bạn vào<br><em>Vòng tròn Nội bộ</em>", welcome_inner_em: "Vòng tròn Nội bộ", welcome_inner_sub: "Chúng tôi đang làm việc vì bạn. Đã mở khóa toàn bộ thông tin.", now_access: "Bạn đã có quyền truy cập", access_1: "✓ Tên và chi tiết bệnh viện", access_2: "✓ Giá đã đàm phán", access_3: "✓ Chuyên gia được đề xuất", access_4: "✓ Liên hệ trực tiếp với Quản lý ca", view_hospitals: "Xem bệnh viện được đề xuất", full_disclosure_label: "Tiết lộ đầy đủ · Cấp 3", hospitals_title: "3 Lựa chọn <em>chúng tôi đề xuất</em>", hospitals_title_em: "chúng tôi đề xuất", hospitals_sub: "Dựa trên 15 năm kinh nghiệm thị trường.", estimate_note_title: "Lưu ý ước tính giá", estimate_note_text: "Giá cho quy trình tiêu chuẩn. <strong>Không bao gồm biến chứng hoặc phụ kiện y tế đặc biệt.</strong>", recommended_tag: "Đề xuất", alternative_tag: "Thay thế", budget_tag: "Tiết kiệm", partner_price: "Giá đối tác", duration: "Thời gian", days_4: "4 ngày", days_5: "5 ngày", walk_in: "Giá niêm yết", select_bumrungrad: "Chọn Bumrungrad", care_level_label: "Mức hỗ trợ chăm sóc", care_title: "Chọn <em>hỗ trợ chăm sóc</em> của bạn", care_title_em: "hỗ trợ chăm sóc", care_sub: "Đây là dịch vụ hỗ trợ. Tiền điều trị y tế thanh toán riêng cho bệnh viện.", basic_name: "Điều phối cơ bản", basic_price: "Đã bao gồm", basic_f1: "Đặt lịch hẹn bệnh viện", basic_f2: "Phiên dịch viên bệnh viện (cơ bản)", basic_f3: "Thông tin tiền hành trình", standard_name: "Chăm sóc Tiêu chuẩn", standard_price: "$30 / ngày", std_f1: "Phiên dịch chuyên trách tại bệnh viện (8:00 – 16:00)", std_f2: "Xe đưa đón sân bay (đến & đi)", std_f3: "Hỗ trợ đặt khách sạn nếu cần", std_f4: "Điều phối tại chỗ trong khi điều trị", std_f5: "Gói chăm sóc trọn gói một lần", premium_name: "Cao cấp Bảo trợ", premium_price: "$120 trọn gói", prem_f1: "Tất cả tính năng Chăm sóc Tiêu chuẩn", prem_f2: "Theo dõi sau điều trị 90 ngày", prem_f3: "Ưu tiên truy cập Quản lý ca bệnh", prem_f4: "Ý kiến thứ hai nếu phát sinh triệu chứng", prem_f5: "Cập nhật cho gia đình bằng ngôn ngữ của bạn", concierge_name: "Concierge Toàn diện", concierge_price: "$350 trọn gói", conc_f1: "Tất cả tính năng Cao cấp", conc_f2: "Quản lý ca bệnh đi cùng thực tế", conc_f3: "Báo cáo gia đình hàng ngày", conc_f4: "Theo dõi mở rộng 6 tháng", confirm_standard: "Xác nhận Chăm sóc Tiêu chuẩn", confirm_booking: "Xác nhận Đặt lịch", booking_final_title: "Bước cuối — <em>chỉ đặt cọc chăm sóc</em>", booking_final_em: "chỉ đặt cọc chăm sóc", booking_final_sub: "Bạn chỉ thanh toán một khoản đặt cọc nhỏ cho dịch vụ hỗ trợ.", hospital: "Bệnh viện", doctor: "Chuyên gia", treatment_date: "Ngày điều trị", may_15_18: "15-18 tháng 5, 2026", care_package: "Hỗ trợ chăm sóc", standard_4days: "Tiêu chuẩn · 4 ngày", medical_section: "Điều trị y tế", treatment_fee: "Gói điều trị", pay_to: "Thanh toán cho", hospital_direct: "Bệnh viện trực tiếp", pay_when: "Thời điểm thanh toán", first_day: "Ngày đầu điều trị", no_medical_deposit: "✓ Không yêu cầu đặt cọc điều trị y tế", care_deposit_title: "Đặt cọc chăm sóc", service_total: "Tổng Chăm sóc Tiêu chuẩn (4 ngày × $30)", deposit_10: "Đặt cọc (10% hôm nay)", balance_on_day1: "Số dư ngày điều trị đầu tiên", deposit_terms_title: "Điều khoản đặt cọc", term_1: "✓ Đặt cọc chỉ áp dụng cho dịch vụ hỗ trợ", term_2: "✓ Thanh toán số dư vào ngày điều trị đầu tiên", term_3: "✓ Nếu bạn hủy và không thể tham gia, tiền đặt cọc <strong>được hoàn lại toàn bộ</strong>", term_4: "✓ Không phí hủy từ phía chúng tôi", payment_method: "Phương thức thanh toán", pay_12: "Thanh toán $12 Đặt cọc · Xác nhận", deposit_security: "🔒 Thanh toán an toàn · Hoàn tiền nếu hủy", greeting: "Xin chào", active_case: "Ca #8492 · Hoạt động", case_title: "Nong mạch vành<br> tại Bumrungrad", case_subtitle: "Còn 23 ngày · 15-18 tháng 5, 2026", view_timeline: "Xem tiến trình", chat_cm: "Nhắn CM", prep_docs: "Chuẩn bị hồ sơ", docs_3_5: "3/5 hoàn tất", travel: "Sắp xếp du lịch", airport_pickup: "Đón sân bay đã xong", accommodation: "Lưu trú", hotel_sukhumvit: "Grand Sukhumvit · 4 đêm", case_manager: "Quản lý ca bệnh", cm_pie: "Mr. Pie · Phản hồi trong 2 giờ", restart: "Chạy lại Demo", restart_short: "Lại", skip_dashboard: "Bỏ qua Dashboard", modal_title: "Vui lòng <em>đồng ý</em> trước", modal_title_em: "đồng ý", modal_text: "Bạn cần nhấn \"Đồng ý\" trước khi tiếp tục.", understood: "Đã hiểu", special_case: "Xử lý ca đặc biệt", nomatch_title: "Ca bệnh cần <em>sự quan tâm đặc biệt</em>", nomatch_title_em: "sự quan tâm đặc biệt", nomatch_sub: "Ca bệnh của bạn không khớp với dữ liệu chuẩn. Hãy kết nối trực tiếp với chuyên gia qua kênh chat bảo mật.", tg_title: "Nhóm Chat Một cửa", tg_desc: "Chúng tôi sẽ tạo một nhóm Telegram riêng gồm bạn, chuyên gia bệnh viện và Admin của chúng tôi.", tg_f1: "Truy cập trực tiếp chuyên gia bệnh viện", tg_f2: "Hỗ trợ phiên dịch bởi Admin", tg_f3: "Theo dõi hội thoại để bảo vệ quyền lợi của bạn", tg_f4: "Hoạt động 7 ngày/tuần", tg_f5: "Phản hồi trong 24 giờ từ bệnh viện", how_it_works: "Cách hoạt động", how_steps: "1. Nhấn \"Tạo Chat\" bên dưới<br>2. Chuyển hướng đến Telegram<br>3. Admin tạo nhóm với bệnh viện phù hợp<br>4. Bắt đầu thảo luận trực tiếp", create_tg_group: "Tạo nhóm Telegram", back_to_results: "← Quay lại Phân tích", tg_created_title: "Nhóm Chat<br><em>đã tạo</em>", tg_created_em: "đã tạo", tg_created_sub: "Nhóm chat riêng với chuyên gia bệnh viện đã sẵn sàng.", members_3: "3 thành viên · Hoạt động", you_member: "Bạn (Bệnh nhân)", hospital_rep: "Đội ngũ chuyên gia bệnh viện", admin_observer: "Admin Medhub24 (Quan sát)", tracked: "Theo dõi để bảo vệ bạn:", tracked_desc: " Mọi cuộc trò chuyện đều được Admin giám sát để đảm bảo giá công bằng.", open_telegram: "Mở Telegram",
        confirm: "Xác nhận",
        voice_sample: "Bác sĩ ở Campuchia nói tôi bị bệnh động mạch vành và cần nong mạch. Tôi muốn lấy ý kiến thứ hai và điều trị ở nước ngoài."
    },
    zh: {
        nav_home: "首页", nav_guardian: "守护者", nav_dashboard: "我的仪表板", nav_promotion: "促销活动",
        tap_start_reading: "我已准备好阅读协议",
        tap_to_start: "点击开始阅读守护者简介", welcome_hero: "为您提供<em>守护</em>的医疗服务", welcome_hero_em: "守护", welcome_sub: "您的独立跨境医疗协调员。我们为您工作，而非医院。", next: "下一步", voice_title: "请告诉我们可以<em>如何帮助您</em>", voice_title_em: "如何帮助您", voice_sub: "用您的母语自然表达。我们的 AI 会将语音转为文字并分析您的病例。无需打字。", voice_hint: "点击开始录音", voice_hint_recording: "录音中... 点击停止", transcript_label: "AI 转录", retry: "重新录音", edit: "编辑文本", budget_label: "预算范围（可选）", timeline_label: "您何时准备好接受治疗？", analyze_btn: "分析我的病例", analyzing_title: "正在分析<br>您的病例", analyzing_sub: "与合作医院数据库交叉比对", step_voice_received: "语音输入已接收", step_case_categorized: "病例已分类", step_matching_db: "匹配合作数据库", step_price_range: "估算价格范围", result_label: "初步分析", result_title: "好消息 — 您的病例<em>可以治疗</em>", result_title_em: "可以治疗", result_sub: "这是初步概况。医院名称和医生详情将在我们的视频通话后揭晓。", diagnosis_label: "初步评估", diagnosis_desc: "冠状动脉球囊扩张及支架植入术", recommended_country: "推荐国家", thailand_first: "泰国（首选）", price_range: "预估价格范围", treatment_duration: "治疗时长", days_3_5: "3-5 天", recovery_time: "恢复时间", weeks_2: "2 周", disclaimer_title: "关于此估算", disclaimer_text: "此估算基于合作医院的标准程序数据。<strong>价格不包含并发症、特殊医疗器械或治疗期间可能需要的配件。</strong> 最终价格将在现场评估后确认。", book_call: "预约视频咨询", consult_free: "30分钟视频通话 · 免费", no_match_link: "病例不匹配？直接沟通 →", booking_label: "预约 · 第2阶段", book_title: "选择<em>合适</em>的时间", book_title_em: "合适", book_sub: "通过视频通话与您的个案经理深入讨论病情。", day_tue: "周二", day_wed: "周三", day_thu: "周四", day_fri: "周五", time_label: "时间段", confirm_time: "确认时间", guardian_label: "守护者协议", guardian_title: "在我们<br>合作之前", guardian_sub: "我们希望您清楚了解我们<strong>如何为您</strong>工作 — 以及我们的相互要求。", four_parts: "四个部分", part1_name: "1. 您的权利", part1_tag: "作为患者", part2_name: "2. 我们的义务", part2_tag: "作为协调员", part3_name: "3. 合作期", part3_tag: "90 天", part4_name: "4. 退出权利", part4_tag: "随时", important: "重要提示", tap_intro: "无需文件。无需签名。只需阅读每部分并点击同意。", start_reading: "开始阅读", part_1_of_4: "第 1/4 部分", part_2_of_4: "第 2/4 部分", part_3_of_4: "第 3/4 部分", part_4_of_4: "第 4/4 部分", rights_title: "您的权利<br><em>作为患者</em>", rights_title_em: "作为患者", rights_sub: "我们为您保护这些权益", right_1: "<strong>诚实指导</strong> — 我们推荐最适合您病情的医院，而非给我们回扣最高的。", right_2: "<strong>价格透明</strong> — 您看到真实价格，无隐藏费用。", right_3: "<strong>问题保护</strong> — 若医院多收费或治疗偏离约定方案，我们为您维权。", right_4: "<strong>术后支持</strong> — 90 天随访、药物协调及第二诊疗意见。", tap_rights: "我理解我的权利", tap_acknowledge: "点击确认", duties_title: "我们的义务<br><em>对您</em>", duties_title_em: "对您", duties_sub: "若我们违反，您可立即终止合作", duty_1: "<strong>真实信息</strong> — 即使真相不是您想听的，我们绝不推销不必要的治疗。", duty_2: "<strong>为您代言</strong> — 利用医院关系为您争取最佳护理方案。", duty_3: "<strong>保护隐私</strong> — 您的医疗信息严格保密，未经同意绝不共享。", duty_4: "<strong>服务保证</strong> — 若护理支持未达标，我们退还服务协调费。", tap_duties: "请我们负责", tap_accountable: "我们承担责任", commit_title: "携手合作<br><em>90 天</em>", commit_title_em: "90 天", commit_sub: "为让我们更好工作，希望您配合", commit_1: "<strong>90天内通过我们办理</strong> — 以便我们为您谈判，而非内部竞争。", commit_2: "<strong>决定前告知我们</strong> — 若需更换医院或方案，先告诉我们。", commit_3: "<strong>准确病史</strong> — 正确信息帮助我们推荐合适的护理。", commit_4: "<strong>诚实反馈</strong> — 治疗后分享体验，助我们改进。", note: "注意：", commit_note: "\"90天\"从开始合作之日起算，非终身绑定。", tap_commit: "我接受此承诺", tap_together: "我们并肩同行", exit_title: "您的退出<br><em>权利</em>", exit_title_em: "权利", exit_sub: "最重要的一点 — 您可随时退出", exit_1: "<strong>无取消费</strong> — 随时退出，零罚款。", exit_2: "<strong>数据属于您</strong> — 若取消，7 天内彻底删除医疗数据。", exit_3: "<strong>护理支持押金可退</strong> — 若治疗前取消，10% 服务费押金全额退还。", exit_4: "<strong>无医院绑定</strong> — 即使取消与我们合作，您仍可前往其他医院。", exit_quote: "\"我们靠优质服务赢得信任 — 而非靠合同绑定您。\"", tap_exit: "我理解并同意全部条款", tap_final: "最终确认", confirm_agreement: "确认守护者协议", welcome_inner: "欢迎进入<br><em>核心圈层</em>", welcome_inner_em: "核心圈层", welcome_inner_sub: "我们现已全力为您服务。已解锁全部信息权限。", now_access: "您现在可访问", access_1: "✓ 医院名称及详情", access_2: "✓ 协议优惠价格", access_3: "✓ 推荐专家医生", access_4: "✓ 个案经理直联", view_hospitals: "查看推荐医院", full_disclosure_label: "完全公开 · 第3阶段", hospitals_title: "我们推荐的<em>3 个选项</em>", hospitals_title_em: "我们推荐的", hospitals_sub: "基于15年市场经验。", estimate_note_title: "价格估算说明", estimate_note_text: "价格为标准程序费用。<strong>不包含并发症或特殊医疗器械配件。</strong>", recommended_tag: "推荐", alternative_tag: "备选", budget_tag: "经济选项", partner_price: "协议价", duration: "时长", days_4: "4 天", days_5: "5 天", walk_in: "门市价", select_bumrungrad: "选择 Bumrungrad", care_level_label: "护理支持级别", care_title: "选择您的<em>护理支持</em>", care_title_em: "护理支持", care_sub: "这些是护理支持服务。医疗费用需直接支付给医院。", basic_name: "基础协调", basic_price: "已包含", basic_f1: "医院预约协助", basic_f2: "医院工作人员翻译（基础）", basic_f3: "行前基础信息", standard_name: "标准护理", standard_price: "$30 / 天", std_f1: "医院专属翻译（08:00 – 16:00）", std_f2: "机场接送（抵达与返程）", std_f3: "必要时协助预订酒店", std_f4: "治疗期间全程地面协调", std_f5: "一次性完整护理包", premium_name: "高级护航", premium_price: "$120 固定", prem_f1: "包含所有标准护理功能", prem_f2: "术后 90 天随访", prem_f3: "个案经理优先接入", prem_f4: "出现症状时提供第二诊疗意见", prem_f5: "用您的语言向家属同步进展", concierge_name: "全托管尊享", concierge_price: "$350 固定", conc_f1: "包含所有高级功能", conc_f2: "个案经理实地陪同", conc_f3: "每日家属简报", conc_f4: "6 个月延长随访", confirm_standard: "确认标准护理", confirm_booking: "确认预约", booking_final_title: "最后一步 — <em>仅付护理押金</em>", booking_final_em: "仅付护理押金", booking_final_sub: "您只需为我们的护理支持服务支付少量押金。", hospital: "医院", doctor: "专家", treatment_date: "治疗日期", may_15_18: "2026年5月15-18日", care_package: "护理支持", standard_4days: "标准 · 4 天", medical_section: "医疗治疗", treatment_fee: "治疗套餐", pay_to: "支付对象", hospital_direct: "直接付给医院", pay_when: "付款时间", first_day: "治疗首日", no_medical_deposit: "✓ 医疗治疗无需押金", care_deposit_title: "护理支持押金", service_total: "标准护理总计 (4 天 × $30)", deposit_10: "押金 (今日 10%)", balance_on_day1: "首日结算尾款", deposit_terms_title: "押金条款", term_1: "✓ 押金仅适用于护理支持服务", term_2: "✓ 尾款于治疗首日结清", term_3: "✓ 若您取消且无法出席，押金<strong>全额可退</strong>", term_4: "✓ 我方不收取取消费", payment_method: "支付方式", pay_12: "支付 $12 押金 · 确认预约", deposit_security: "🔒 安全支付 · 取消可退", greeting: "您好", active_case: "病例 #8492 · 活跃中", case_title: "冠状动脉成形术<br>于 Bumrungrad", case_subtitle: "剩余 23 天 · 2026年5月15-18日", view_timeline: "查看时间线", chat_cm: "联系个案经理", prep_docs: "准备文件", docs_3_5: "已完成 3/5", travel: "行程安排", airport_pickup: "已安排机场接送", accommodation: "住宿安排", hotel_sukhumvit: "Grand Sukhumvit · 4 晚", case_manager: "个案经理", cm_pie: "Pie 先生 · 2 小时内回复", restart: "重新开始演示", restart_short: "重开", skip_dashboard: "跳至仪表盘", modal_title: "请先<em>同意</em>", modal_title_em: "同意", modal_text: "您需要点击“同意”框才能继续。", understood: "明白了", special_case: "特殊病例处理", nomatch_title: "您的病例需要<em>专人关注</em>", nomatch_title_em: "专人关注", nomatch_sub: "您的病例不在标准数据库中。", tg_title: "一站式聊天群", tg_desc: "我们将创建专属 Telegram 群组，包含您、医院专家团队及我方管理员。", tg_f1: "直连医院专家", tg_f2: "管理员提供翻译协助", tg_f3: "全程聊天记录受监控以保护您的权益", tg_f4: "每周 7 天可用", tg_f5: "医院 24 小时内响应", how_it_works: "操作流程", how_steps: "1. 点击下方的“创建聊天”<br>2. 跳转至 Telegram<br>3. 管理员拉入对应医院<br>4. 直接讨论您的病情", create_tg_group: "创建 Telegram 群组", back_to_results: "← 返回分析", tg_created_title: "聊天群组<br><em>已创建</em>", tg_created_em: "已创建", tg_created_sub: "您与医院专家团队的专属聊天已就绪。", members_3: "3 名成员 · 活跃", you_member: "您 (患者)", hospital_rep: "医院专家团队", admin_observer: "Medhub24 管理员 (观察员)", tracked: "为您的安全全程监控：", tracked_desc: " 所有对话均由管理员监督，确保定价公平并保护您的利益。", open_telegram: "打开 Telegram", voice_sample: "柬埔寨医生说我患有冠心病，需要做球囊扩张术。我想寻求第二诊疗意见并出国治疗。"
    }
};
const extraTranslations = {
    en: {
        nav_note: "Note",
        nav_price: "Price",
        fb_gate_label: "Facebook access required",
        fb_gate_title: "Join the group and follow the page first",
        fb_gate_desc: "Before viewing the next step, the user must join your Facebook group and follow your Facebook page. The continue button unlocks only after both confirmations are checked.",
        fb_join_group: "Join Facebook Group",
        fb_join_group_check: "I joined the Facebook group.",
        fb_follow_page: "Follow Facebook Page",
        fb_follow_page_check: "I followed the Facebook page.",
        fb_open_direct: "Opens directly in Facebook",
        fb_done_short: "Done",
        fb_gate_status_default: "Complete both Facebook actions to unlock the next step.",
        fb_gate_status_partial: "Open both Facebook links and confirm both actions to unlock the next step.",
        fb_gate_status_ready: "Facebook requirements completed. You can continue to the next page.",
        fb_gate_continue: "See Your Matching Hospitals Based on Your Symptoms",
        fb_gate_continue_hint: "Continue to your curated hospital matches and trust details"
    },
    km: {
        nav_note: "ចំណាំ",
        nav_price: "តម្លៃ",
        fb_gate_label: "តម្រូវឱ្យចូល Facebook ជាមុន",
        fb_gate_title: "សូមចូលក្រុម និង Follow ទំព័រជាមុនសិន",
        fb_gate_desc: "មុនពេលមើលជំហានបន្ទាប់ អ្នកប្រើត្រូវចូលជាសមាជិកក្រុម Facebook និង Follow ទំព័រ Facebook របស់អ្នកជាមុនសិន។ ប៊ូតុងបន្តនឹងដោះសោ បន្ទាប់ពីបញ្ជាក់ទាំងពីររួចរាល់។",
        fb_join_group: "ចូលក្រុម Facebook",
        fb_join_group_check: "ខ្ញុំបានចូលជាសមាជិកក្រុម Facebook រួចហើយ។",
        fb_follow_page: "Follow ទំព័រ Facebook",
        fb_follow_page_check: "ខ្ញុំបាន Follow ទំព័រ Facebook រួចហើយ។",
        fb_open_direct: "បើកដោយផ្ទាល់ក្នុង Facebook",
        fb_done_short: "រួចហើយ",
        fb_gate_status_default: "សូមបំពេញសកម្មភាព Facebook ទាំងពីរ ដើម្បីដោះសោជំហានបន្ទាប់។",
        fb_gate_status_partial: "សូមបើកតំណ Facebook ទាំងពីរ ហើយបញ្ជាក់ទាំងពីរ ដើម្បីដោះសោជំហានបន្ទាប់។",
        fb_gate_status_ready: "បានបំពេញតម្រូវការ Facebook រួចរាល់។ អ្នកអាចបន្តទៅទំព័របន្ទាប់បាន។",
        fb_gate_continue: "មើលមន្ទីរពេទ្យដែលផ្គូផ្គងតាមរោគសញ្ញារបស់អ្នក",
        fb_gate_continue_hint: "បន្តទៅការផ្គូផ្គងមន្ទីរពេទ្យ និងព័ត៌មានទំនុកចិត្តរបស់អ្នក"
    },
    my: {
        nav_note: "မှတ်စု",
        nav_price: "စျေးနှုန်း",
        fb_gate_label: "Facebook ဝင်ရောက်မှု လိုအပ်သည်",
        fb_gate_title: "Group ကို join လုပ်ပြီး Page ကို follow လုပ်ပါ",
        fb_gate_desc: "နောက်တစ်ဆင့်ကို မကြည့်မီ အသုံးပြုသူသည် သင့် Facebook group ထဲဝင်ပြီး သင့် Facebook page ကို follow လုပ်ရပါမည်။ အတည်ပြုချက် နှစ်ခုစလုံး ပြီးမှ ဆက်သွားရန် button ကို ဖွင့်ပေးပါမည်။",
        fb_join_group: "Facebook Group Join လုပ်ရန်",
        fb_join_group_check: "ကျွန်ုပ် Facebook group ကို join လုပ်ပြီးပါပြီ။",
        fb_follow_page: "Facebook Page Follow လုပ်ရန်",
        fb_follow_page_check: "ကျွန်ုပ် Facebook page ကို follow လုပ်ပြီးပါပြီ။",
        fb_open_direct: "Facebook တွင် တိုက်ရိုက်ဖွင့်မည်",
        fb_done_short: "ပြီးပြီ",
        fb_gate_status_default: "နောက်တစ်ဆင့်ကို ဖွင့်ရန် Facebook လုပ်ဆောင်ချက် နှစ်ခုစလုံး ပြီးအောင်လုပ်ပါ။",
        fb_gate_status_partial: "Facebook link နှစ်ခုစလုံးကို ဖွင့်ပြီး အတည်ပြုချက် နှစ်ခုစလုံးကို အမှန်ခြစ်ပါ။",
        fb_gate_status_ready: "Facebook လိုအပ်ချက်များ ပြည့်စုံပါပြီ။ နောက်စာမျက်နှာသို့ ဆက်သွားနိုင်ပါသည်။",
        fb_gate_continue: "သင့်ရောဂါလက္ခဏာအပေါ် အခြေခံသော ကိုက်ညီသည့် ဆေးရုံများကို ကြည့်ရန်",
        fb_gate_continue_hint: "သင့်အတွက်ရွေးချယ်ထားသော ဆေးရုံများနှင့် ယုံကြည်မှုအချက်အလက်များကို ဆက်လက်ကြည့်ရှုပါ"
    },
    vi: {
        nav_note: "Ghi chú",
        nav_price: "Giá",
        fb_gate_label: "Yêu cầu Facebook",
        fb_gate_title: "Hãy tham gia nhóm và theo dõi trang trước",
        fb_gate_desc: "Trước khi xem bước tiếp theo, người dùng phải tham gia nhóm Facebook và theo dõi trang Facebook của bạn. Nút tiếp tục chỉ được mở khi cả hai xác nhận đã hoàn tất.",
        fb_join_group: "Tham gia nhóm Facebook",
        fb_join_group_check: "Tôi đã tham gia nhóm Facebook.",
        fb_follow_page: "Theo dõi trang Facebook",
        fb_follow_page_check: "Tôi đã theo dõi trang Facebook.",
        fb_open_direct: "Mở trực tiếp trong Facebook",
        fb_done_short: "Xong",
        fb_gate_status_default: "Hoàn tất cả hai hành động trên Facebook để mở bước tiếp theo.",
        fb_gate_status_partial: "Hãy mở cả hai liên kết Facebook và xác nhận cả hai hành động để mở bước tiếp theo.",
        fb_gate_status_ready: "Đã hoàn tất yêu cầu Facebook. Bạn có thể tiếp tục sang trang tiếp theo.",
        fb_gate_continue: "Xem các bệnh viện phù hợp theo triệu chứng của bạn",
        fb_gate_continue_hint: "Tiếp tục để xem các bệnh viện đã được chọn lọc và thông tin tạo niềm tin"
    },
    zh: {
        nav_note: "笔记",
        nav_price: "价格",
        fb_gate_label: "需要先完成 Facebook 步骤",
        fb_gate_title: "请先加入群组并关注主页",
        fb_gate_desc: "在查看下一步之前，用户必须先加入您的 Facebook 群组并关注您的 Facebook 主页。只有两项确认都完成后，继续按钮才会解锁。",
        fb_join_group: "加入 Facebook 群组",
        fb_join_group_check: "我已加入 Facebook 群组。",
        fb_follow_page: "关注 Facebook 主页",
        fb_follow_page_check: "我已关注 Facebook 主页。",
        fb_open_direct: "直接在 Facebook 中打开",
        fb_done_short: "完成",
        fb_gate_status_default: "请完成两个 Facebook 操作后再解锁下一步。",
        fb_gate_status_partial: "请打开两个 Facebook 链接并确认两项操作，才能解锁下一步。",
        fb_gate_status_ready: "Facebook 要求已完成。您现在可以继续下一页。",
        fb_gate_continue: "查看基于您症状匹配的医院",
        fb_gate_continue_hint: "继续查看为您筛选的医院匹配结果和信任信息"
    }
};
Object.keys(extraTranslations).forEach(lang => {
    translations[lang] = { ...(translations[lang] || {}), ...extraTranslations[lang] };
});
// ============= CORE FUNCTIONS =============
function autoDetectLang() {
    switchLang('en');
}
function toggleLangDropdown(forceOpen) {
    const dropdown = document.getElementById('lang-dropdown');
    const button = document.getElementById('lang-btn');
    if (!dropdown || !button) return;
    const shouldOpen = typeof forceOpen === 'boolean' ? forceOpen : !dropdown.classList.contains('open');
    dropdown.classList.toggle('open', shouldOpen);
    button.setAttribute('aria-expanded', shouldOpen ? 'true' : 'false');
}
function switchLang(lang) {
    const nextLang = translations[lang] ? lang : 'en';
    const langSet = translations[nextLang] || translations.en;
    currentLang = nextLang;
    document.documentElement.lang = nextLang;
    document.querySelectorAll('[data-i18n]').forEach(el => {
        const key = el.getAttribute('data-i18n');
        const text = langSet[key] || translations.en[key];
        if (text) el.innerHTML = text;
    });
    const langCode = document.querySelector('.lang-text-code');
    if (langCode) langCode.textContent = nextLang.toUpperCase();
    document.querySelectorAll('.lang-option').forEach(option => {
        const active = option.getAttribute('data-lang') === nextLang;
        option.classList.toggle('active', active);
        option.setAttribute('aria-selected', active ? 'true' : 'false');
    });
    toggleLangDropdown(false);
    refreshCoordinationPreviewLabels();
    updateDepositUI();
    updateFacebookGate();
}

function getCoordinationPreviewLabel(expanded) {
    const labelSet = COORD_PREVIEW_LABELS[currentLang] || COORD_PREVIEW_LABELS.en;
    return expanded ? labelSet.unpreview : labelSet.preview;
}

function refreshCoordinationPreviewLabels() {
    document.querySelectorAll('[data-coord-card]').forEach(card => {
        const expanded = card.classList.contains('is-open');
        const button = card.querySelector('.quick-action-preview-btn');
        const label = card.querySelector('.quick-action-preview-label');
        if (button) button.setAttribute('aria-expanded', expanded ? 'true' : 'false');
        if (label) label.textContent = getCoordinationPreviewLabel(expanded);
    });
}

function focusCoordinationCard(card) {
    const cards = Array.from(document.querySelectorAll('[data-coord-card]'));
    if (!cards.length || !card) return;
    cards.forEach(item => {
        const panel = item.querySelector('.quick-action-preview');
        const isTarget = item === card;
        item.classList.toggle('is-active', isTarget);
        if (!isTarget) {
            item.classList.remove('is-open');
            if (panel) panel.hidden = true;
        }
    });
    refreshCoordinationPreviewLabels();
}

function toggleCoordinationPreview(card) {
    const cards = Array.from(document.querySelectorAll('[data-coord-card]'));
    if (!cards.length || !card) return;

    const shouldOpen = !card.classList.contains('is-open');

    cards.forEach(item => {
        const open = item === card ? shouldOpen : false;
        const panel = item.querySelector('.quick-action-preview');
        item.classList.toggle('is-active', item === card);
        item.classList.toggle('is-open', open);
        if (panel) panel.hidden = !open;
    });

    refreshCoordinationPreviewLabels();

    if (shouldOpen) {
        card.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }
}

function initCoordinationCards() {
    const cards = Array.from(document.querySelectorAll('[data-coord-card]'));
    if (!cards.length) return;

    cards.forEach((card, index) => {
        const panel = card.querySelector('.quick-action-preview');
        card.classList.toggle('is-active', index === 0);
        card.classList.remove('is-open');
        if (panel) panel.hidden = true;
    });

    refreshCoordinationPreviewLabels();
}
/* =============================================================================
   REMOVED: legacy Price v2 state machine
   The active production Price workflow is the pc3 module on #screen-20.
   See docs/ARCHITECTURE.md and the pc3 module below for current data flow.
   ============================================================================= */

function captureMatchJourneyTemplate() {
    const rail = document.getElementById('ip-journey-track');
    const drawer = document.getElementById('ip-drawer-timeline');
    if (!rail || !drawer) return;
    matchJourneyTemplate = {
        rail: rail.innerHTML,
        drawer: drawer.innerHTML
    };
}

function buildAccountJourneyAction(step, closeDrawer = false) {
    const action = step.key === 'ai-scan'
        ? 'goTo(21)'
        : `scrollToAccountSection('${step.key}')`;
    return closeDrawer ? `${action};closeIpDrawer()` : action;
}

function buildAccountRail() {
    let ordinal = 0;
    return ACCOUNT_JOURNEY.flatMap(phase =>
        phase.steps.map(step => {
            ordinal += 1;
            return `
                        <div class="ip-journey-seg" data-account-step="${step.key}" data-phase="${phase.key}" data-name="${step.label}"
                            onclick="${buildAccountJourneyAction(step)}" aria-label="Topic ${ordinal} · ${step.label}"></div>
                    `;
        })
    ).join('');
}

function buildAccountDrawerTimeline() {
    let ordinal = 0;
    return ACCOUNT_JOURNEY.map(phase => {
        const phaseHtml = `
                    <div class="ip-drawer-phase" data-phase="${phase.key}">
                        <div class="ip-drawer-phase-dot"></div>
                        <div class="ip-drawer-phase-label">${phase.label}</div>
                    </div>
                `;

        const stepsHtml = phase.steps.map(step => {
            ordinal += 1;
            return `
                        <div class="ip-drawer-step" data-account-step="${step.key}" onclick="${buildAccountJourneyAction(step, true)}">
                            <div class="ip-drawer-step-num">${ordinal}</div>
                            <div>
                                <div class="ip-drawer-step-label">${step.label}</div>
                                <div class="ip-drawer-step-meta">${step.meta}</div>
                            </div>
                        </div>
                    `;
        }).join('');

        return phaseHtml + stepsHtml;
    }).join('');
}

function isAccountJourneyScreen(screenNum) {
    return [16, 19, 21].includes(screenNum);
}

function ensureJourneyMode(mode) {
    if (currentJourneyMode === mode) return;
    const rail = document.getElementById('ip-journey-track');
    const drawer = document.getElementById('ip-drawer-timeline');
    if (!rail || !drawer) return;

    if (mode === 'account') {
        rail.innerHTML = buildAccountRail();
        drawer.innerHTML = buildAccountDrawerTimeline();
    } else {
        rail.innerHTML = matchJourneyTemplate.rail;
        drawer.innerHTML = matchJourneyTemplate.drawer;
    }

    currentJourneyMode = mode;
}

function resolveActiveAccountStep(screenNum) {
    if (ACCOUNT_JOURNEY_SCREEN_MAP[screenNum]) return ACCOUNT_JOURNEY_SCREEN_MAP[screenNum];
    if (screenNum !== 16) return 'portfolio';

    const screen = document.getElementById('screen-16');
    if (!screen) return 'portfolio';

    const anchors = Array.from(screen.querySelectorAll('[data-account-section]'));
    if (!anchors.length) return 'portfolio';

    const threshold = 132;
    let active = anchors[0];
    anchors.forEach(anchor => {
        if ((anchor.offsetTop - screen.scrollTop) <= threshold) {
            active = anchor;
        }
    });

    return active.getAttribute('data-account-section') || 'portfolio';
}

function scrollToAccountSection(stepKey) {
    if (stepKey === 'ai-scan') {
        goTo(21);
        return;
    }

    const doScroll = () => {
        const screen = document.getElementById('screen-16');
        const anchor = screen ? screen.querySelector(`[data-account-section="${stepKey}"]`) : null;
        if (!screen || !anchor) return;
        const top = Math.max(0, anchor.offsetTop - 124);
        screen.scrollTo({ top, behavior: 'smooth' });
        currentAccountStep = stepKey;
        queueAccountJourneySync();
    };

    if (currentScreen !== 16) {
        goTo(16);
        setTimeout(doScroll, 80);
    } else {
        doScroll();
    }
}

function updateAccountJourney(screenNum) {
    const stepKey = resolveActiveAccountStep(screenNum);
    const step = ACCOUNT_JOURNEY_LOOKUP[stepKey] || ACCOUNT_JOURNEY_LOOKUP.portfolio;
    const activeIdx = Math.max(0, ACCOUNT_JOURNEY_ORDER.indexOf(stepKey));
    const total = ACCOUNT_JOURNEY_ORDER.length;
    currentAccountStep = stepKey;

    const segs = document.querySelectorAll('.ip-journey-seg[data-account-step]');
    segs.forEach(seg => {
        const key = seg.getAttribute('data-account-step');
        const idx = ACCOUNT_JOURNEY_ORDER.indexOf(key);
        seg.classList.toggle('completed', idx > -1 && idx < activeIdx);
        seg.classList.toggle('active', key === stepKey);
    });

    const tooltip = document.getElementById('ip-journey-tooltip');
    const activeSeg = document.querySelector(`.ip-journey-seg[data-account-step="${stepKey}"]`);
    const track = document.getElementById('ip-journey-track');
    if (tooltip && activeSeg && track) {
        const trackRect = track.getBoundingClientRect();
        const segRect = activeSeg.getBoundingClientRect();
        const topPx = (segRect.top - trackRect.top) + (segRect.height / 2);
        tooltip.style.top = topPx + 'px';
        tooltip.setAttribute('data-phase', step.phaseKey);
        document.getElementById('ip-tt-phase').textContent = step.phaseLabel;
        document.getElementById('ip-tt-step').textContent = `${activeIdx + 1}/${total} · ${step.label}`;
        tooltip.classList.add('show');
        clearTimeout(window._ipTtTimer);
        window._ipTtTimer = setTimeout(() => tooltip.classList.remove('show'), 2200);
    }

    const handleText = document.getElementById('ip-handle-text');
    const handlePos = document.getElementById('ip-handle-pos');
    if (handleText) handleText.textContent = step.phaseLabel;
    if (handlePos) handlePos.textContent = `${activeIdx + 1}/${total}`;

    const drawerSteps = document.querySelectorAll('.ip-drawer-step[data-account-step]');
    drawerSteps.forEach(item => {
        const key = item.getAttribute('data-account-step');
        const idx = ACCOUNT_JOURNEY_ORDER.indexOf(key);
        item.classList.toggle('completed', idx > -1 && idx < activeIdx);
        item.classList.toggle('active', key === stepKey);
    });

    const drawerCurrent = document.getElementById('ip-drawer-current');
    if (drawerCurrent) drawerCurrent.textContent = `Topic ${activeIdx + 1} · ${step.label}`;

    const dwTimeline = document.getElementById('ip-drawer-timeline');
    const dwContent = dwTimeline ? dwTimeline.parentElement : null;
    const dwActive = dwTimeline ? dwTimeline.querySelector(`.ip-drawer-step[data-account-step="${stepKey}"]`) : null;
    if (dwTimeline && dwActive && dwContent) {
        const dwDot = dwActive.querySelector('.ip-drawer-step-num');
        const tlRect = dwTimeline.getBoundingClientRect();
        const dotRect = dwDot.getBoundingClientRect();
        const fillPx = (dotRect.top - tlRect.top) + (dotRect.height / 2);
        dwContent.style.setProperty('--ip-progress', fillPx + 'px');
    }

    updateBottomNav(screenNum);
}

function queueAccountJourneySync() {
    if (accountJourneyFrame) cancelAnimationFrame(accountJourneyFrame);
    accountJourneyFrame = requestAnimationFrame(() => {
        accountJourneyFrame = 0;
        if (!isAccountJourneyScreen(currentScreen)) return;
        updateAccountJourney(currentScreen);
    });
}

function initAccountJourneyScroll() {
    [16, 19, 21].forEach(screenNum => {
        const screen = document.getElementById(`screen-${screenNum}`);
        if (!screen) return;
        screen.addEventListener('scroll', () => {
            if (!screen.classList.contains('active')) return;
            queueAccountJourneySync();
        }, { passive: true });
    });
}

function syncJourneyUI(screenNum) {
    currentScreen = screenNum;
    const mode = isAccountJourneyScreen(screenNum) ? 'account' : 'match';
    ensureJourneyMode(mode);
    if (mode === 'account') updateAccountJourney(screenNum);
    else {
        updateMatchJourneyProgress(screenNum);
        updateMatchInPhoneJourney(screenNum);
    }
}

// FIXED: Proper state reset, scroll reset, and unified navigation
function goTo(screenNum) {
    if (isNavigating) return;
    isNavigating = true;
    // Agreement gate
    if ([7, 8, 9, 10, 11].includes(screenNum) && !agreements[screenNum - 1] && screenNum > 7) {
        document.getElementById('modal-overlay').classList.add('active');
        isNavigating = false;
        return;
    }
    // Switch screens
    document.querySelectorAll('.screen-content').forEach(el => el.classList.remove('active'));
    const target = document.getElementById(`screen-${screenNum}`);
    if (!target) {
        isNavigating = false;
        return false;
    }
    target.classList.add('active');
    if (screenNum !== 16) document.body.classList.remove('note-workflow-open');
    target.scrollTop = 0; // FIXED: Prevents scroll jump
    const phoneScreen = document.querySelector('.phone-screen');
    if (phoneScreen) {
        phoneScreen.scrollTop = 0;
        phoneScreen.scrollLeft = 0;
    }
    if (document.scrollingElement) {
        document.scrollingElement.scrollTop = 0;
        document.scrollingElement.scrollLeft = 0;
    }
    syncJourneyUI(screenNum);
    // Trigger dynamic updates if needed
    if (screenNum === 15) updateDepositUI();
    updateInquiryState();
    isNavigating = false;
}
function toggleAgree(el, nextScreen = null) {
    if (el.classList.contains('activated')) return;

    el.classList.add('activated');
    const screenId = parseInt(el.closest('.screen-content').id.replace('screen-', ''));
    agreements[screenId] = true;

    // Auto-navigate after a short delay for visual feedback
    if (nextScreen) {
        setTimeout(() => {
            goTo(nextScreen);
        }, 500); // Snappier but still visible
    }
}
function checkAgree(from, to) {
    if (agreements[from]) goTo(to);
    else document.getElementById('modal-overlay').classList.add('active');
}
function closeModal() {
    document.getElementById('modal-overlay').classList.remove('active');
}
function selectSlot(el, parent) {
    document.querySelectorAll(parent).forEach(s => s.classList.remove('selected'));
    el.classList.add('selected');
}
function selectHospital(el) {
    document.querySelectorAll('.hospital-card').forEach(c => c.classList.remove('selected'));
    el.classList.add('selected');
}
// G6 (new 6-step Guardian flow) helpers
function selectG6Slot(el, selector) {
    // Toggle selected within a sibling group
    const parent = el.parentElement;
    if (!parent) return;
    parent.querySelectorAll(selector).forEach(s => s.classList.remove('selected'));
    el.classList.add('selected');
}
function selectG6Care(el, type) {
    document.querySelectorAll('#screen-13 .g6-care-card').forEach(c => c.classList.remove('selected'));
    el.classList.add('selected');
    // Basic has a blended/representative rate ($30 Khmer-Thai/VN, $50 English in Malaysia) — we use $30 as default floor
    const labels = { basic: 'Basic · 4 days', standard: 'Standard · 4 days', premium: 'Premium · 4 days' };
    const prices = { basic: 30, standard: 100, premium: 150 };
    const days = 4;
    const total = (prices[type] || 100) * days;
    const deposit = 12;
    const balance = total - deposit;
    const display = document.getElementById('selected-care-display');
    if (display) display.textContent = labels[type] || 'Standard · 4 days';
    const label = document.getElementById('service-total-label');
    if (label) label.textContent = `${(labels[type] || 'Standard').split(' ·')[0]} Care support total (${days} days × $${prices[type]})`;
    const tv = document.getElementById('service-total-value');
    if (tv) tv.textContent = '$' + total;
    const dv = document.getElementById('deposit-value');
    if (dv) dv.textContent = '$' + deposit;
    const bv = document.getElementById('balance-value');
    if (bv) bv.textContent = '$' + balance;
    resetGuardianPaymentState();
}
function toggleG6Agreement(id) {
    const acc = document.getElementById(id);
    if (!acc) return;
    acc.classList.toggle('expanded');
}
function acknowledgeG6(id) {
    const acc = document.getElementById(id);
    if (!acc) return;
    acc.classList.add('agreed');
    acc.classList.remove('expanded');
    // Check if all agreements are signed, then enable deposit button
    const all = document.querySelectorAll('#screen-6 .g6-agreement-accordion');
    const agreed = document.querySelectorAll('#screen-6 .g6-agreement-accordion.agreed');
    const depositBtn = document.getElementById('g6-deposit-btn');
    if (depositBtn && all.length > 0 && agreed.length === all.length) {
        depositBtn.classList.remove('disabled');
        depositBtn.removeAttribute('disabled');
    }
}
// FIXED: Robust package selection without fragile string replacement
function selectPackage(el, type) {
    document.querySelectorAll('.package-card').forEach(c => c.classList.remove('selected'));
    el.classList.add('selected');
    const prices = { basic: 0, standard: 30, premium: 120, concierge: 350 };
    const keyMap = { basic: 'basic_name', standard: 'standard_name', premium: 'premium_name', concierge: 'concierge_name' };

    // Store type and price, but resolve label dynamically to support language switching
    selectedCare = { type, price: prices[type], i18nKey: keyMap[type] };

    const label = translations[currentLang][keyMap[type]] || type;
    const confirmLabel = translations[currentLang].confirm || 'Confirm';
    document.getElementById('confirm-care-btn').querySelector('span').textContent = `${confirmLabel} ${label}`;
    resetGuardianPaymentState();
}
function refreshGuardianPaymentUI() {
    const payBtn = document.getElementById('guardian-payment-btn');
    const payLabel = document.getElementById('pay-btn-text');
    const completeNote = document.getElementById('guardian-payment-complete');
    if (payBtn && payLabel) {
        payBtn.classList.toggle('disabled', guardianPaymentCompleted);
        if (guardianPaymentCompleted) payBtn.setAttribute('disabled', 'disabled');
        else payBtn.removeAttribute('disabled');
        payLabel.textContent = guardianPaymentCompleted ? 'Payment Completed' : 'Pay $12 Deposit - Open ABA';
    }
    if (completeNote) completeNote.style.display = guardianPaymentCompleted ? 'block' : 'none';
}
function resetGuardianPaymentState() {
    guardianPaymentCompleted = false;
    refreshGuardianPaymentUI();
}
function updateDepositUI() {
    const total = selectedCare.price * 4;
    const deposit = 12;
    const balance = total - deposit;
    const label = translations[currentLang][selectedCare.i18nKey] || selectedCare.type;

    document.getElementById('selected-care-display').textContent = `${label} · 4 days`;
    document.getElementById('service-total-label').textContent = `${label} Care support total (4 days × $${selectedCare.price})`;
    document.getElementById('service-total-value').textContent = `$${total}`;
    document.getElementById('deposit-value').textContent = `$${deposit}`;
    document.getElementById('balance-value').textContent = `$${balance}`;
    refreshGuardianPaymentUI();
}
// FIXED: Fallback for missing translation key during recording state
function toggleRecording() {
    const container = document.getElementById('voice-container');
    const hint = document.getElementById('voice-hint');
    const mic = document.getElementById('mic-btn');
    const wave = document.getElementById('voice-wave');
    const transcript = document.getElementById('voice-transcript');
    const actions = document.getElementById('voice-actions');
    const analyzeBtn = document.getElementById('analyze-btn');
    if (!isRecording) {
        isRecording = true;
        container.classList.add('recording');
        mic.classList.add('recording');
        hint.textContent = translations[currentLang].voice_hint_recording || 'Recording...';
        wave.classList.add('active');
    } else {
        isRecording = false;
        container.classList.remove('recording');
        container.classList.add('has-text');
        mic.classList.remove('recording');
        wave.classList.remove('active');
        hint.textContent = translations[currentLang].voice_hint || 'Tap to start recording';
        transcript.querySelector('#transcript-text').textContent = translations[currentLang].voice_sample || "Voice transcript simulated.";
        transcript.classList.add('show');
        actions.classList.add('show');
        analyzeBtn.disabled = false;
    }
}
function retryRecording() {
    document.getElementById('voice-container').classList.remove('has-text');
    document.getElementById('voice-transcript').classList.remove('show');
    document.getElementById('voice-actions').classList.remove('show');
    document.getElementById('analyze-btn').disabled = true;
    toggleRecording();
}
function editTranscript() { alert("Edit functionality would open a text area (Prototype)"); }
function startAnalysis() { goTo(4); setTimeout(() => goTo(5), 3000); }
function updateInquiryState() {
    const pendingCard = document.getElementById('pending-inquiry-card');
    if (pendingCard) pendingCard.classList.toggle('active', inquiryPending);
    const inquiryValue = document.getElementById('inquiry-status-value');
    if (inquiryValue) inquiryValue.textContent = inquiryPending ? 'Pending - return anytime' : 'Available now';
}
function openTelegramCall() {
    inquiryPending = true;
    updateInquiryState();
    const deepLink = TELEGRAM_PROFILE_URL.replace('https://t.me/', 'tg://resolve?domain=');
    const fallbackWindow = window.open(TELEGRAM_PROFILE_URL, '_blank');
    window.location.href = deepLink;
    if (!fallbackWindow) window.location.href = TELEGRAM_PROFILE_URL;
}
function startAbaPayment() {
    if (guardianPaymentCompleted) return;
    const paymentWindow = window.open(ABA_PAYMENT_URL, '_blank', 'noopener,noreferrer');
    if (!paymentWindow) window.location.href = ABA_PAYMENT_URL;
    setTimeout(() => {
        const isPaid = window.confirm('After you complete the deposit in ABA Mobile, tap OK to finish your booking.');
        if (!isPaid) return;
        guardianPaymentCompleted = true;
        refreshGuardianPaymentUI();
    }, 250);
}
let facebookGate = { groupOpened: false, pageOpened: false };
function markFacebookAction(type) {
    if (type === 'group') facebookGate.groupOpened = true;
    if (type === 'page') facebookGate.pageOpened = true;
    updateFacebookGate();
}
function openFacebookTarget(type, url) {
    markFacebookAction(type);
    window.open(url, '_blank', 'noopener,noreferrer');
}
function updateFacebookGate() {
    const groupCheck = document.getElementById('fb-group-check');
    const pageCheck = document.getElementById('fb-page-check');
    const continueBtn = document.getElementById('fb-gated-continue-btn');
    const status = document.getElementById('fb-gate-status');
    if (!groupCheck || !pageCheck || !continueBtn || !status) return;
    const langSet = translations[currentLang] || translations.en;

    const groupDone = facebookGate.groupOpened && groupCheck.checked;
    const pageDone = facebookGate.pageOpened && pageCheck.checked;
    const unlocked = groupDone && pageDone;

    continueBtn.disabled = !unlocked;
    continueBtn.style.opacity = unlocked ? '1' : '0.45';
    continueBtn.style.cursor = unlocked ? 'pointer' : 'not-allowed';

    if (unlocked) {
        status.textContent = langSet.fb_gate_status_ready || translations.en.fb_gate_status_ready;
        status.style.color = 'var(--success)';
    } else if (groupCheck.checked || pageCheck.checked) {
        status.textContent = langSet.fb_gate_status_partial || translations.en.fb_gate_status_partial;
        status.style.color = 'var(--gray)';
    } else {
        status.textContent = langSet.fb_gate_status_default || translations.en.fb_gate_status_default;
        status.style.color = 'var(--gray)';
    }
}
function openTelegram() { window.open(TELEGRAM_PROFILE_URL, '_blank'); }
function restartDemo() {
    goTo(1);
    agreements = { 7: false, 8: false, 9: false, 10: false, 11: false };
    document.querySelectorAll('.tap-to-agree').forEach(el => el.classList.remove('activated'));
    selectedCare = { type: 'standard', price: 30, i18nKey: 'standard_name' };
    inquiryPending = false;
    facebookGate = { groupOpened: false, pageOpened: false };
    const groupCheck = document.getElementById('fb-group-check');
    const pageCheck = document.getElementById('fb-page-check');
    if (groupCheck) groupCheck.checked = false;
    if (pageCheck) pageCheck.checked = false;
    updateDepositUI();
    resetGuardianPaymentState();
    updateInquiryState();
    updateFacebookGate();
    initCoordinationCards();
}
// ============= IN-PHONE JOURNEY PROGRESS =============
// Order is the visual top-to-bottom order in the in-phone timeline
// (Discovery → Fallback → Trust → Commitment), NOT the screen number.
// New Guardian flow: 3 (Voice Case) → 5 (Preliminary Match) → 6 (Match Review + Agreement) → 13 (Hospital + Care) → 15 (Final Confirm)
// Guardian ends at 15; Account opens separately from the bottom navigation.
const JOURNEY_ORDER = [1, 3, 4, 5, 17, 18, 6, 13, 15];
const JOURNEY_TOTAL = JOURNEY_ORDER.length;
const PHASE_BY_SCREEN = {
    1: 'discovery', 3: 'discovery', 4: 'discovery', 5: 'discovery',
    17: 'fallback', 18: 'fallback',
    6: 'trust', 7: 'trust', 8: 'trust', 9: 'trust', 10: 'trust', 11: 'trust', 12: 'trust',
    13: 'commit', 15: 'commit', 16: 'commit',
    19: 'commit', 20: 'commit', 21: 'commit'
};
const PHASE_LABEL = {
    discovery: 'Discovery',
    fallback: 'Fallback',
    trust: 'Trust',
    commit: 'Commitment'
};
const SCREEN_NAME = {
    1: 'Welcome', 3: 'Step 2 · Voice Case', 4: 'Case Analysis', 5: 'Step 3 · Preliminary Match',
    6: 'Step 4 · Match Review', 7: 'Guardian Intro', 8: 'Your Rights', 9: 'Our Duties',
    10: '90-Day Commitment', 11: 'Right to Exit', 12: 'Agreement Complete',
    13: 'Step 5 · Hospital + Care', 15: 'Step 6 · Confirm', 16: 'Note',
    17: 'No Match Fallback', 18: 'TG Group Created',
    19: 'Health Timeline', 20: 'Year Comparison', 21: 'AI Scan'
};
// Account screens keep the Guardian flow visually completed at Step 15.
const SUB_SCREEN_PARENT = { 16: 15, 19: 15, 20: 15, 21: 15 };

function updateMatchJourneyProgress(screenNum) {
    updateBottomNav(screenNum);
}

function resolveBottomNavTarget(screenNum) {
    if (screenNum === 1) return 1;
    if (screenNum === 20) return 20;
    if ([16, 19, 21].includes(screenNum)) return 16;
    return 1;
}

// Bottom-nav active state sync
function updateBottomNav(screenNum) {
    const activeTarget = resolveBottomNavTarget(screenNum);
    const items = document.querySelectorAll('.ip-bottom-nav-item');
    items.forEach(item => {
        const target = parseInt(item.getAttribute('data-target'));
        item.classList.toggle('active', target === activeTarget);
    });
}

// ============= IN-PHONE JOURNEY SYSTEM =============
// Updates the top pulse rail, floating tooltip, drawer handle,
// and drawer steps every time goTo() is called.
function updateMatchInPhoneJourney(screenNum) {
    const phase = PHASE_BY_SCREEN[screenNum] || 'discovery';
    const idx = JOURNEY_ORDER.indexOf(screenNum);
    const ordinal = idx >= 0 ? (idx + 1) : 1;
    const screenName = SCREEN_NAME[screenNum] || '';
    // Sub-screens map to their parent on the top rail
    const isSubScreen = !!SUB_SCREEN_PARENT[screenNum];
    const railScreen = SUB_SCREEN_PARENT[screenNum] || screenNum;
    const ordLabel = isSubScreen ? screenName : (ordinal + '/' + JOURNEY_TOTAL);

    // ---- (1) Top pulse rail segments ----
    const segs = document.querySelectorAll('.ip-journey-seg');
    segs.forEach(seg => {
        const s = parseInt(seg.getAttribute('data-screen'));
        seg.classList.toggle('completed', s < railScreen && PHASE_BY_SCREEN[s] !== 'fallback');
        seg.classList.toggle('active', s === railScreen);
    });

    // ---- (2) Floating tooltip — position above active segment ----
    const tooltip = document.getElementById('ip-journey-tooltip');
    const activeSeg = document.querySelector(`.ip-journey-seg[data-screen="${railScreen}"]`);
    const track = document.getElementById('ip-journey-track');
    if (tooltip && activeSeg && track) {
        const trackRect = track.getBoundingClientRect();
        const segRect = activeSeg.getBoundingClientRect();
        const topPx = (segRect.top - trackRect.top) + (segRect.height / 2);
        tooltip.style.top = topPx + 'px';
        tooltip.setAttribute('data-phase', phase);
        document.getElementById('ip-tt-phase').textContent = PHASE_LABEL[phase];
        document.getElementById('ip-tt-step').textContent = ordLabel;
        tooltip.classList.add('show');
        clearTimeout(window._ipTtTimer);
        window._ipTtTimer = setTimeout(() => tooltip.classList.remove('show'), 2200);
    }

    // ---- (3) Drawer handle ----
    const handleText = document.getElementById('ip-handle-text');
    const handlePos = document.getElementById('ip-handle-pos');
    if (handleText) handleText.textContent = isSubScreen ? screenName : PHASE_LABEL[phase];
    if (handlePos) handlePos.textContent = isSubScreen ? '📋' : (ordinal + '/' + JOURNEY_TOTAL);

    // ---- (3) Drawer steps ----
    const drawerSteps = document.querySelectorAll('.ip-drawer-step');
    drawerSteps.forEach(step => {
        const s = parseInt(step.getAttribute('data-screen'));
        step.classList.toggle('completed', s < railScreen && PHASE_BY_SCREEN[s] !== 'fallback');
        step.classList.toggle('active', s === railScreen);
    });

    // ---- (3) Drawer current label ----
    const drawerCurrent = document.getElementById('ip-drawer-current');
    if (drawerCurrent) drawerCurrent.textContent = isSubScreen
        ? 'Sub-screen · ' + screenName
        : ('Step ' + ordinal + ' · ' + screenName);

    // ---- (3) Drawer progress spine fill ----
    const dwTimeline = document.getElementById('ip-drawer-timeline');
    const dwContent = dwTimeline ? dwTimeline.parentElement : null;
    const dwActive = dwTimeline ? dwTimeline.querySelector(`.ip-drawer-step[data-screen="${screenNum}"]`) : null;
    if (dwTimeline && dwActive && dwContent) {
        const dwDot = dwActive.querySelector('.ip-drawer-step-num');
        const tlRect = dwTimeline.getBoundingClientRect();
        const dotRect = dwDot.getBoundingClientRect();
        const fillPx = (dotRect.top - tlRect.top) + (dotRect.height / 2);
        dwContent.style.setProperty('--ip-progress', fillPx + 'px');
    }
}

function toggleIpDrawer() {
    const overlay = document.getElementById('ip-drawer-overlay');
    if (!overlay) return;
    overlay.classList.toggle('open');
    // Recompute drawer spine fill once it's visible (geometry needs layout)
    if (overlay.classList.contains('open')) {
        const active = document.querySelector('.ip-drawer-step.active');
        if (active) setTimeout(() => {
            syncJourneyUI(currentScreen);
            active.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }, 100);
    }
}
function closeIpDrawer() {
    const overlay = document.getElementById('ip-drawer-overlay');
    if (overlay) overlay.classList.remove('open');
}

// ============= HOSPITAL FLIP CARDS =============
function toggleHospCard(cardEl) {
    if (!cardEl) return;
    cardEl.classList.toggle('flipped');
}

// ============= n8n AI SCAN FLOW =============
// Simulates the n8n webhook workflow for the prototype. In production,
// replace the setTimeout chain with a real `fetch(WEBHOOK_URL, {method:'POST', body:formData})`
// and progress events via EventSource / WebSocket. See instructions at bottom.
let n8nRunning = false;
const N8N_WEBHOOK_URL = 'https://n8n.yourdomain.com/webhook/health-scan'; // ← REPLACE with real webhook in production

function startN8nFlow(fileName) {
    if (n8nRunning) return;
    n8nRunning = true;

    const pipeline = document.getElementById('n8n-pipeline');
    const result = document.getElementById('n8n-result');
    const drop = document.getElementById('n8n-drop');

    // Reset any prior state
    result.classList.remove('active');
    document.querySelectorAll('.n8n-node').forEach(n => {
        n.classList.remove('running', 'done');
        const timeEl = n.querySelector('[data-time]');
        if (timeEl) timeEl.textContent = '';
    });

    // Show pipeline, dim drop
    pipeline.classList.add('active');
    drop.style.opacity = '0.5';
    drop.style.pointerEvents = 'none';

    // Node sequence with realistic timings
    const nodes = [
        { sel: '[data-node="upload"]', dur: 800, status: 'Encrypted · 2.4 MB sent' },
        { sel: '[data-node="ocr"]', dur: 1600, status: '14 lab values extracted' },
        { sel: '[data-node="translate"]', dur: 1200, status: 'Khmer → English · 11 terms translated' },
        { sel: '[data-node="compare"]', dur: 1400, status: 'Compared with 2022, 2023, 2024, 2025 records' },
        { sel: '[data-node="delete"]', dur: 700, status: 'Source file permanently removed' }
    ];

    let chain = Promise.resolve();
    const startTime = Date.now();

    nodes.forEach((n, i) => {
        chain = chain.then(() => new Promise(resolve => {
            const el = document.querySelector(n.sel);
            if (!el) return resolve();
            el.classList.add('running');
            setTimeout(() => {
                el.classList.remove('running');
                el.classList.add('done');
                const statusEl = el.querySelector('.n8n-node-status');
                if (statusEl) statusEl.textContent = n.status;
                const timeEl = el.querySelector('[data-time]');
                if (timeEl) timeEl.textContent = ((Date.now() - startTime) / 1000).toFixed(1) + 's';
                resolve();
            }, n.dur);
        }));
    });

    chain.then(() => {
        // Reveal results
        setTimeout(() => {
            result.classList.add('active');
            result.scrollIntoView({ behavior: 'smooth', block: 'start' });
            n8nRunning = false;
        }, 400);
    });
}

function resetN8nFlow() {
    document.getElementById('n8n-pipeline').classList.remove('active');
    document.getElementById('n8n-result').classList.remove('active');
    document.querySelectorAll('.n8n-node').forEach(n => n.classList.remove('running', 'done'));
    const drop = document.getElementById('n8n-drop');
    drop.style.opacity = '1';
    drop.style.pointerEvents = 'auto';
    n8nRunning = false;
}

// =====================================================================
// MY DASHBOARD V2 — OTP auth, Upload flow, Processing, Analysis Dashboard
// =====================================================================

// Auth state — session-only for the prototype (cleared on reload)
let mdDashboardUnlocked = false;
let mdPendingAction = null; // what to do after auth completes
let mdAuthPhone = '';

// ---------- OTP AUTH ----------
function openAuthOverlay(nextAction) {
    mdPendingAction = nextAction || null;
    document.getElementById('md-auth-step-phone').style.display = 'block';
    document.getElementById('md-auth-step-success').style.display = 'none';
    document.getElementById('md-auth-error').classList.remove('show');
    document.getElementById('md-auth-overlay').classList.add('active');
    setTimeout(() => {
        const u = document.getElementById('md-auth-username');
        if (u) u.focus();
    }, 300);
}

function closeAuthOverlay() {
    document.getElementById('md-auth-overlay').classList.remove('active');
}

// Auto-advance between DOB fields (DD → MM → YYYY)
function dobHop(el, nextId, requiredLen) {
    el.value = el.value.replace(/\D/g, '');
    if (el.value.length >= requiredLen) {
        const n = document.getElementById(nextId);
        if (n) n.focus();
    }
}

// Username + DOB login — replaces OTP
function verifyLogin() {
    const username = document.getElementById('md-auth-username').value.trim();
    const dd = document.getElementById('md-auth-dd').value.trim();
    const mm = document.getElementById('md-auth-mm').value.trim();
    const yyyy = document.getElementById('md-auth-yyyy').value.trim();

    // Demo validation — any non-empty username + valid-shaped DOB works
    const errEl = document.getElementById('md-auth-error');
    const validDob = dd.length >= 1 && mm.length >= 1 && yyyy.length === 4
        && parseInt(dd) >= 1 && parseInt(dd) <= 31
        && parseInt(mm) >= 1 && parseInt(mm) <= 12
        && parseInt(yyyy) >= 1900 && parseInt(yyyy) <= 2025;

    if (!username || !validDob) {
        errEl.textContent = !username
            ? 'Please enter your username to continue.'
            : 'Please enter a valid date of birth (DD/MM/YYYY).';
        errEl.classList.add('show');
        return;
    }
    errEl.classList.remove('show');

    // Store portfolio identity
    mdPortfolioUser = {
        username: username,
        dob: `${dd.padStart(2, '0')}/${mm.padStart(2, '0')}/${yyyy}`,
        since: new Date().getFullYear()
    };
    mdDashboardUnlocked = true;

    // Show success state
    document.getElementById('md-auth-step-phone').style.display = 'none';
    document.getElementById('md-auth-step-success').style.display = 'block';

    // Update portfolio chrome
    updatePortfolioHeader();

    setTimeout(() => {
        closeAuthOverlay();
        if (mdPendingAction === 'upload') {
            openUploadFlow();
        } else if (mdPendingAction === 'sample') {
            runSampleDemo(true);
        }
        mdPendingAction = null;
    }, 1200);
}

function authSwitchToSignup() {
    alert('Demo: In production this creates a new portfolio. For now, just fill in any username + your DOB and tap "Enter my portfolio".');
}

// Portfolio header updater — called after login
let mdPortfolioUser = null;
function updatePortfolioHeader() {
    const headEl = document.getElementById('pf-portfolio-head');
    if (!headEl || !mdPortfolioUser) return;
    const initials = mdPortfolioUser.username.slice(0, 2).toUpperCase();
    const nameEl = document.getElementById('pf-port-name');
    const avatarEl = document.getElementById('pf-port-avatar');
    const sinceEl = document.getElementById('pf-port-since');
    if (nameEl) nameEl.textContent = mdPortfolioUser.username;
    if (avatarEl) avatarEl.textContent = initials;
    if (sinceEl) sinceEl.textContent = `Portfolio since ${mdPortfolioUser.since}`;
    // Hide tutorial banner once real login happens
    const tut = document.getElementById('pf-tutorial-banner');
    if (tut) tut.style.display = 'none';
}

function portfolioLogout() {
    mdDashboardUnlocked = false;
    mdPortfolioUser = null;
    hideResults();
    // Reset header to tutorial state
    const nameEl = document.getElementById('pf-port-name');
    const avatarEl = document.getElementById('pf-port-avatar');
    const sinceEl = document.getElementById('pf-port-since');
    if (nameEl) nameEl.textContent = 'Sample Patient';
    if (avatarEl) avatarEl.textContent = 'SP';
    if (sinceEl) sinceEl.textContent = 'Tutorial mode';
    const tut = document.getElementById('pf-tutorial-banner');
    if (tut) tut.style.display = 'block';
}

// ---------- UPLOAD FLOW ----------
// selectedUploadCategory: chosen before uploading (medrecord|medication|payment)
let selectedUploadCategory = null;

function selectUploadCategory(cat) {
    selectedUploadCategory = cat;
    // toggle active classes on picker buttons
    document.querySelectorAll('.md-cat-opt').forEach(b => {
        if (b.getAttribute('data-cat') === cat) b.classList.add('active');
        else b.classList.remove('active');
    });
    const err = document.getElementById('md-up-cat-error');
    if (err) err.style.display = 'none';
}
function openUploadFlow() {
    // Gate: require OTP login first
    if (!mdDashboardUnlocked) {
        openAuthOverlay('upload');
        return;
    }
    resetUploadFlow();
    document.getElementById('md-upload-overlay').classList.add('active');
}

function closeUploadOverlay() {
    document.getElementById('md-upload-overlay').classList.remove('active');
}

function resetUploadFlow() {
    document.getElementById('md-up-step-pick').style.display = 'block';
    document.getElementById('md-up-step-confirm').style.display = 'none';
    document.getElementById('md-up-step-processing').style.display = 'none';
    const reviewEl = document.getElementById('md-up-step-review');
    if (reviewEl) reviewEl.style.display = 'none';
    document.getElementById('md-up-step-done').style.display = 'none';
    // Reset processing steps
    document.querySelectorAll('.md-proc-step').forEach(s => s.classList.remove('active', 'done'));
    const first = document.querySelector('.md-proc-step[data-step="1"]');
    if (first) first.classList.add('active');
}

function simulatePickFile() {
    // Require user to pick a category first
    if (!selectedUploadCategory) {
        const err = document.getElementById('md-up-cat-error');
        if (err) err.style.display = 'block';
        return;
    }
    // In the demo we skip the OS file picker
    document.getElementById('md-up-step-pick').style.display = 'none';
    document.getElementById('md-up-step-confirm').style.display = 'block';
    // Reflect chosen category in the preview area
    const previewInfo = document.querySelector('.md-file-preview-info');
    if (previewInfo) {
        let catNode = document.getElementById('md-file-preview-cat');
        if (!catNode) {
            catNode = document.createElement('div');
            catNode.id = 'md-file-preview-cat';
            catNode.style.fontSize = '12px';
            catNode.style.opacity = '.8';
            previewInfo.appendChild(catNode);
        }
        const labels = { medrecord: 'MedRecord', medication: 'Medication', payment: 'Payment' };
        catNode.textContent = 'Saving to: ' + (labels[selectedUploadCategory] || selectedUploadCategory);
    }
}

function startProcessing() {
    document.getElementById('md-up-step-confirm').style.display = 'none';
    document.getElementById('md-up-step-processing').style.display = 'block';

    const stepLabels = [
        'Reading your document…',
        'Detecting medical terms…',
        'Translating to English & Khmer…',
        'Preparing extraction review…'
    ];
    const stepDurations = [900, 900, 900, 900];
    let i = 0;

    function runStep() {
        const steps = document.querySelectorAll('.md-proc-step');
        if (i > 0) {
            steps[i - 1].classList.remove('active');
            steps[i - 1].classList.add('done');
        }
        if (i >= steps.length) {
            // All done → show LAB REVIEW step (keep/remove extracted items)
            setTimeout(() => {
                document.getElementById('md-up-step-processing').style.display = 'none';
                document.getElementById('md-up-step-review').style.display = 'block';
                renderLabReview();
            }, 300);
            return;
        }
        steps[i].classList.add('active');
        document.getElementById('md-proc-title').textContent = stepLabels[i];
        setTimeout(() => { i++; runStep(); }, stepDurations[i]);
    }
    runStep();
}

// ---------- LAB EXTRACTION REVIEW ----------
// Sample extracted lab items — in production these come from the OCR+translation pipeline.
// Note the variety: core lipid panel + extras (HbA1c, Vitamin D, thyroid, liver, kidney).
const mdExtractedLabs = [
    { id: 'ldl', name: 'LDL Cholesterol', value: '142 mg/dL', flag: 'Abnormal', critical: true, keep: true },
    { id: 'hdl', name: 'HDL Cholesterol', value: '48 mg/dL', flag: 'Normal', critical: false, keep: true },
    { id: 'tri', name: 'Triglycerides', value: '165 mg/dL', flag: 'Abnormal', critical: true, keep: true },
    { id: 'tchol', name: 'Total Cholesterol', value: '218 mg/dL', flag: 'Abnormal', critical: true, keep: true },
    { id: 'glu', name: 'Fasting Glucose', value: '98 mg/dL', flag: 'Normal', critical: false, keep: true },
    { id: 'hba1c', name: 'HbA1c', value: '5.6%', flag: 'Normal', critical: false, keep: true },
    { id: 'creat', name: 'Creatinine', value: '0.9 mg/dL', flag: 'Normal', critical: false, keep: false },
    { id: 'urea', name: 'Blood Urea (BUN)', value: '14 mg/dL', flag: 'Normal', critical: false, keep: false },
    { id: 'alt', name: 'ALT (liver)', value: '42 U/L', flag: 'Borderline', critical: false, keep: true },
    { id: 'ast', name: 'AST (liver)', value: '28 U/L', flag: 'Normal', critical: false, keep: false },
    { id: 'tsh', name: 'TSH (thyroid)', value: '2.1 mIU/L', flag: 'Normal', critical: false, keep: false },
    { id: 'vitd', name: 'Vitamin D', value: '22 ng/mL', flag: 'Low', critical: false, keep: true },
    { id: 'hb', name: 'Hemoglobin', value: '14.2 g/dL', flag: 'Normal', critical: false, keep: false },
    { id: 'wbc', name: 'White Blood Count', value: '7.1 k/µL', flag: 'Normal', critical: false, keep: false }
];

function renderLabReview() {
    const listEl = document.getElementById('md-lab-review-list');
    const countEl = document.getElementById('md-lab-count');
    countEl.textContent = mdExtractedLabs.length + ' test results';
    listEl.innerHTML = mdExtractedLabs.map(item => `
                <div class="md-lab-review-row ${item.keep ? 'keep' : 'drop'}" onclick="toggleLabItem('${item.id}')">
                    <div class="md-lab-review-check"></div>
                    <div class="md-lab-review-info">
                        <div class="md-lab-review-name">
                            ${item.name}
                            ${item.critical ? '<span class="md-lab-review-critical-flag">Critical</span>' : ''}
                        </div>
                        <div class="md-lab-review-val">Value: <strong>${item.value}</strong> · ${item.flag}</div>
                    </div>
                </div>
            `).join('');
    updateLabKeptCount();
}

function toggleLabItem(id) {
    const item = mdExtractedLabs.find(x => x.id === id);
    if (!item) return;
    item.keep = !item.keep;
    renderLabReview();
}

function labBulkAction(mode) {
    mdExtractedLabs.forEach(item => {
        if (mode === 'all') item.keep = true;
        else if (mode === 'none') item.keep = false;
        else if (mode === 'critical') item.keep = !!item.critical;
    });
    renderLabReview();
}

function updateLabKeptCount() {
    const kept = mdExtractedLabs.filter(x => x.keep).length;
    document.getElementById('md-lab-kept-count').textContent =
        `Keeping ${kept} of ${mdExtractedLabs.length} items`;
}

function confirmLabReview() {
    // In production: send keep/remove decisions to backend. Also: log decisions as labeled
    // training data for market intelligence.
    const kept = mdExtractedLabs.filter(x => x.keep).length;
    if (kept === 0) {
        alert('Please keep at least one item before building your account.');
        return;
    }
    document.getElementById('md-up-step-review').style.display = 'none';
    document.getElementById('md-up-step-done').style.display = 'block';
}

function finishUploadAndShowResults() {
    // If user picked a category before upload, reflect save into the folder UI
    if (selectedUploadCategory) {
        const folder = document.querySelector('.mr-folder[data-folder="' + selectedUploadCategory + '"]');
        if (folder) {
            const cnt = folder.querySelector('[data-count]');
            if (cnt) {
                const n = parseInt(cnt.textContent) || 0;
                cnt.textContent = (n + 1) + ' files';
            }
        }
        const labels = { medrecord: 'MedRecord', medication: 'Medication', payment: 'Payment' };
        const flash = document.getElementById('mrFlash');
        if (flash) {
            flash.textContent = '✓ Saved to ' + (labels[selectedUploadCategory] || selectedUploadCategory);
            flash.classList.add('show');
            setTimeout(() => flash.classList.remove('show'), 2200);
        }
        selectedUploadCategory = null;
    }
    closeUploadOverlay();
    showResultsDashboard('upload');
}

// ---------- SAMPLE DEMO ----------
function runSampleDemo(skipAuth) {
    // For the sample, no auth required — it's public tutorial data
    // But keep consistency: if flow was interrupted, this still works.
    showResultsDashboard('sample');
}

// ---------- RESULTS DASHBOARD ----------
const mdSampleData = {
    source: 'sample',
    reportCount: 9,
    yearRange: '2022–2026',
    indicators: [
        {
            key: 'ldl',
            name: 'LDL Cholesterol',
            unit: 'mg/dL',
            normalMin: 0,
            normalMax: 130,
            critical: 160,
            higherIsWorse: true
        },
        {
            key: 'glu',
            name: 'Fasting Glucose',
            unit: 'mg/dL',
            normalMin: 70,
            normalMax: 100,
            critical: 125,
            higherIsWorse: true
        },
        {
            key: 'sys',
            name: 'Systolic BP',
            unit: 'mmHg',
            normalMin: 90,
            normalMax: 120,
            critical: 140,
            higherIsWorse: true
        },
        {
            key: 'tri',
            name: 'Triglycerides',
            unit: 'mg/dL',
            normalMin: 0,
            normalMax: 150,
            critical: 200,
            higherIsWorse: true
        }
    ],
    yearly: {
        labels: ['2022', '2023', '2024', '2025', '2026'],
        ldl: [132, 148, 161, 168, 142],
        glu: [92, 97, 102, 102, 98],
        sys: [122, 128, 134, 138, 128],
        tri: [155, 172, 181, 190, 165]
    },
    monthly: {
        labels: ['Sep', 'Oct', 'Nov', 'Dec', 'Jan', 'Feb', 'Mar', 'Apr'],
        ldl: [168, 165, 160, 158, 154, 148, 144, 142],
        glu: [102, 101, 100, 99, 99, 98, 98, 98],
        sys: [138, 136, 134, 132, 131, 130, 129, 128],
        tri: [190, 185, 180, 175, 172, 170, 168, 165]
    },
    byDoctor: {
        labels: ['Dr. Sophal\n(Calmette)', 'Dr. Kim\n(Vinmec)', 'Dr. Chan\n(Bumrungrad)'],
        ldl: [168, 152, 142],
        glu: [102, 100, 98],
        sys: [138, 132, 128],
        tri: [190, 175, 165]
    },
    overview: [
        { label: 'LDL Cholesterol', value: '142', unit: 'mg/dL', status: 'warn', trend: '−26 vs 2025', trendClass: 'down-good' },
        { label: 'Fasting Glucose', value: '98', unit: 'mg/dL', status: 'good', trend: 'Stable · in range', trendClass: 'down-good' },
        { label: 'Systolic BP', value: '128', unit: 'mmHg', status: 'good', trend: '−10 vs 2025', trendClass: 'down-good' },
        { label: 'Triglycerides', value: '165', unit: 'mg/dL', status: 'warn', trend: '−25 vs 2025', trendClass: 'down-good' }
    ],
    summaryHeadline: 'Cardiovascular risk has declined substantially post-angioplasty. LDL cholesterol remains the one indicator to keep watching — controlled but still above the ideal target.',
    summaryBullets: [
        { text: 'BP trending down after lifestyle + medication adjustments', warn: false },
        { text: 'Fasting glucose stable within the reference range', warn: false },
        { text: 'LDL peaked above 160 mg/dL in 2024–2025 — now re-controlled, continue Atorvastatin', warn: true }
    ],
    // Imaging & specialized tests — distinct from blood labs
    imaging: [
        {
            type: 'MRI',
            modality: 'mri',
            region: 'Brain MRI · T2-weighted',
            date: 'Apr 2026',
            doctor: 'Dr. Chan · Bumrungrad',
            status: 'normal',
            statusLabel: 'Normal',
            finding: 'No acute intracranial abnormality. White matter appears within normal limits for age. No signs of stroke or mass.',
            coordHook: 'View specialist report →'
        },
        {
            type: 'Echocardiogram',
            modality: 'echo',
            region: 'Cardiac Echo · 2D + Doppler',
            date: 'Mar 2026',
            doctor: 'Dr. Chan · Bumrungrad',
            status: 'attention',
            statusLabel: 'Follow up',
            finding: 'Ejection fraction 58% (normal). Mild mitral regurgitation. LAD stent patent — post-angioplasty result excellent. Re-check in 6 months.',
            coordHook: 'Request specialist review →'
        },
        {
            type: 'Ultrasound',
            modality: 'us',
            region: 'Abdominal Ultrasound',
            date: 'Jan 2026',
            doctor: 'Dr. Kim · Vinmec',
            status: 'attention',
            statusLabel: 'Mild finding',
            finding: 'Grade 1 fatty liver. Gallbladder, kidneys, and pancreas unremarkable. Dietary modification advised.',
            coordHook: 'Ask a nutritionist →'
        },
        {
            type: 'CT Angiography',
            modality: 'ct',
            region: 'Coronary CT Angiography',
            date: 'Dec 2025',
            doctor: 'Dr. Sophal · Calmette, PP',
            status: 'review',
            statusLabel: 'Awaiting specialist',
            finding: '70% stenosis in proximal LAD. Recommend invasive coronary angiography — patient referred abroad for angioplasty + stent.',
            coordHook: 'Open hospital coordination →'
        },
        {
            type: 'X-Ray',
            modality: 'xray',
            region: 'Chest X-Ray · PA view',
            date: 'Nov 2025',
            doctor: 'Dr. Sophal · Calmette, PP',
            status: 'normal',
            statusLabel: 'Clear',
            finding: 'Lungs clear. Heart size within normal limits. No pleural effusion or consolidation.',
            coordHook: 'View full report →'
        }
    ],
    // Doctor-grouped notes (multiple visits per doctor)
    doctorFolders: [
        {
            id: 'chan',
            name: 'Dr. Chan',
            clinic: 'Bumrungrad International · Bangkok',
            specialty: 'Interventional Cardiology',
            visitCount: 3,
            visits: [
                {
                    date: 'APR 2026',
                    subject: 'Post-procedure MRI review',
                    text: 'MRI clear — no neurological complications post-angioplasty. Patient tolerating Atorvastatin well. No chest pain episodes reported. Continue 6-month surveillance.'
                },
                {
                    date: 'MAR 2026',
                    subject: 'Post-angioplasty follow-up',
                    text: 'Post-angioplasty recovery is excellent. LDL dropped from 168 to 142 after combination of lifestyle change and Atorvastatin 20mg. Continue medication and re-check in 6 months. Echocardiogram shows patent stent.'
                },
                {
                    date: 'MAY 2026',
                    subject: 'Coronary angioplasty + stent',
                    text: 'Successful PCI with stent placement in proximal LAD. No intra-operative complications. Patient discharged on day 3 with standard cardiac rehabilitation plan.'
                }
            ]
        },
        {
            id: 'sophal',
            name: 'Dr. Sophal',
            clinic: 'Calmette Hospital · Phnom Penh',
            specialty: 'General Cardiology',
            visitCount: 3,
            visits: [
                {
                    date: 'DEC 2025',
                    subject: 'Stress test + referral abroad',
                    text: 'Stress test confirms partial blockage in LAD artery. CT angiography shows 70% stenosis. Patient referred for coronary angiography abroad — LDL 168 is the key risk factor. Treatment priority.'
                },
                {
                    date: 'NOV 2025',
                    subject: 'Chest pain evaluation',
                    text: 'Patient presented with exertional chest pain. ECG shows minor ST-T changes. Chest X-ray clear. Ordered CT angiography and stress test. Started on aspirin 81mg.'
                },
                {
                    date: 'MAR 2023',
                    subject: 'Annual physical',
                    text: 'Borderline cholesterol. Patient counseled on diet. No medication started at this time. Continue lifestyle modifications. Repeat lipid panel in 6 months.'
                }
            ]
        },
        {
            id: 'kim',
            name: 'Dr. Kim',
            clinic: 'Vinmec International · Ho Chi Minh',
            specialty: 'Internal Medicine',
            visitCount: 2,
            visits: [
                {
                    date: 'JAN 2026',
                    subject: 'Annual check-up + ultrasound',
                    text: 'Grade 1 fatty liver detected on abdominal ultrasound. BP improved (132/86). Advised weight loss and reduction of saturated fat. Counseled on Mediterranean-style diet.'
                },
                {
                    date: 'JUN 2024',
                    subject: 'Routine health screening',
                    text: 'BP slightly elevated (134/86). LDL 161 — borderline high. Advised weight loss and reduction of saturated fat. Repeat lipid panel in 3 months. No medication at this time.'
                }
            ]
        }
    ],
};


let mdChartState = {
    period: 'year',     // 'year' | 'month' | 'doctor'
    indicator: 'ldl'
};

let mdActiveHospital = null;
const mdImagingHospitalMeta = {
    'Bumrungrad': { city: 'Bangkok, Thailand', logoCls: 'emerald', initials: 'BH' },
    'Bumrungrad, BKK': { city: 'Bangkok, Thailand', logoCls: 'emerald', initials: 'BH' },
    'Vinmec': { city: 'Ho Chi Minh, Vietnam', logoCls: 'sand', initials: 'VM' },
    'Calmette': { city: 'Phnom Penh, Cambodia', logoCls: 'coral', initials: 'CL' },
    'Calmette, PP': { city: 'Phnom Penh, Cambodia', logoCls: 'coral', initials: 'CL' },
    'Subang Jaya': { city: 'Kuala Lumpur, Malaysia', logoCls: 'emerald', initials: 'SJ' },
    'Other': { city: 'Other facility', logoCls: 'sand', initials: 'OT' }
};

function showResultsDashboard(source) {
    const results = document.getElementById('md-results');
    results.classList.add('visible');
    results.classList.remove('preview-hidden');
    mdActiveHospital = null;

    // Reset preview toggle state
    const toggleBtn = document.getElementById('md-preview-toggle');
    if (toggleBtn) toggleBtn.classList.add('previewing');

    const tag = document.getElementById('md-results-source-tag');
    tag.textContent = source === 'sample'
        ? 'SAMPLE PATIENT DATA · TUTORIAL MODE'
        : 'TRANSLATED FROM YOUR UPLOAD · DEMO DATA';

    renderOverviewCards();
    renderIndicatorChips();
    renderChart();
    renderImagingCards();
    renderDoctorFolders();
    renderSummary();

    // Smooth scroll to results
    setTimeout(() => {
        results.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 100);
}

function hideResults() {
    document.getElementById('md-results').classList.remove('visible');
}

// Preview toggle — hides chart/notes/imaging but keeps the action row visible
function togglePreview(btn) {
    const results = document.getElementById('md-results');
    results.classList.toggle('preview-hidden');
    btn.classList.toggle('previewing');
}

// Share with doctor — opens modal with PDF preview + native share options
function shareWithDoctor() {
    // Populate modal with current user info
    const patientEl = document.getElementById('pdf-patient-name');
    const dobEl = document.getElementById('pdf-patient-dob');
    const genEl = document.getElementById('pdf-gen-date');
    if (patientEl) patientEl.textContent = mdPortfolioUser ? mdPortfolioUser.username : 'Sample Patient';
    if (dobEl) dobEl.textContent = mdPortfolioUser ? mdPortfolioUser.dob : '—';
    if (genEl) {
        const d = new Date();
        genEl.textContent = d.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
    }
    document.getElementById('md-share-overlay').classList.add('active');
}

function closeShareOverlay() {
    document.getElementById('md-share-overlay').classList.remove('active');
}

// Native share sheet — uses Web Share API when available
// This is the ONLY cross-platform mechanism. On iOS 12.2+ and Android Chrome,
// it opens the native share sheet which includes AirDrop (iOS), Nearby Share
// (Android), WhatsApp, Telegram, and any other installed share-capable app.
// AirDrop is Apple-to-Apple only — cross-platform (iOS to Android) uses
// WhatsApp, Telegram, or email inside the share sheet.
async function triggerNativeShare() {
    const patientName = mdPortfolioUser ? mdPortfolioUser.username : 'Sample Patient';
    const shareData = {
        title: `Medhub24 Health Portfolio — ${patientName}`,
        text: `${patientName}'s health portfolio. Includes 9 lab results and 5 imaging studies. Secure link expires in 48 hours.`,
        url: window.location.href  // In production: link to hosted PDF with 48hr token
    };

    if (navigator.share) {
        try {
            await navigator.share(shareData);
            closeShareOverlay();
        } catch (err) {
            // User cancelled — just close silently
            if (err.name !== 'AbortError') {
                alert('Sharing failed: ' + err.message);
            }
        }
    } else {
        alert('📤 Demo: Your browser does not support the native share sheet. In the Medhub24 mobile app, this opens iOS AirDrop / Android Nearby Share / WhatsApp / email — all in one sheet.');
    }
}

function demoShareMethod(method) {
    const labels = {
        whatsapp: '💬 Demo: Opens WhatsApp with a pre-filled message containing your secure PDF link.',
        telegram: '✈️ Demo: Opens Telegram with a pre-filled message containing your secure PDF link.',
        email: '✉️ Demo: Opens your email app with the PDF attached.',
        download: '⬇️ Demo: Downloads the PDF to your device so you can share it manually.',
        copy: '🔗 Demo: Link copied! Anyone with this link can view your PDF for 48 hours.'
    };
    alert(labels[method] || 'Demo share action');
    closeShareOverlay();
}

function renderOverviewCards() {
    const grid = document.getElementById('md-overview-grid');
    grid.innerHTML = mdSampleData.overview.map(o => `
                <div class="md-overview-card ${o.status}">
                    <div class="md-overview-label">${o.label}</div>
                    <div class="md-overview-value ${o.status === 'warn' ? 'critical' : 'good'}">${o.value}<span style="font-size:10px; color:var(--gray); font-weight:400; font-family:inherit; margin-left:3px;">${o.unit}</span></div>
                    <div class="md-overview-trend ${o.trendClass}">${o.trend}</div>
                </div>
            `).join('');
}

function renderIndicatorChips() {
    const el = document.getElementById('md-ind-chips');
    el.innerHTML = mdSampleData.indicators.map(ind => {
        const isCritical = ind.key === 'ldl' || ind.key === 'tri';
        return `<div class="md-ind-chip ${isCritical ? 'critical' : ''} ${ind.key === mdChartState.indicator ? 'active' : ''}"
                    onclick="selectIndicator('${ind.key}')">${ind.name}</div>`;
    }).join('');
}

function selectIndicator(key) {
    mdChartState.indicator = key;
    renderIndicatorChips();
    renderChart();
}

function switchChartTab(el, period) {
    document.querySelectorAll('.md-tab').forEach(t => t.classList.remove('active'));
    el.classList.add('active');
    mdChartState.period = period;
    renderChart();
}

function renderChart() {
    const svg = document.getElementById('md-chart-svg');
    const ind = mdSampleData.indicators.find(i => i.key === mdChartState.indicator);
    const dataset = mdChartState.period === 'year'
        ? mdSampleData.yearly
        : mdChartState.period === 'month'
            ? mdSampleData.monthly
            : mdSampleData.byDoctor;
    const values = dataset[ind.key];
    const labels = dataset.labels;

    // Update chart title & unit
    const periodLabel = mdChartState.period === 'year' ? 'over years'
        : mdChartState.period === 'month' ? 'last 8 months'
            : 'by doctor';
    document.getElementById('md-chart-title').textContent = `${ind.name} · ${periodLabel}`;
    document.getElementById('md-chart-unit').textContent = `${ind.unit} · normal range ${ind.normalMin}–${ind.normalMax} · critical ≥ ${ind.critical}`;

    // Compute Y scale
    const allVals = values.concat([ind.normalMin, ind.normalMax, ind.critical]);
    let yMin = Math.min(...allVals) * 0.9;
    let yMax = Math.max(...allVals) * 1.08;
    yMin = Math.max(0, Math.floor(yMin / 10) * 10);
    yMax = Math.ceil(yMax / 10) * 10;
    const yRange = yMax - yMin;

    // Viewbox dimensions
    const W = 320, H = 180;
    const padL = 36, padR = 14, padT = 14, padB = 28;
    const innerW = W - padL - padR;
    const innerH = H - padT - padB;

    const xFor = i => padL + (labels.length <= 1 ? innerW / 2 : (innerW * i) / (labels.length - 1));
    const yFor = v => padT + innerH - ((v - yMin) / yRange) * innerH;

    // Normal-range band
    const bandY1 = yFor(ind.normalMax);
    const bandY2 = yFor(ind.normalMin);

    // Critical threshold line
    const critY = yFor(ind.critical);

    // Build line segments, switching colour when above critical
    const pts = values.map((v, i) => ({ x: xFor(i), y: yFor(v), v }));

    // Build a "normal" path (emerald) and "critical" path (coral) by segmenting
    // Each segment coloured by whether its *endpoint* is ≥ critical threshold.
    let normalPath = '';
    let criticalPath = '';
    for (let i = 0; i < pts.length - 1; i++) {
        const a = pts[i], b = pts[i + 1];
        const seg = `M${a.x.toFixed(1)} ${a.y.toFixed(1)} L${b.x.toFixed(1)} ${b.y.toFixed(1)} `;
        // If either endpoint is at or above critical threshold, colour this segment red
        if (a.v >= ind.critical || b.v >= ind.critical) {
            criticalPath += seg;
        } else {
            normalPath += seg;
        }
    }

    // X-axis tick labels
    const xTicks = labels.map((lab, i) => {
        const multiline = lab.includes('\n');
        const lines = multiline ? lab.split('\n') : [lab];
        return lines.map((line, idx) => `<text x="${xFor(i).toFixed(1)}" y="${(H - 10 + idx * 9).toFixed(1)}" text-anchor="middle" font-size="9" fill="#6B6B6B" font-family="Plus Jakarta Sans, sans-serif">${line}</text>`).join('');
    }).join('');

    // Y-axis gridlines (3 lines)
    const gridlines = [0, 0.5, 1].map(frac => {
        const y = padT + innerH * frac;
        const val = Math.round(yMax - frac * yRange);
        return `
                    <line x1="${padL}" y1="${y.toFixed(1)}" x2="${W - padR}" y2="${y.toFixed(1)}" stroke="#E5DFD5" stroke-width="1" stroke-dasharray="2 3"/>
                    <text x="${padL - 6}" y="${(y + 3).toFixed(1)}" text-anchor="end" font-size="9" fill="#9B9B9B" font-family="Plus Jakarta Sans, sans-serif">${val}</text>
                `;
    }).join('');

    // Point circles (red if above critical)
    const circles = pts.map(p => {
        const isCritical = p.v >= ind.critical;
        const color = isCritical ? '#E87968' : '#0B4F4A';
        const pulse = isCritical ? `<circle cx="${p.x.toFixed(1)}" cy="${p.y.toFixed(1)}" r="8" fill="${color}" opacity="0.25"><animate attributeName="r" values="6;12;6" dur="1.8s" repeatCount="indefinite"/><animate attributeName="opacity" values="0.3;0;0.3" dur="1.8s" repeatCount="indefinite"/></circle>` : '';
        return `
                    ${pulse}
                    <circle cx="${p.x.toFixed(1)}" cy="${p.y.toFixed(1)}" r="3.5" fill="#fff" stroke="${color}" stroke-width="2"/>
                    <text x="${p.x.toFixed(1)}" y="${(p.y - 9).toFixed(1)}" text-anchor="middle" font-size="9" font-weight="700" fill="${color}" font-family="Plus Jakarta Sans, sans-serif">${p.v}</text>
                `;
    }).join('');

    svg.innerHTML = `
                <defs>
                    <linearGradient id="bandGradient" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stop-color="#2D8F7A" stop-opacity="0.12"/>
                        <stop offset="100%" stop-color="#2D8F7A" stop-opacity="0.06"/>
                    </linearGradient>
                </defs>
                <!-- Normal-range band -->
                <rect x="${padL}" y="${Math.min(bandY1, bandY2).toFixed(1)}" width="${innerW}" height="${Math.abs(bandY2 - bandY1).toFixed(1)}" fill="url(#bandGradient)"/>
                <!-- Gridlines -->
                ${gridlines}
                <!-- Critical threshold line -->
                <line x1="${padL}" y1="${critY.toFixed(1)}" x2="${W - padR}" y2="${critY.toFixed(1)}" stroke="#E87968" stroke-width="1" stroke-dasharray="3 3" opacity="0.6"/>
                <text x="${W - padR - 2}" y="${(critY - 3).toFixed(1)}" text-anchor="end" font-size="8" fill="#E87968" font-weight="700" font-family="Plus Jakarta Sans, sans-serif">critical ≥ ${ind.critical}</text>
                <!-- Normal line -->
                <path d="${normalPath}" fill="none" stroke="#0B4F4A" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>
                <!-- Critical line -->
                <path d="${criticalPath}" fill="none" stroke="#E87968" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>
                <!-- Points -->
                ${circles}
                <!-- X axis labels -->
                ${xTicks}
            `;
}

// Render imaging / specialized test cards (MRI, Ultrasound, Echo, CT, X-Ray)
// Each modality gets a distinct visual signature in its tile.
// Group imaging by hospital, chronological (latest first) within each hospital
function getImagingHospitalGroups() {
    const byHospital = {};
    mdSampleData.imaging.forEach(img => {
        const parts = img.doctor.split('·').map(s => s.trim());
        const hospitalName = parts.length > 1 ? parts[1] : 'Other';
        if (!byHospital[hospitalName]) {
            byHospital[hospitalName] = { name: hospitalName, items: [] };
        }
        // Attach sortable date (parse "Apr 2026" style)
        img._sortKey = parseImagingDate(img.date);
        byHospital[hospitalName].items.push(img);
    });

    // Sort each hospital's items by date descending (latest first)
    Object.values(byHospital).forEach(grp => {
        grp.items.sort((a, b) => b._sortKey - a._sortKey);
    });

    // Sort hospitals by most-recent item (active hospital first)
    return Object.values(byHospital).sort((a, b) => b.items[0]._sortKey - a.items[0]._sortKey);
}

function renderImagingCards() {
    const el = document.getElementById('md-imaging-grid');
    const subtitleEl = document.getElementById('md-imaging-subtitle');
    if (!el) return;

    const groups = getImagingHospitalGroups();
    const activeGroup = groups.find(grp => grp.name === mdActiveHospital) || null;
    if (mdActiveHospital && !activeGroup) {
        mdActiveHospital = null;
    }

    if (subtitleEl) {
        subtitleEl.textContent = activeGroup
            ? `${activeGroup.name} folder open. Press back to return to the full hospital chain timeline.`
            : 'Scans and studies organized by hospital — chronological within each (latest first). Tap a hospital folder to focus on one hospital.';
    }

    const visibleGroups = activeGroup ? [activeGroup] : groups;

    el.innerHTML = visibleGroups.map(grp => {
        const meta = mdImagingHospitalMeta[grp.name] || mdImagingHospitalMeta['Other'];
        const isFocused = activeGroup && grp.name === activeGroup.name;
        const headAction = isFocused ? '' : `onclick='openHospitalDetail(${JSON.stringify(grp.name)})'`;
        const detailBar = isFocused ? `
                    <div class="md-hosp-detail-bar">
                        <button type="button" class="md-hosp-back-btn" onclick="exitHospitalDetail(event)">← All hospitals</button>
                        <div class="md-hosp-detail-note">Showing ${grp.items.length} tests from ${grp.name} only</div>
                    </div>
                ` : '';
        const timelineItems = grp.items.map(img => `
                    <div class="md-hosp-timeline-item ${img.status}">
                        <div class="md-hosp-timeline-dot"></div>
                        <div class="md-hosp-timeline-date">${img.date}</div>
                        <div class="md-hosp-timeline-test">
                            <div class="md-hosp-timeline-modality ${img.modality}">${getImagingVisualSvg(img.modality)}</div>
                            <div class="md-hosp-timeline-name">${img.region}</div>
                            <span class="md-hosp-timeline-status ${img.status}">${img.statusLabel}</span>
                        </div>
                        <div class="md-hosp-timeline-finding">
                            <strong style="color:var(--emerald); font-size:9px; letter-spacing:0.8px; text-transform:uppercase; display:block; margin-bottom:3px;">Finding — ${img.doctor.split('·')[0].trim()}</strong>
                            ${img.finding}
                        </div>
                    </div>
                `).join('');

        return `
                    <div class="md-hosp-group open ${isFocused ? 'focused' : ''}">
                        <div class="md-hosp-group-head" ${headAction}>
                            <div class="md-hosp-logo ${meta.logoCls}">${meta.initials}</div>
                            <div class="md-hosp-info">
                                <div class="md-hosp-name">${grp.name}</div>
                                <div class="md-hosp-meta">${meta.city} · latest: ${grp.items[0].date}</div>
                            </div>
                            <div class="md-hosp-count">${isFocused ? 'Focused view' : `${grp.items.length} tests`}</div>
                            <div class="md-hosp-chev">›</div>
                        </div>
                        <div class="md-hosp-body">
                            <div class="md-hosp-body-inner">
                                ${detailBar}
                                <div class="md-hosp-timeline">
                                    ${timelineItems}
                                </div>
                            </div>
                        </div>
                    </div>
                `;
    }).join('');
}

function openHospitalDetail(hospitalName) {
    mdActiveHospital = hospitalName;
    renderImagingCards();
    const grid = document.getElementById('md-imaging-grid');
    if (grid) {
        grid.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }
}

function exitHospitalDetail(event) {
    if (event) event.stopPropagation();
    mdActiveHospital = null;
    renderImagingCards();
    const grid = document.getElementById('md-imaging-grid');
    if (grid) {
        grid.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }
}

// Parse informal imaging date strings ("Apr 2026", "Mar 2026") into sortable numbers
function parseImagingDate(s) {
    const months = { Jan: 0, Feb: 1, Mar: 2, Apr: 3, May: 4, Jun: 5, Jul: 6, Aug: 7, Sep: 8, Oct: 9, Nov: 10, Dec: 11 };
    const m = s.match(/([A-Za-z]{3})\s+(\d{4})/);
    if (!m) return 0;
    return new Date(parseInt(m[2]), months[m[1]] || 0, 1).getTime();
}

// Stylized modality-specific SVG visuals — no real medical images used
function getImagingVisualSvg(modality) {
    switch (modality) {
        case 'mri':
            // Stylized brain silhouette
            return `<svg viewBox="0 0 74 74" xmlns="http://www.w3.org/2000/svg">
                        <path d="M37 12 C25 12 18 20 18 32 C18 38 20 42 20 46 C20 54 25 60 30 60 C32 60 33 58 33 56 L33 46 C33 44 34 43 35 43 C36 43 37 44 37 46 C37 44 38 43 39 43 C40 43 41 44 41 46 L41 56 C41 58 42 60 44 60 C49 60 54 54 54 46 C54 42 56 38 56 32 C56 20 49 12 37 12 Z" fill="none" stroke="#E8C9A0" stroke-width="1.8"/>
                        <path d="M37 18 C37 26 37 34 37 46" stroke="#D4A574" stroke-width="1" stroke-dasharray="2 2" fill="none" opacity="0.6"/>
                        <circle cx="28" cy="30" r="1.5" fill="#D4A574" opacity="0.5"/>
                        <circle cx="46" cy="34" r="1.5" fill="#D4A574" opacity="0.5"/>
                        <circle cx="30" cy="42" r="1" fill="#D4A574" opacity="0.5"/>
                        <circle cx="44" cy="24" r="1" fill="#D4A574" opacity="0.5"/>
                    </svg>`;
        case 'us':
            // Sonar wave cone
            return `<svg viewBox="0 0 74 74" xmlns="http://www.w3.org/2000/svg">
                        <path d="M37 14 L20 62 L54 62 Z" fill="none" stroke="#0B4F4A" stroke-width="1.5" opacity="0.9"/>
                        <circle cx="37" cy="18" r="3" fill="#0B4F4A"/>
                        <path d="M28 42 Q37 38 46 42" stroke="#0B4F4A" stroke-width="1.8" fill="none"/>
                        <path d="M25 50 Q37 44 49 50" stroke="#0B4F4A" stroke-width="1.8" fill="none" opacity="0.7"/>
                        <path d="M22 58 Q37 51 52 58" stroke="#0B4F4A" stroke-width="1.8" fill="none" opacity="0.5"/>
                        <circle cx="37" cy="40" r="2" fill="#0B4F4A"/>
                    </svg>`;
        case 'echo':
            // ECG / heart rhythm line
            return `<svg viewBox="0 0 74 74" xmlns="http://www.w3.org/2000/svg">
                        <path d="M37 20 C32 20 28 24 28 30 C28 40 37 48 37 48 C37 48 46 40 46 30 C46 24 42 20 37 20 Z" fill="#FAF7F2" opacity="0.9"/>
                        <path d="M8 42 L18 42 L22 32 L26 52 L30 36 L34 48 L38 42 L66 42" stroke="#FAF7F2" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>`;
        case 'ct':
            // CT slice with cross-hair
            return `<svg viewBox="0 0 74 74" xmlns="http://www.w3.org/2000/svg">
                        <circle cx="37" cy="37" r="22" fill="none" stroke="#FAF7F2" stroke-width="1.5" opacity="0.95"/>
                        <circle cx="37" cy="37" r="14" fill="none" stroke="#FAF7F2" stroke-width="1" opacity="0.6"/>
                        <line x1="15" y1="37" x2="59" y2="37" stroke="#FAF7F2" stroke-width="0.8" stroke-dasharray="3 3" opacity="0.6"/>
                        <line x1="37" y1="15" x2="37" y2="59" stroke="#FAF7F2" stroke-width="0.8" stroke-dasharray="3 3" opacity="0.6"/>
                        <circle cx="30" cy="32" r="2" fill="#FAF7F2" opacity="0.8"/>
                        <circle cx="43" cy="40" r="2.5" fill="#FAF7F2" opacity="0.9"/>
                    </svg>`;
        case 'xray':
            // Ribcage silhouette
            return `<svg viewBox="0 0 74 74" xmlns="http://www.w3.org/2000/svg">
                        <path d="M37 14 L37 62" stroke="#FAF7F2" stroke-width="1.8"/>
                        <path d="M22 22 Q30 28 37 28 Q44 28 52 22" stroke="#FAF7F2" stroke-width="1.5" fill="none"/>
                        <path d="M20 30 Q30 36 37 36 Q44 36 54 30" stroke="#FAF7F2" stroke-width="1.5" fill="none"/>
                        <path d="M18 38 Q30 44 37 44 Q44 44 56 38" stroke="#FAF7F2" stroke-width="1.5" fill="none"/>
                        <path d="M18 46 Q30 52 37 52 Q44 52 56 46" stroke="#FAF7F2" stroke-width="1.5" fill="none"/>
                        <circle cx="37" cy="18" r="5" fill="none" stroke="#FAF7F2" stroke-width="1.5"/>
                    </svg>`;
        default:
            return '<svg viewBox="0 0 74 74"><rect x="20" y="20" width="34" height="34" fill="none" stroke="#FAF7F2" stroke-width="1.5"/></svg>';
    }
}

function imagingCoordHook(type) {
    alert(`📋 Demo: In production, tapping this opens the full ${type} report + a chat thread with a specialist from one of our partner hospitals (Bumrungrad / Vinmec / Subang Jaya). Coordination fee: $150–300 per case depending on complexity.`);
}

// Render doctor folders (grouped, collapsible)
function renderDoctorFolders() {
    const el = document.getElementById('md-doc-folders');
    el.innerHTML = mdSampleData.doctorFolders.map((doc, idx) => {
        const visits = doc.visits.map(v => `
                    <div class="md-doc-visit">
                        <div class="md-doc-visit-head">
                            <div class="md-doc-visit-subject">${v.subject}</div>
                            <div class="md-doc-visit-date">${v.date}</div>
                        </div>
                        <div class="md-doc-visit-text">${v.text}</div>
                    </div>
                `).join('');

        return `
                    <div class="md-doc-folder" id="md-doc-folder-${doc.id}">
                        <div class="md-doc-folder-head" onclick="toggleDoctorFolder('${doc.id}')">
                            <div class="md-doc-folder-icon">👨‍⚕️</div>
                            <div class="md-doc-folder-info">
                                <div class="md-doc-folder-name">${doc.name}</div>
                                <div class="md-doc-folder-meta">${doc.specialty} · ${doc.clinic}</div>
                            </div>
                            <div class="md-doc-folder-count">${doc.visitCount} visits</div>
                            <div class="md-doc-folder-chev">›</div>
                        </div>
                        <div class="md-doc-folder-body">
                            <div class="md-doc-folder-body-inner">
                                ${visits}
                            </div>
                        </div>
                    </div>
                `;
    }).join('');
}

function toggleDoctorFolder(id) {
    const folder = document.getElementById('md-doc-folder-' + id);
    if (folder) folder.classList.toggle('expanded');
}


function renderSummary() {
    document.getElementById('md-summary-headline').textContent = mdSampleData.summaryHeadline;
    const ul = document.getElementById('md-summary-bullets');
    ul.innerHTML = mdSampleData.summaryBullets.map(b =>
        `<li class="${b.warn ? 'warn' : ''}">${b.text}</li>`
    ).join('');
}

// ---------- PAYMENT CHAIN (hospital spend timeline) ----------
// Sample data — in production aggregated from uploaded bills (categorized by OCR)
const mdPaymentChain = [
    {
        hospital: 'Bumrungrad International',
        city: 'Bangkok, Thailand',
        logoCls: 'emerald',
        initials: 'BH',
        total: 10450,
        years: [
            { year: 2026, amount: 9800 },
            { year: 2025, amount: 650 }
        ]
    },
    {
        hospital: 'Vinmec International',
        city: 'Ho Chi Minh, Vietnam',
        logoCls: 'sand',
        initials: 'VM',
        total: 4120,
        years: [
            { year: 2026, amount: 380 },
            { year: 2024, amount: 1420 },
            { year: 2023, amount: 2320 }
        ]
    },
    {
        hospital: 'Calmette Hospital',
        city: 'Phnom Penh, Cambodia',
        logoCls: 'coral',
        initials: 'CL',
        total: 3670,
        years: [
            { year: 2025, amount: 2150 },
            { year: 2023, amount: 820 },
            { year: 2022, amount: 700 }
        ]
    }
];

function renderPaymentChain() {
    const el = document.getElementById('pf-hosp-chain');
    if (!el) return;
    el.innerHTML = mdPaymentChain.map(h => {
        const years = h.years.map(y =>
            `<span class="pf-year-chip"><span class="yc-yr">${y.year}</span>$${y.amount.toLocaleString()}</span>`
        ).join('');
        const logoColor = h.logoCls === 'emerald' ? 'var(--emerald)' : h.logoCls === 'sand' ? 'var(--sand)' : 'var(--coral)';
        const textColor = h.logoCls === 'sand' ? 'var(--emerald-dark)' : 'var(--white)';
        return `
                    <div class="pf-hosp-chain-row">
                        <div class="pf-hosp-chain-logo" style="background: ${logoColor}; color: ${textColor};">${h.initials}</div>
                        <div class="pf-hosp-chain-info">
                            <div class="pf-hosp-chain-name">${h.hospital}</div>
                            <div class="pf-hosp-chain-city">${h.city}</div>
                            <div class="pf-hosp-chain-years" style="margin-top:5px; justify-content:flex-start; max-width:100%;">${years}</div>
                        </div>
                        <div class="pf-hosp-chain-total">$${h.total.toLocaleString()}</div>
                    </div>
                `;
    }).join('');
}

function uploadBillFlow() {
    alert('📎 Demo: In production, this opens the same upload flow as lab reports, but the extraction engine recognizes hospital-name, date, line items, and total — and auto-categorizes them into Hospital fees / Coordination / Travel / Other. Your spend chain updates automatically.');
}

// Initialize payment chain once DOM ready
document.addEventListener('DOMContentLoaded', () => {
    renderPaymentChain();
    captureMatchJourneyTemplate();
    initAccountJourneyScroll();
    initCoordinationCards();
});

// Close overlay on background click
document.addEventListener('click', (e) => {
    if (e.target.id === 'md-auth-overlay') closeAuthOverlay();
    if (e.target.id === 'md-upload-overlay') closeUploadOverlay();
    if (e.target.id === 'md-share-overlay') closeShareOverlay();
});

// ============= INIT =============
window.addEventListener('load', () => {
    autoDetectLang();
    // Run after stepIn animations settle so geometry is correct
    setTimeout(() => {
        syncJourneyUI(1);
    }, 1400);
});
window.addEventListener('resize', () => {
    syncJourneyUI(currentScreen);
});
document.addEventListener('click', (e) => {
    if (!e.target.closest('.lang-switcher')) toggleLangDropdown(false);
});
document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') toggleLangDropdown(false);
});


// ═══════════════════════════════════════════════════════════════════════════
// MEDHUB24 v3 — JAVASCRIPT (Modules 1, 2, 3)
// ═══════════════════════════════════════════════════════════════════════════

(function () {
    'use strict';

    /* ════════════════════════════════════════════════════════════════════════
       MODULE 2 · PRICE COMPARE v3
       - 6 packages with hospital images (CSS gradient + SVG)
       - Predictive search
       - FIXED comparison matrix using flex+horizontal-scroll
       - Smart tags: Best Value / Fastest Recovery / Most Comprehensive
       - Save / Contact actions
       ════════════════════════════════════════════════════════════════════════ */

    // ── Treatment suggestions ──
    const PC3_SUGGEST = {
        'k': ['Kidney Stone Treatment', 'Knee Replacement', 'Kidney Stone Surgery'],
        'ki': ['Kidney Stone Treatment', 'Kidney Stone Surgery'],
        'kid': ['Kidney Stone Treatment', 'Kidney Stone Surgery', 'Kidney Stone Removal'],
        'kidn': ['Kidney Stone Treatment', 'Kidney Stone Surgery', 'Kidney Stone Removal'],
        'kidney': ['Kidney Stone Treatment', 'Kidney Stone Surgery', 'Kidney Stone Removal', 'Kidney Transplant'],
        'kidney stone': ['Kidney Stone Treatment', 'Kidney Stone Surgery', 'Laser Lithotripsy'],
        'h': ['Heart Bypass', 'Hip Replacement', 'Hernia Surgery'],
        'he': ['Heart Bypass', 'Heart Valve Surgery', 'Hernia Surgery'],
        'hea': ['Heart Bypass', 'Heart Valve Surgery', 'Heart Check-up'],
        'heart': ['Heart Bypass (CABG)', 'Heart Valve Surgery', 'Coronary Angioplasty'],
        'c': ['Cancer Treatment', 'Cataract Surgery', 'Coronary Angioplasty'],
        'ca': ['Cancer Treatment', 'Cataract Surgery'],
        'can': ['Cancer Treatment', 'Cancer Screening'],
        'cancer': ['Cancer Screening', 'Tumor Removal', 'Chemotherapy'],
        'cataract': ['Cataract Surgery', 'Lens Replacement'],
        's': ['Spine Surgery', 'Skin Treatment'],
        'sp': ['Spine Surgery', 'Spinal Fusion'],
        'spine': ['Spinal Disc Surgery', 'Spinal Fusion', 'Lumbar Pain Treatment'],
        'd': ['Diabetes Check-up', 'Dental Implant'],
        'di': ['Diabetes Check-up', 'Dialysis'],
        'diab': ['Diabetes Full Check-up', 'Diabetes Management'],
        'l': ['Laser Lithotripsy', 'Liver Treatment'],
        'liver': ['Liver Cirrhosis Screening', 'Hepatitis B Treatment', 'Liver Transplant'],
    };

    // ── 6 packages with hospital imagery ──
    const PC3_PACKAGES = [
        {
            id: 'bumrungrad',
            hospital: 'Bumrungrad International',
            short: 'Bumrungrad',
            country: 'Thailand', flag: '🇹🇭', city: 'BANGKOK',
            procedure: 'Kidney Stone Treatment',
            imageClass: 'th',
            badges: [{ label: 'BEST VALUE', type: 'gold' }],
            price: 2450, originalPrice: 2800, discount: 12,
            stayDays: 3, stay: '3 Days', recoveryWeeks: '1–2 Weeks', recoveryDays: 10,
            valueScore: 8.7,
            bestFor: 'Best Value', bestForType: 'gold',
            includes: ['Surgeon Fee', 'Anesthesia', 'Hospital Stay', 'Medication', 'Lab Tests', 'CT/X-ray Imaging'],
            notIncluded: ['Post-discharge meds', 'Complication treatment'],
            freeServices: ['Airport Pickup', 'Interpreter', 'SIM Card', 'Lounge Access', 'Hotel voucher'],
            highlights: [
                'JCI-accredited · 520k intl patients/year',
                'English/Khmer interpreter included',
                'Includes airport pickup + lounge access',
            ],
        },
        {
            id: 'sunway',
            hospital: 'Sunway Medical Centre',
            short: 'Sunway',
            country: 'Malaysia', flag: '🇲🇾', city: 'SUBANG JAYA',
            procedure: 'Kidney Stone Treatment',
            imageClass: 'my',
            badges: [{ label: 'CHEAPEST', type: 'violet' }],
            price: 2150, originalPrice: 2400, discount: 10,
            stayDays: 2, stay: '2 Days', recoveryWeeks: '1–2 Weeks', recoveryDays: 10,
            valueScore: 8.2,
            bestFor: 'Budget Friendly', bestForType: 'violet',
            includes: ['Surgeon Fee', 'Anesthesia', 'Hospital Stay', 'Basic Medication', 'Lab Tests'],
            notIncluded: ['Post-discharge meds', 'CT scan', 'Extended stay'],
            freeServices: ['Airport Pickup', 'Interpreter', 'SIM Card'],
            highlights: [
                'Lowest base price · save up to $300',
                'MSQH accredited · 180k intl patients/yr',
                'Shortest stay (2 nights only)',
            ],
        },
        {
            id: 'fv',
            hospital: 'FV Hospital',
            short: 'FV Hospital',
            country: 'Vietnam', flag: '🇻🇳', city: 'HO CHI MINH CITY',
            procedure: 'Kidney Stone Treatment',
            imageClass: 'vn',
            badges: [{ label: 'FAST RECOVERY', type: 'sky' }],
            price: 2780, originalPrice: 3050, discount: 9,
            stayDays: 3, stay: '3–4 Days', recoveryWeeks: '1 Week', recoveryDays: 7,
            valueScore: 8.4,
            bestFor: 'Fast Recovery', bestForType: 'sky',
            includes: ['Surgeon Fee', 'Anesthesia', 'Hospital Stay', 'Medication', 'Lab Tests', 'Imaging', 'Physiotherapy'],
            notIncluded: ['Post-discharge meds', 'Complication treatment'],
            freeServices: ['Airport Pickup', 'Interpreter', 'SIM Card', 'Hotel Voucher'],
            highlights: [
                'Fastest recovery · 1-week protocol',
                'Includes physiotherapy session',
                'First JCI-accredited hospital in Vietnam',
            ],
        },
        {
            id: 'bangkok',
            hospital: 'Bangkok Hospital',
            short: 'Bangkok Hospital',
            country: 'Thailand', flag: '🇹🇭', city: 'BANGKOK',
            procedure: 'Kidney Stone Treatment',
            imageClass: 'th2',
            badges: [{ label: 'PREMIUM', type: 'coral' }],
            price: 3550, originalPrice: 3900, discount: 9,
            stayDays: 3, stay: '3 Days', recoveryWeeks: '1–2 Weeks', recoveryDays: 10,
            valueScore: 8.9,
            bestFor: 'Premium Care', bestForType: 'coral',
            includes: ['Surgeon Fee', 'Anesthesia', 'Private Suite', 'Medication', 'Lab Tests', 'CT+MRI Imaging', 'Follow-up visits', 'Post-discharge meds'],
            notIncluded: ['Complication treatment'],
            freeServices: ['Airport Pickup', 'Interpreter', 'SIM Card', 'VIP Lounge', 'Hotel 2N'],
            highlights: [
                'Private suite + dedicated nurse',
                'Includes 2 follow-up visits + meds',
                'Top-ranked Thailand · 800k intl patients',
            ],
        },
        {
            id: 'pantai',
            hospital: 'Pantai Hospital KL',
            short: 'Pantai KL',
            country: 'Malaysia', flag: '🇲🇾', city: 'KUALA LUMPUR',
            procedure: 'Kidney Stone Treatment',
            imageClass: 'my2',
            badges: [{ label: 'BALANCED', type: 'green' }],
            price: 2350, originalPrice: 2600, discount: 10,
            stayDays: 2, stay: '2–3 Days', recoveryWeeks: '1–2 Weeks', recoveryDays: 9,
            valueScore: 8.3,
            bestFor: 'Well Balanced', bestForType: 'green',
            includes: ['Surgeon Fee', 'Anesthesia', 'Hospital Stay', 'Medication', 'Lab Tests', 'Ultrasound'],
            notIncluded: ['Post-discharge meds', 'CT scan'],
            freeServices: ['Airport Pickup', 'Interpreter', 'Hotel Voucher'],
            highlights: [
                'Strong value · KL central location',
                'MSQH accredited',
                'Includes hotel voucher + interpreter',
            ],
        },
        {
            id: 'vinmec',
            hospital: 'Vinmec International',
            short: 'Vinmec',
            country: 'Vietnam', flag: '🇻🇳', city: 'HANOI',
            procedure: 'Kidney Stone Treatment',
            imageClass: 'vn2',
            badges: [{ label: 'COMPREHENSIVE', type: 'sky' }],
            price: 2920, originalPrice: 3250, discount: 10,
            stayDays: 4, stay: '3–4 Days', recoveryWeeks: '1 Week', recoveryDays: 8,
            valueScore: 8.5,
            bestFor: 'Most Comprehensive', bestForType: 'sky',
            includes: ['Surgeon Fee', 'Anesthesia', 'Hospital Stay', 'Medication', 'Lab Tests', 'CT/MRI Imaging', 'Follow-up visits', 'Physiotherapy'],
            notIncluded: ['Complication treatment'],
            freeServices: ['Airport Pickup', 'Interpreter', 'SIM Card', 'Hotel 1N'],
            highlights: [
                'Most comprehensive package · 8 inclusions',
                'JCI accredited · modern facility',
                'Includes follow-up + physiotherapy',
            ],
        },

        // ════ v4 · 15 NEW PACKAGES — General Surgery + Oncology ════
        // Each carries category + countryCode for the new browse-by-disease flow.

        // ── GENERAL SURGERY (8) ─────────────────────────────────────
        {
            id: 'gs01', category: 'general-surgery', countryCode: 'TH',
            hospital: 'Bumrungrad International', short: 'Bumrungrad',
            country: 'Thailand', flag: '🇹🇭', city: 'BANGKOK',
            procedure: 'Laparoscopic Appendectomy', imageClass: 'th',
            badges: [{ label: 'BEST VALUE', type: 'gold' }],
            price: 3450, originalPrice: 3950, discount: 13,
            stayDays: 2, stay: '2 Days', recoveryWeeks: '1 Week', recoveryDays: 7, valueScore: 8.6,
            bestFor: 'Best Value', bestForType: 'gold',
            includes: ['Surgeon Fee', 'Anesthesia', 'Hospital Stay', 'Medication', 'Lab Tests', 'Imaging'],
            notIncluded: ['Complication treatment', 'Extended stay'],
            freeServices: ['Airport Pickup', 'Interpreter', 'SIM Card'],
            highlights: ['Minimally invasive · 3-port technique', '24-hour discharge typical', 'Khmer-speaking nurse on call'],
        },
        {
            id: 'gs02', category: 'general-surgery', countryCode: 'MY',
            hospital: 'Sunway Medical Centre', short: 'Sunway',
            country: 'Malaysia', flag: '🇲🇾', city: 'SUBANG JAYA',
            procedure: 'Laparoscopic Cholecystectomy', imageClass: 'my',
            badges: [{ label: 'CHEAPEST', type: 'violet' }],
            price: 2850, originalPrice: 3200, discount: 11,
            stayDays: 2, stay: '1–2 Days', recoveryWeeks: '1–2 Weeks', recoveryDays: 10, valueScore: 8.3,
            bestFor: 'Budget Friendly', bestForType: 'violet',
            includes: ['Surgeon Fee', 'Anesthesia', 'Hospital Stay', 'Basic Medication', 'Lab Tests', 'Ultrasound'],
            notIncluded: ['Post-discharge meds', 'Extended stay'],
            freeServices: ['Airport Pickup', 'Interpreter'],
            highlights: ['Gallbladder removal · keyhole approach', 'Lowest entry price for laparoscopic GB', 'MSQH accredited'],
        },
        {
            id: 'gs03', category: 'general-surgery', countryCode: 'VN',
            hospital: 'FV Hospital', short: 'FV Hospital',
            country: 'Vietnam', flag: '🇻🇳', city: 'HO CHI MINH CITY',
            procedure: 'Inguinal Hernia Repair', imageClass: 'vn',
            badges: [{ label: 'FAST RECOVERY', type: 'sky' }],
            price: 2150, originalPrice: 2400, discount: 10,
            stayDays: 1, stay: '1 Day', recoveryWeeks: '1 Week', recoveryDays: 7, valueScore: 8.4,
            bestFor: 'Fast Recovery', bestForType: 'sky',
            includes: ['Surgeon Fee', 'Anesthesia', 'Hospital Stay', 'Mesh Implant', 'Medication', 'Lab Tests'],
            notIncluded: ['Bilateral repair (single side only)', 'Complication treatment'],
            freeServices: ['Airport Pickup', 'Interpreter', 'Hotel Voucher'],
            highlights: ['Day-surgery protocol · home same evening', 'Lightweight mesh included', 'French-Vietnamese surgeon team'],
        },
        {
            id: 'gs04', category: 'general-surgery', countryCode: 'TH',
            hospital: 'Bangkok Hospital', short: 'Bangkok Hospital',
            country: 'Thailand', flag: '🇹🇭', city: 'BANGKOK',
            procedure: 'Thyroid Lobectomy', imageClass: 'th2',
            badges: [{ label: 'PREMIUM', type: 'coral' }],
            price: 5250, originalPrice: 5800, discount: 9,
            stayDays: 3, stay: '2–3 Days', recoveryWeeks: '2 Weeks', recoveryDays: 14, valueScore: 8.8,
            bestFor: 'Premium Care', bestForType: 'coral',
            includes: ['Surgeon Fee', 'Anesthesia', 'Private Suite', 'Medication', 'Lab Tests', 'Pathology', 'Follow-up x2'],
            notIncluded: ['Total thyroidectomy', 'Complication treatment'],
            freeServices: ['Airport Pickup', 'Interpreter', 'VIP Lounge', 'Hotel 2N'],
            highlights: ['Endocrine-specialist surgeon', 'Voice-preservation nerve monitoring', 'Pathology result in 48 hrs'],
        },
        {
            id: 'gs05', category: 'general-surgery', countryCode: 'MY',
            hospital: 'Pantai Hospital KL', short: 'Pantai KL',
            country: 'Malaysia', flag: '🇲🇾', city: 'KUALA LUMPUR',
            procedure: 'Hemorrhoidectomy', imageClass: 'my2',
            badges: [{ label: 'BALANCED', type: 'green' }],
            price: 1850, originalPrice: 2050, discount: 10,
            stayDays: 1, stay: '1 Day', recoveryWeeks: '1–2 Weeks', recoveryDays: 10, valueScore: 8.1,
            bestFor: 'Well Balanced', bestForType: 'green',
            includes: ['Surgeon Fee', 'Anesthesia', 'Hospital Stay', 'Medication', 'Lab Tests'],
            notIncluded: ['Post-discharge stool softeners', 'Complication treatment'],
            freeServices: ['Airport Pickup', 'Interpreter', 'Hotel Voucher'],
            highlights: ['Stapled (PPH) technique available', 'Same-day discharge', 'KL central · easy travel'],
        },
        {
            id: 'gs06', category: 'general-surgery', countryCode: 'VN',
            hospital: 'Vinmec International', short: 'Vinmec',
            country: 'Vietnam', flag: '🇻🇳', city: 'HANOI',
            procedure: 'Bariatric Sleeve Gastrectomy', imageClass: 'vn2',
            badges: [{ label: 'COMPREHENSIVE', type: 'sky' }],
            price: 8400, originalPrice: 9200, discount: 9,
            stayDays: 4, stay: '3–4 Days', recoveryWeeks: '3 Weeks', recoveryDays: 21, valueScore: 8.7,
            bestFor: 'Most Comprehensive', bestForType: 'sky',
            includes: ['Surgeon Fee', 'Anesthesia', 'Hospital Stay', 'Medication', 'Lab Tests', 'CT Imaging', 'Dietitian Plan', 'Follow-up x3'],
            notIncluded: ['Complication treatment', 'Plastic surgery'],
            freeServices: ['Airport Pickup', 'Interpreter', 'SIM Card', 'Hotel 2N'],
            highlights: ['Includes 3-month dietitian programme', 'JCI accredited · modern OR', 'Bariatric specialist team'],
        },
        {
            id: 'gs07', category: 'general-surgery', countryCode: 'TH',
            hospital: 'Phyathai 2 Hospital', short: 'Phyathai 2',
            country: 'Thailand', flag: '🇹🇭', city: 'BANGKOK',
            procedure: 'Open Hernia Repair (Bilateral)', imageClass: 'th',
            badges: [{ label: 'BALANCED', type: 'green' }],
            price: 3100, originalPrice: 3400, discount: 9,
            stayDays: 2, stay: '2 Days', recoveryWeeks: '2 Weeks', recoveryDays: 14, valueScore: 8.2,
            bestFor: 'Well Balanced', bestForType: 'green',
            includes: ['Surgeon Fee', 'Anesthesia', 'Hospital Stay', 'Mesh (both sides)', 'Medication', 'Lab Tests'],
            notIncluded: ['Complication treatment', 'Post-discharge meds'],
            freeServices: ['Airport Pickup', 'Interpreter', 'SIM Card'],
            highlights: ['Bilateral repair single anesthesia', 'Khmer interpreter included', 'High-volume hernia center'],
        },
        {
            id: 'gs08', category: 'general-surgery', countryCode: 'MY',
            hospital: 'Mahkota Medical Centre', short: 'Mahkota',
            country: 'Malaysia', flag: '🇲🇾', city: 'MELAKA',
            procedure: 'Varicose Vein Laser Ablation', imageClass: 'my',
            badges: [{ label: 'FAST RECOVERY', type: 'sky' }],
            price: 2250, originalPrice: 2500, discount: 10,
            stayDays: 1, stay: 'Day Case', recoveryWeeks: '3–5 Days', recoveryDays: 4, valueScore: 8.0,
            bestFor: 'Fast Recovery', bestForType: 'sky',
            includes: ['Surgeon Fee', 'Local Anesthesia', 'Laser Treatment', 'Compression Stockings', 'Lab Tests'],
            notIncluded: ['Sclerotherapy add-on', 'Complication treatment'],
            freeServices: ['Airport Pickup', 'Interpreter', 'Hotel 1N'],
            highlights: ['Walk-in / walk-out same day', 'EVLA endovenous laser', 'Stockings included'],
        },

        // ── ONCOLOGY (7) ────────────────────────────────────────────
        {
            id: 'on01', category: 'oncology', countryCode: 'TH',
            hospital: 'Bumrungrad International', short: 'Bumrungrad',
            country: 'Thailand', flag: '🇹🇭', city: 'BANGKOK',
            procedure: 'Breast Cancer Lumpectomy', imageClass: 'th',
            badges: [{ label: 'BEST VALUE', type: 'gold' }],
            price: 6850, originalPrice: 7600, discount: 10,
            stayDays: 3, stay: '2–3 Days', recoveryWeeks: '3 Weeks', recoveryDays: 21, valueScore: 8.9,
            bestFor: 'Best Value', bestForType: 'gold',
            includes: ['Surgeon Fee', 'Anesthesia', 'Hospital Stay', 'Sentinel Node Biopsy', 'Medication', 'Pathology', 'Imaging'],
            notIncluded: ['Chemotherapy', 'Radiotherapy', 'Reconstruction'],
            freeServices: ['Airport Pickup', 'Interpreter', 'SIM Card', 'Hotel 1N'],
            highlights: ['Breast-conserving surgery', 'Sentinel lymph node biopsy included', 'Pathology in 72 hrs'],
        },
        {
            id: 'on02', category: 'oncology', countryCode: 'MY',
            hospital: 'Sunway Medical Centre', short: 'Sunway',
            country: 'Malaysia', flag: '🇲🇾', city: 'SUBANG JAYA',
            procedure: 'Colon Cancer Resection (Laparoscopic)', imageClass: 'my',
            badges: [{ label: 'CHEAPEST', type: 'violet' }],
            price: 9450, originalPrice: 10500, discount: 10,
            stayDays: 6, stay: '5–7 Days', recoveryWeeks: '4 Weeks', recoveryDays: 28, valueScore: 8.5,
            bestFor: 'Budget Friendly', bestForType: 'violet',
            includes: ['Surgeon Fee', 'Anesthesia', 'Hospital Stay', 'Pathology', 'Medication', 'Lab Tests', 'CT Imaging'],
            notIncluded: ['Adjuvant chemotherapy', 'Stoma supplies'],
            freeServices: ['Airport Pickup', 'Interpreter', 'Hotel 2N'],
            highlights: ['Lowest cost laparoscopic colectomy in region', 'Multidisciplinary tumor board', 'MSQH accredited'],
        },
        {
            id: 'on03', category: 'oncology', countryCode: 'VN',
            hospital: 'Vinmec International', short: 'Vinmec',
            country: 'Vietnam', flag: '🇻🇳', city: 'HANOI',
            procedure: 'Chemotherapy Cycle (per session)', imageClass: 'vn2',
            badges: [{ label: 'BALANCED', type: 'green' }],
            price: 1450, originalPrice: 1650, discount: 12,
            stayDays: 1, stay: 'Day Case', recoveryWeeks: '—', recoveryDays: 0, valueScore: 8.3,
            bestFor: 'Well Balanced', bestForType: 'green',
            includes: ['Oncologist Consult', 'Day Care Bed', 'Standard Chemo Drugs', 'Anti-emetics', 'Lab Tests', 'Port Care'],
            notIncluded: ['Targeted therapy', 'Immunotherapy', 'PET-CT imaging'],
            freeServices: ['Airport Pickup', 'Interpreter', 'Hotel Voucher'],
            highlights: ['Per-cycle pricing · pay as you go', 'Includes premedication + monitoring', 'Khmer-speaking patient liaison'],
        },
        {
            id: 'on04', category: 'oncology', countryCode: 'TH',
            hospital: 'Bangkok Hospital', short: 'Bangkok Hospital',
            country: 'Thailand', flag: '🇹🇭', city: 'BANGKOK',
            procedure: 'Prostate Cancer (Robotic Prostatectomy)', imageClass: 'th2',
            badges: [{ label: 'PREMIUM', type: 'coral' }],
            price: 14800, originalPrice: 16200, discount: 9,
            stayDays: 4, stay: '3–4 Days', recoveryWeeks: '4 Weeks', recoveryDays: 28, valueScore: 9.0,
            bestFor: 'Premium Care', bestForType: 'coral',
            includes: ['Surgeon Fee', 'Robot Time', 'Anesthesia', 'Private Suite', 'Pathology', 'Catheter Care', 'Follow-up x3'],
            notIncluded: ['Adjuvant therapy', 'Complication treatment'],
            freeServices: ['Airport Pickup', 'Interpreter', 'VIP Lounge', 'Hotel 3N'],
            highlights: ['da Vinci robotic system', 'Nerve-sparing technique', 'Top-ranked urology in SE Asia'],
        },
        {
            id: 'on05', category: 'oncology', countryCode: 'MY',
            hospital: 'Pantai Hospital KL', short: 'Pantai KL',
            country: 'Malaysia', flag: '🇲🇾', city: 'KUALA LUMPUR',
            procedure: 'Radiotherapy (IMRT, full course)', imageClass: 'my2',
            badges: [{ label: 'COMPREHENSIVE', type: 'sky' }],
            price: 7200, originalPrice: 8000, discount: 10,
            stayDays: 0, stay: 'Outpatient', recoveryWeeks: '6 Weeks', recoveryDays: 42, valueScore: 8.6,
            bestFor: 'Most Comprehensive', bestForType: 'sky',
            includes: ['Radiation Oncologist', 'Simulation + Planning', 'Daily Sessions (~30)', 'Onsite Imaging', 'Lab Tests'],
            notIncluded: ['Concurrent chemo', 'Complication treatment'],
            freeServices: ['Airport Pickup', 'Interpreter', 'SIM Card', 'Long-stay Apartment'],
            highlights: ['IMRT precision delivery', 'Full 6-week course included', 'Nearby long-stay accommodation'],
        },
        {
            id: 'on06', category: 'oncology', countryCode: 'VN',
            hospital: 'FV Hospital', short: 'FV Hospital',
            country: 'Vietnam', flag: '🇻🇳', city: 'HO CHI MINH CITY',
            procedure: 'Lung Cancer VATS Lobectomy', imageClass: 'vn',
            badges: [{ label: 'FAST RECOVERY', type: 'sky' }],
            price: 11200, originalPrice: 12400, discount: 10,
            stayDays: 5, stay: '4–5 Days', recoveryWeeks: '3 Weeks', recoveryDays: 21, valueScore: 8.7,
            bestFor: 'Fast Recovery', bestForType: 'sky',
            includes: ['Surgeon Fee', 'Anesthesia', 'Hospital Stay', 'Pathology', 'CT Imaging', 'Chest Drain Care', 'Physio'],
            notIncluded: ['Adjuvant therapy', 'Complication treatment'],
            freeServices: ['Airport Pickup', 'Interpreter', 'Hotel 2N'],
            highlights: ['Video-assisted thoracoscopic surgery', 'Faster recovery vs open thoracotomy', 'JCI accredited'],
        },
        {
            id: 'on07', category: 'oncology', countryCode: 'TH',
            hospital: 'Phyathai 2 Hospital', short: 'Phyathai 2',
            country: 'Thailand', flag: '🇹🇭', city: 'BANGKOK',
            procedure: 'Cancer Screening Panel (Comprehensive)', imageClass: 'th',
            badges: [{ label: 'BEST VALUE', type: 'gold' }],
            price: 950, originalPrice: 1180, discount: 19,
            stayDays: 0, stay: 'Outpatient · 1 Day', recoveryWeeks: '—', recoveryDays: 0, valueScore: 8.4,
            bestFor: 'Best Value', bestForType: 'gold',
            includes: ['Tumor Markers Panel', 'Low-dose CT Chest', 'Abdominal US', 'Mammogram or PSA', 'Pap Smear (F)', 'Consultation'],
            notIncluded: ['Biopsy if abnormal', 'PET-CT'],
            freeServices: ['Airport Pickup', 'Interpreter', 'Hotel 1N'],
            highlights: ['Single-day comprehensive screen', 'Age-tailored panel (M/F)', 'Results in 24 hrs with consult'],
        },

    ];

    // ── State ──
    const pc3 = {
        selectedIds: [],
        sort: 'value',
        tier: 'signature',
        searchText: '',
        saved: false,
    };

    // ── Helpers ──
    const $ = id => document.getElementById(id);

    function pc3Toast(msg) {
        const t = $('pc3Toast');
        if (!t) return;
        t.textContent = msg;
        t.classList.add('active');
        clearTimeout(window.__pc3ToastTimer);
        window.__pc3ToastTimer = setTimeout(() => t.classList.remove('active'), 1800);
    }

    function pc3SortPackages(pkgs) {
        const arr = [...pkgs];
        if (pc3.sort === 'cheap') arr.sort((a, b) => a.price - b.price);
        else if (pc3.sort === 'recovery') arr.sort((a, b) => a.recoveryDays - b.recoveryDays);
        else if (pc3.sort === 'premium') arr.sort((a, b) => b.price - a.price);
        else arr.sort((a, b) => b.valueScore - a.valueScore);
        return arr;
    }

    function pc3GetTier(p) {
        if (!p || typeof p.price !== 'number') return 'signature';
        if (p.price >= 8000) return 'concierge';
        if (p.price >= 3000) return 'signature';
        return 'essential';
    }

    function pc3GetTierLabel(p) {
        const tier = pc3GetTier(p);
        if (tier === 'concierge') return 'Concierge Portfolio';
        if (tier === 'essential') return 'Essential Portfolio';
        return 'Signature Portfolio';
    }

    function pc3GetVisualType(p) {
        const procedure = (p.procedure || '').toLowerCase();
        if (procedure.includes('kidney stone') || procedure.includes('lithotripsy')) return 'kidney-stone';
        if (procedure.includes('append')) return 'appendix';
        if (procedure.includes('chole') || procedure.includes('gall')) return 'gallbladder';
        if (procedure.includes('hernia')) return 'hernia';
        if (procedure.includes('thyroid')) return 'thyroid';
        if (procedure.includes('hemorrhoid')) return 'colorectal';
        if (procedure.includes('bariatric') || procedure.includes('gastrectomy')) return 'stomach';
        if (procedure.includes('varicose') || procedure.includes('vein')) return 'vein';
        if (procedure.includes('breast')) return 'breast-cancer';
        if (procedure.includes('colon')) return 'colon-cancer';
        if (procedure.includes('chemo')) return 'chemo';
        if (procedure.includes('prostate')) return 'prostate';
        if (procedure.includes('radio')) return 'radiotherapy';
        if (procedure.includes('lung')) return 'lung';
        if (procedure.includes('screening')) return 'screening';
        return pc3GetCategory(p);
    }

    function pc3ProcedureVisual(p) {
        const type = pc3GetVisualType(p);
        const title = (p.procedure || 'Treatment') + ' visual';
        const visualMap = {
            'kidney-stone': '<path class="pc3-organ" d="M24 17c-8 2-13 10-11 19 1 7 7 12 13 10 6-1 8-7 7-13-1-7 5-15-9-16Z"/><path class="pc3-organ alt" d="M42 17c8 2 13 10 11 19-1 7-7 12-13 10-6-1-8-7-7-13 1-7-5-15 9-16Z"/><circle class="pc3-stone" cx="24" cy="35" r="3"/><circle class="pc3-stone delay" cx="42" cy="30" r="2.5"/><path class="pc3-line" d="M31 44c4 3 9 3 13 0"/>',
            appendix: '<path class="pc3-organ" d="M22 17c13-7 28 2 27 16-.8 11-9 18-19 17-8-1-14-7-14-15 0-7 4-13 6-18Z"/><path class="pc3-line" d="M37 48c2 4 6 6 10 4"/><path class="pc3-pulse-line" d="M25 31h8l3-6 5 13 3-7h6"/>',
            gallbladder: '<path class="pc3-organ" d="M34 13c12 7 13 20 6 29-5 7-16 8-21 1-6-8-2-17 6-20 5-2 7-5 9-10Z"/><circle class="pc3-stone" cx="30" cy="35" r="3"/><circle class="pc3-stone delay" cx="38" cy="32" r="2.4"/><path class="pc3-line" d="M44 18c8 3 10 9 6 16"/>',
            hernia: '<path class="pc3-line" d="M18 19c8 11 20 13 30 0M20 49c7-10 23-10 30 0"/><circle class="pc3-organ" cx="34" cy="36" r="10"/><circle class="pc3-stone" cx="34" cy="36" r="4"/>',
            thyroid: '<path class="pc3-organ" d="M27 18c-9 2-11 14-3 21 5 4 10-2 10-8V20c0-2-3-3-7-2Z"/><path class="pc3-organ alt" d="M41 18c9 2 11 14 3 21-5 4-10-2-10-8V20c0-2 3-3 7-2Z"/><path class="pc3-pulse-line" d="M25 47h6l3-5 4 9 3-4h5"/>',
            colorectal: '<path class="pc3-line" d="M23 15c-7 7-8 16-3 23 4 5 11 5 15 0 5-6 2-14-4-16"/><path class="pc3-line" d="M41 15c7 7 8 16 3 23-4 5-11 5-15 0"/><circle class="pc3-stone" cx="31" cy="42" r="3"/>',
            stomach: '<path class="pc3-organ" d="M28 13c8 2 7 11 4 17-3 7 2 14 10 13 7-1 10-8 8-15-2-9-12-12-16-17"/><path class="pc3-line" d="M31 45c7 6 17 4 23-2"/><path class="pc3-pulse-line" d="M17 34h7l3-5 5 10 3-5h5"/>',
            vein: '<path class="pc3-line" d="M21 13c9 8 2 14 9 21 6 6 14 4 14 15"/><path class="pc3-line alt-line" d="M36 14c-8 7-1 13-7 19-5 5-12 4-12 15"/><circle class="pc3-stone" cx="30" cy="34" r="3"/><circle class="pc3-stone delay" cx="42" cy="48" r="2.5"/>',
            'breast-cancer': '<path class="pc3-organ" d="M24 25c-7 3-11 11-8 18 4 9 17 8 20-2 3 10 16 11 20 2 3-7-1-15-8-18-5-2-10-1-12 4-2-5-7-6-12-4Z"/><circle class="pc3-stone" cx="43" cy="39" r="4"/><path class="pc3-pulse-line" d="M20 18h8l3-5 4 10 3-5h8"/>',
            'colon-cancer': '<path class="pc3-line" d="M20 17h21c8 0 13 6 13 13s-5 13-13 13H28c-5 0-9-4-9-9s4-9 9-9h13"/><circle class="pc3-stone" cx="39" cy="43" r="3.2"/><circle class="pc3-stone delay" cx="49" cy="30" r="2.6"/>',
            chemo: '<path class="pc3-organ" d="M27 15h15v10l-5 6v17c0 5-10 5-10 0V31l-5-6V15Z"/><path class="pc3-line" d="M24 15h21M28 25h12"/><circle class="pc3-stone" cx="32" cy="39" r="2.4"/><circle class="pc3-stone delay" cx="37" cy="47" r="2.4"/>',
            prostate: '<path class="pc3-organ" d="M34 25c11-7 21 3 17 14-3 9-13 11-17 5-4 6-14 4-17-5-4-11 6-21 17-14Z"/><path class="pc3-line" d="M34 15v10M28 52h12"/><circle class="pc3-stone" cx="42" cy="37" r="3"/>',
            radiotherapy: '<circle class="pc3-organ" cx="34" cy="34" r="13"/><path class="pc3-ray" d="M34 8v15M34 45v15M8 34h15M45 34h15M16 16l11 11M41 41l11 11M52 16 41 27M27 41 16 52"/><circle class="pc3-stone" cx="34" cy="34" r="3"/>',
            lung: '<path class="pc3-organ" d="M31 19c-11 2-17 11-15 24 1 8 12 8 15 1V19Z"/><path class="pc3-organ alt" d="M37 19c11 2 17 11 15 24-1 8-12 8-15 1V19Z"/><path class="pc3-line" d="M34 14v35"/><circle class="pc3-stone" cx="43" cy="39" r="3"/>',
            screening: '<rect class="pc3-organ" x="18" y="18" width="30" height="30" rx="7"/><path class="pc3-line" d="M25 30h17M25 38h10"/><circle class="pc3-stone" cx="46" cy="46" r="7"/><path class="pc3-line" d="M51 51l7 7"/>',
            urology: '<path class="pc3-organ" d="M25 18c-8 2-12 10-10 18 2 7 9 10 14 6 6-5-1-14 7-22-3-2-6-3-11-2Z"/><path class="pc3-organ alt" d="M43 18c8 2 12 10 10 18-2 7-9 10-14 6-6-5 1-14-7-22 3-2 6-3 11-2Z"/><path class="pc3-pulse-line" d="M21 49h7l3-5 5 10 3-5h7"/>',
            'general-surgery': '<path class="pc3-organ" d="M18 21h32v27H18z"/><path class="pc3-line" d="M25 21v27M43 21v27M17 34h34"/><circle class="pc3-stone" cx="34" cy="34" r="4"/>',
            oncology: '<circle class="pc3-organ" cx="34" cy="34" r="16"/><circle class="pc3-stone" cx="34" cy="34" r="5"/><path class="pc3-ray" d="M34 9v10M34 49v10M9 34h10M49 34h10"/>',
        };
        return `<svg class="pc3-card-image-svg pc3-disease-svg pc3-disease-${type}" viewBox="0 0 68 68" role="img" aria-label="${title}">
                  <title>${title}</title>
                  ${visualMap[type] || visualMap.urology}
                </svg>`;
    }

    // ── Render package cards ──
    function pc3RenderCards() {
        const list = $('pc3CardsList');
        if (!list) return;
        const pkgs = pc3SortPackages(PC3_PACKAGES);

        list.innerHTML = pkgs.map(p => {
            const isSelected = pc3.selectedIds.includes(p.id);
            const badgeHtml = p.badges.map(b =>
                `<span class="pc3-card-badge ${b.type}">${b.label}</span>`
            ).join('');

            const highlightsHtml = p.highlights.map(h => `
        <div class="pc3-card-highlight">
          <svg class="pc3-card-highlight-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg>
          <span>${h}</span>
        </div>
      `).join('');

            return `
        <div class="pc3-card ${isSelected ? 'active' : ''}" data-id="${p.id}">
          <div class="pc3-card-image pc3-card-image-${p.imageClass}">
            ${pc3ProcedureVisual(p)}
            <div class="pc3-card-checkbox">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg>
            </div>
            <div class="pc3-card-badges">${badgeHtml}</div>
            <div class="pc3-card-image-loc">${p.city}</div>
            <div class="pc3-card-image-flag">${p.flag}</div>
          </div>
          <div class="pc3-card-body">
            <div class="pc3-card-procedure">${p.procedure}</div>
            <div class="pc3-card-hospital">${p.hospital}</div>
            <div class="pc3-card-country">${p.country}</div>
            <div class="pc3-card-price-row">
              <span class="pc3-card-price">$${p.price.toLocaleString()}</span>
              <span class="pc3-card-price-old">$${p.originalPrice.toLocaleString()}</span>
              <span class="pc3-card-discount">−${p.discount}%</span>
            </div>
            <div class="pc3-card-highlights">${highlightsHtml}</div>
            <div class="pc3-card-meta">
              <span class="pc3-card-meta-item">📅 <strong>${p.stay}</strong> stay</span>
              <span class="pc3-card-meta-item">⚡ <strong>${p.recoveryWeeks}</strong> recovery</span>
              <span class="pc3-card-meta-item">⭐ <strong>${p.valueScore}</strong>/10</span>
            </div>
          </div>
        </div>
      `;
        }).join('');

        list.querySelectorAll('.pc3-card').forEach(el => {
            el.addEventListener('click', () => pc3ToggleSelect(el.dataset.id));
        });
    }

    function pc3ToggleSelect(id) {
        if (pc3.selectedIds.includes(id)) {
            pc3.selectedIds = pc3.selectedIds.filter(x => x !== id);
        } else {
            if (pc3.selectedIds.length >= 4) {
                pc3Toast('Maximum 4 packages — deselect one first');
                return;
            }
            pc3.selectedIds.push(id);
        }
        pc3RenderCards();
        pc3UpdateFloatingCta();
    }

    function pc3UpdateFloatingCta() {
        const counter = $('pc3SelCounter');
        const floatCount = $('pc3FloatingCount');
        const btn = $('pc3CompareBtn');
        const label = $('pc3CTALabel');
        const basketTitle = $('pc3BasketTitle');
        const basketSub = $('pc3BasketSub');
        if (!counter || !btn || !label) return;

        const n = pc3.selectedIds.length;
        counter.textContent = `${n}/4`;
        if (floatCount) floatCount.textContent = String(n);
        if (basketTitle) basketTitle.textContent = n >= 2 ? `Compare Selected (${n})` : 'Compare Selected';
        if (basketSub) basketSub.textContent = n === 0 ? 'Tap packages to add · max 4' : `${n} selected · ready for comparison`;

        if (n === 0) {
            btn.disabled = true;
            label.textContent = 'Select 2 packages';
        } else if (n === 1) {
            btn.disabled = true;
            label.textContent = 'Add 1 more package';
        } else {
            btn.disabled = false;
            label.textContent = `Compare Selected (${n})`;
        }

    }

    // ── Predictive search ──
    function pc3RenderSuggest() {
        const input = $('pc3SearchInput');
        const box = $('pc3SuggestBox');
        const wrap = $('pc3SearchWrap');
        if (!input || !box) return;

        const q = (input.value || '').trim().toLowerCase();
        if (wrap) wrap.classList.toggle('has-value', !!q);

        if (!q) {
            box.classList.remove('open');
            box.innerHTML = '';
            return;
        }

        // Find best matching key (longest matching prefix)
        let best = null;
        for (const k of Object.keys(PC3_SUGGEST)) {
            if (q.startsWith(k)) {
                if (!best || k.length > best.length) best = k;
            }
        }

        if (!best) {
            box.classList.remove('open');
            box.innerHTML = '';
            return;
        }

        const items = PC3_SUGGEST[best];
        box.innerHTML = items.map((s, idx) => `
      <div class="pc3-suggest-item" data-val="${s}">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/>
        </svg>
        <span>${s}</span>
        ${idx === 0 ? '<span class="pc3-suggest-item-tag">Top result</span>' : ''}
      </div>
    `).join('');
        box.classList.add('open');

        box.querySelectorAll('.pc3-suggest-item').forEach(el => {
            el.addEventListener('click', () => {
                input.value = el.dataset.val;
                pc3.searchText = el.dataset.val;
                if (wrap) wrap.classList.add('has-value');
                box.classList.remove('open');
                pc3Toast(`Showing results for "${el.dataset.val}"`);
            });
        });
    }

    // ── Smart tagging logic ──
    function pc3ComputeSmartTags(selected) {
        const tags = {};
        if (selected.length < 2) return tags;
        // Best Value (highest valueScore)
        tags.bestValue = selected.reduce((a, b) => a.valueScore > b.valueScore ? a : b);
        // Fastest Recovery
        tags.fastestRecovery = selected.reduce((a, b) => a.recoveryDays < b.recoveryDays ? a : b);
        // Most Comprehensive (most includes)
        tags.mostComprehensive = selected.reduce((a, b) => a.includes.length > b.includes.length ? a : b);
        // Cheapest
        tags.cheapest = selected.reduce((a, b) => a.price < b.price ? a : b);
        return tags;
    }

    // ── Render comparison modal (FIXED LAYOUT) ──
    function pc3RenderCompareModal() {
        const selected = pc3.selectedIds.map(id => PC3_PACKAGES.find(p => p.id === id)).filter(Boolean);
        if (selected.length < 2) return;

        const tags = pc3ComputeSmartTags(selected);
        const recommended = tags.bestValue;

        // Subtitle
        const sub = $('pc3ModalSub');
        if (sub) sub.textContent = `Side-by-side · ${selected.length} hospital${selected.length > 1 ? 's' : ''}`;

        // ── Hospital header strip ──
        const strip = $('pc3CmpHeaderStrip');
        if (strip) {
            strip.innerHTML = selected.map(p => {
                const isRec = p.id === recommended.id;
                return `
          <div class="pc3-cmp-h-tile ${isRec ? 'recommended' : ''}" data-id="${p.id}">
            ${isRec ? '<div class="pc3-cmp-h-tile-rec">★ RECOMMENDED</div>' : ''}
            <div class="pc3-cmp-h-tile-img pc3-card-image-${p.imageClass}">
              <button class="pc3-cmp-h-tile-remove" data-remove="${p.id}" aria-label="Remove">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M18 6 6 18M6 6l12 12"/></svg>
              </button>
              <span class="pc3-cmp-h-tile-flag">${p.flag}</span>
            </div>
            <div class="pc3-cmp-h-tile-body">
              <div class="pc3-cmp-h-tile-name">${p.short}</div>
              <div class="pc3-cmp-h-tile-price">$${p.price.toLocaleString()}</div>
            </div>
          </div>
        `;
            }).join('');

            strip.querySelectorAll('[data-remove]').forEach(el => {
                el.addEventListener('click', (e) => {
                    e.stopPropagation();
                    const id = el.dataset.remove;
                    pc3.selectedIds = pc3.selectedIds.filter(x => x !== id);
                    if (pc3.selectedIds.length < 2) {
                        pc3CloseCompareModal();
                        pc3RenderCards();
                        pc3UpdateFloatingCta();
                        return;
                    }
                    pc3RenderCards();
                    pc3UpdateFloatingCta();
                    pc3RenderCompareModal();
                });
            });
        }

        // ── Smart tag banner ──
        const banner = $('pc3TagBanner');
        if (banner) {
            banner.innerHTML = `
        <div class="pc3-tag-banner-row">
          <span class="pc3-tag-banner-icon value">★</span>
          <span><strong>Best Value:</strong> ${tags.bestValue.short} — ${tags.bestValue.valueScore}/10</span>
        </div>
        <div class="pc3-tag-banner-row">
          <span class="pc3-tag-banner-icon recovery">⚡</span>
          <span><strong>Fastest Recovery:</strong> ${tags.fastestRecovery.short} — ${tags.fastestRecovery.recoveryWeeks}</span>
        </div>
        <div class="pc3-tag-banner-row">
          <span class="pc3-tag-banner-icon complete">✦</span>
          <span><strong>Most Comprehensive:</strong> ${tags.mostComprehensive.short} — ${tags.mostComprehensive.includes.length} inclusions</span>
        </div>
      `;
        }

        // ── Comparison Matrix (FLEX-BASED, scroll horizontally for 3+ pkgs) ──
        const matrix = $('pc3CmpMatrix');
        if (matrix) {
            let html = '';

            // Section: Financials
            html += '<div class="pc3-cmp-section">Financials</div>';
            html += pc3RenderRow('Price', selected, p => `<span class="pc3-cmp-row-cell price-cell ${p.id === recommended.id ? 'highlight' : ''}">$${p.price.toLocaleString()}</span>`, true);
            html += pc3RenderRow('Discount', selected, p => `<span class="pc3-cmp-row-cell"><span style="color:#10B981; font-weight:700;">−${p.discount}%</span><span class="delta">save $${(p.originalPrice - p.price).toLocaleString()}</span></span>`);
            html += pc3RenderRow('Value Score', selected, p => `<span class="pc3-cmp-row-cell"><strong>${p.valueScore.toFixed(1)}</strong>/10<div class="score-bar"><div class="score-fill" style="width:${p.valueScore * 10}%"></div></div></span>`);

            // Section: Logistics
            html += '<div class="pc3-cmp-section">Logistics</div>';
            html += pc3RenderRow('Length of Stay', selected, p => `<span class="pc3-cmp-row-cell">${p.stay}</span>`);
            html += pc3RenderRow('Recovery Time', selected, p => `<span class="pc3-cmp-row-cell">${p.recoveryWeeks}</span>`);
            html += pc3RenderRow('Best For', selected, p => `<span class="pc3-cmp-row-cell"><span class="pc3-cmp-tag-pill ${p.bestForType}">${p.bestFor}</span></span>`);

            // Section: Inclusions
            html += '<div class="pc3-cmp-section">What\'s Included</div>';
            html += pc3RenderRow('Includes', selected, p => `<span class="pc3-cmp-row-cell"><ul>${p.includes.slice(0, 5).map(i => `<li class="in">${i}</li>`).join('')}${p.includes.length > 5 ? `<li style="color:var(--gray);">+${p.includes.length - 5} more</li>` : ''}</ul></span>`);
            html += pc3RenderRow('Not Included', selected, p => `<span class="pc3-cmp-row-cell"><ul>${p.notIncluded.map(i => `<li class="out">${i}</li>`).join('')}</ul></span>`);

            // Section: Extras
            html += '<div class="pc3-cmp-section">Free Services</div>';
            html += pc3RenderRow('Bonus', selected, p => `<span class="pc3-cmp-row-cell"><ul>${p.freeServices.slice(0, 4).map(s => `<li class="in">${s}</li>`).join('')}${p.freeServices.length > 4 ? `<li style="color:var(--gray);">+${p.freeServices.length - 4} more</li>` : ''}</ul></span>`);

            matrix.innerHTML = html;
        }

        // ── AI Recommendation ──
        const recText = $('pc3AiRecText');
        if (recText) {
            const cheapest = tags.cheapest;
            let txt = `<strong>${recommended.hospital}</strong> in ${recommended.country} ${recommended.flag} offers the best overall value at <strong>${recommended.valueScore.toFixed(1)}/10</strong>. `;
            if (recommended.id !== cheapest.id) {
                txt += `If price is the priority, <strong>${cheapest.short}</strong> saves $${(recommended.price - cheapest.price).toLocaleString()}.`;
            } else {
                txt += `It's also the most affordable option among your selection.`;
            }
            recText.innerHTML = txt;
        }
    }

    function pc3RenderRow(label, selected, cellFn, highlight = false) {
        const cells = selected.map(p => cellFn(p)).join('');
        return `<div class="pc3-cmp-row ${highlight ? 'highlight' : ''}">
      <div class="pc3-cmp-row-label">${label}</div>
      ${cells}
    </div>`;
    }

    // ── Modal open/close ──
    function pc3OpenCompareModal() {
        if (pc3.selectedIds.length < 2) {
            pc3Toast('Select at least 2 packages to compare');
            return;
        }
        pc3RenderCompareModal();
        const modal = $('pc3CompareModal');
        if (modal) {
            modal.classList.add('active');
        }
        const basket = $('pc3Basket');
        if (basket) basket.classList.remove('expanded');
        const summary = $('pc3BasketSummary');
        if (summary) summary.setAttribute('aria-expanded', 'false');
    }

    function pc3CloseCompareModal() {
        const modal = $('pc3CompareModal');
        if (modal) modal.classList.remove('active');
    }

    // ── Wire events ──
    let _pc3EventsBound = false;
    function pc3InitEvents() {
        if (_pc3EventsBound) return;
        _pc3EventsBound = true;
        const input = $('pc3SearchInput');
        if (input) {
            input.addEventListener('input', pc3RenderSuggest);
            input.addEventListener('focus', pc3RenderSuggest);
        }
        const clearBtn = $('pc3ClearBtn');
        if (clearBtn) {
            clearBtn.addEventListener('click', () => {
                if (input) input.value = '';
                pc3.searchText = '';
                const wrap = $('pc3SearchWrap');
                if (wrap) wrap.classList.remove('has-value');
                const box = $('pc3SuggestBox');
                if (box) {
                    box.classList.remove('open');
                    box.innerHTML = '';
                }
            });
        }
        // Close suggest on outside click
        document.addEventListener('click', (e) => {
            const box = $('pc3SuggestBox');
            const wrap = $('pc3SearchWrap');
            if (!box || !wrap) return;
            if (!box.contains(e.target) && !wrap.contains(e.target)) {
                box.classList.remove('open');
            }
        });

        // Filter chips
        const chips = $('pc3Chips');
        if (chips) {
            chips.querySelectorAll('.pc3-chip').forEach(chip => {
                chip.addEventListener('click', () => {
                    chips.querySelectorAll('.pc3-chip').forEach(c => c.classList.remove('active'));
                    chip.classList.add('active');
                    pc3.sort = chip.dataset.sort;
                    pc3RenderCards();
                });
            });
        }

        const tierNav = $('pc3TierNav');
        if (tierNav) {
            tierNav.querySelectorAll('.pc3-tier-btn').forEach(btn => {
                btn.classList.toggle('active', btn.dataset.tier === pc3.tier);
                btn.addEventListener('click', () => pc3SetTier(btn.dataset.tier));
            });
        }

        // Compare button
        const cmpBtn = $('pc3CompareBtn');
        if (cmpBtn) cmpBtn.addEventListener('click', pc3OpenCompareModal);

        // Modal back / close
        const back = $('pc3ModalBack');
        const close = $('pc3ModalClose');
        if (back) back.addEventListener('click', pc3CloseCompareModal);
        if (close) close.addEventListener('click', pc3CloseCompareModal);

        // Click outside modal sheet to close
        const modal = $('pc3CompareModal');
        if (modal) {
            modal.addEventListener('click', (e) => {
                if (e.target === modal) pc3CloseCompareModal();
            });
        }

        // Save / Contact
        const saveBtn = $('pc3SaveCmpBtn');
        if (saveBtn) {
            saveBtn.addEventListener('click', () => {
                pc3.saved = !pc3.saved;
                saveBtn.classList.toggle('active', pc3.saved);
                pc3Toast(pc3.saved ? '✓ Comparison saved' : 'Removed from saved');
            });
        }
        const contactBtn = $('pc3ContactBtn');
        if (contactBtn) {
            contactBtn.addEventListener('click', () => {
                pc3Toast('📞 Connecting you with a coordinator…');
            });
        }
        const savedBtn = $('pc3SavedBtn');
        if (savedBtn) {
            savedBtn.addEventListener('click', () => pc3Toast('Saved comparisons feature coming soon'));
        }
    }

    // ════════════════════════════════════════════════════════════════════
    // v4 · BASKET + DUAL-MODE SEARCH + BROWSE-BY-CATEGORY
    // Operates on top of the existing pc3 state — no breaking changes.
    // ════════════════════════════════════════════════════════════════════

    // Default category fallback for package entries without explicit metadata.
    function pc3GetCategory(p) {
        if (p.category) return p.category;
        return 'urology';
    }
    function pc3GetCountryCode(p) {
        if (p.countryCode) return p.countryCode;
        if (p.country === 'Thailand') return 'TH';
        if (p.country === 'Malaysia') return 'MY';
        if (p.country === 'Vietnam') return 'VN';
        return '??';
    }

    // Disease categories
    const PC3_CATEGORIES = [
        { id: 'urology', icon: '🫘', name: 'Urology', color: '#0B4F4A', desc: 'Kidney, bladder, prostate' },
        { id: 'general-surgery', icon: '🩺', name: 'General Surgery', color: '#205C7F', desc: 'Hernia, gallbladder, thyroid' },
        { id: 'oncology', icon: '🎗️', name: 'Oncology', color: '#E87968', desc: 'Cancer screening & treatment' },
        { id: 'cardiology', icon: '❤️', name: 'Cardiology', color: '#C7423A', desc: 'Heart bypass, valves (coming)' },
        { id: 'orthopedics', icon: '🦴', name: 'Orthopedics', color: '#B97A0E', desc: 'Joints, spine (coming)' },
        { id: 'screening', icon: '🔬', name: 'Health Screening', color: '#3D2D78', desc: 'Annual full-body checks' },
    ];

    // Browse state
    const pc3Browse = {
        activeCategory: null,
        activeCountry: 'ALL',
    };

    // Render category tiles in the browse panel
    function pc3RenderCategories() {
        const grid = document.getElementById('pc3CatGrid');
        if (!grid) return;
        const counts = {};
        const tierPackages = PC3_PACKAGES.filter(p => pc3GetTier(p) === pc3.tier);
        tierPackages.forEach(p => {
            const c = pc3GetCategory(p);
            counts[c] = (counts[c] || 0) + 1;
        });
        grid.innerHTML = PC3_CATEGORIES.map(c => `
      <div class="pc3-cat-tile ${pc3Browse.activeCategory === c.id ? 'active' : ''}"
           data-cat="${c.id}" style="--cat-c: ${c.color};">
        <div class="pc3-cat-icon">${c.icon}</div>
        <div class="pc3-cat-name">${c.name}</div>
        <div class="pc3-cat-count">${counts[c.id] || 0} packages · ${c.desc}</div>
      </div>
    `).join('');
        grid.querySelectorAll('.pc3-cat-tile').forEach(el => {
            el.addEventListener('click', () => {
                const cat = el.dataset.cat;
                pc3Browse.activeCategory = (pc3Browse.activeCategory === cat) ? null : cat;
                pc3Browse.activeCountry = 'ALL';
                pc3RenderCategories();
                pc3RenderCountryFilter();
                pc3RenderCards();
            });
        });
    }

    // Render country filter pills (only when a category is active)
    function pc3RenderCountryFilter() {
        const wrap = document.getElementById('pc3CountryFilter');
        if (!wrap) return;
        if (!pc3Browse.activeCategory) {
            wrap.classList.remove('active');
            wrap.innerHTML = '';
            return;
        }
        const inCat = PC3_PACKAGES.filter(p => pc3GetCategory(p) === pc3Browse.activeCategory && pc3GetTier(p) === pc3.tier);
        const counts = inCat.reduce((a, p) => {
            const c = pc3GetCountryCode(p);
            a[c] = (a[c] || 0) + 1;
            return a;
        }, {});
        const countries = [
            { code: 'ALL', label: 'All countries', flag: '🌏' },
            { code: 'TH', label: 'Thailand', flag: '🇹🇭' },
            { code: 'MY', label: 'Malaysia', flag: '🇲🇾' },
            { code: 'VN', label: 'Vietnam', flag: '🇻🇳' },
        ];
        wrap.innerHTML = countries.map(c => {
            const count = c.code === 'ALL' ? inCat.length : (counts[c.code] || 0);
            if (count === 0 && c.code !== 'ALL') return '';
            return `<div class="pc3-country-pill ${pc3Browse.activeCountry === c.code ? 'active' : ''}" data-cc="${c.code}">
        <span>${c.flag}</span><span>${c.label}</span><span style="opacity:.6;">·&nbsp;${count}</span>
      </div>`;
        }).join('');
        wrap.classList.add('active');
        wrap.querySelectorAll('.pc3-country-pill').forEach(pill => {
            pill.addEventListener('click', () => {
                pc3Browse.activeCountry = pill.dataset.cc;
                pc3RenderCountryFilter();
                pc3RenderCards();
            });
        });
    }

    function pc3SetTier(tier) {
        if (!tier || pc3.tier === tier) return;
        pc3.tier = tier;
        const tierNav = document.getElementById('pc3TierNav');
        if (tierNav) {
            tierNav.querySelectorAll('.pc3-tier-btn').forEach(btn => {
                btn.classList.toggle('active', btn.dataset.tier === tier);
            });
        }
        pc3Browse.activeCountry = 'ALL';
        pc3RenderCategories();
        pc3RenderCountryFilter();
        pc3RenderCards();
    }

    // Filter packages by current browse state + free-text search
    function pc3FilterPackages(arr) {
        let out = [...arr];
        // browse filter
        if (pc3Browse.activeCategory) {
            out = out.filter(p => pc3GetCategory(p) === pc3Browse.activeCategory);
        }
        if (pc3Browse.activeCountry && pc3Browse.activeCountry !== 'ALL') {
            out = out.filter(p => pc3GetCountryCode(p) === pc3Browse.activeCountry);
        }
        if (pc3.tier) {
            out = out.filter(p => pc3GetTier(p) === pc3.tier);
        }
        // text search filter (works in both modes)
        const q = (pc3.searchText || '').trim().toLowerCase();
        if (q) {
            out = out.filter(p =>
                (p.procedure || '').toLowerCase().includes(q) ||
                (p.hospital || '').toLowerCase().includes(q) ||
                (p.country || '').toLowerCase().includes(q)
            );
        }
        return out;
    }

    // Wrap the original pc3RenderCards to inject filtering + grouping
    const __origPc3RenderCards = pc3RenderCards;
    pc3RenderCards = function () {
        const list = document.getElementById('pc3CardsList');
        if (!list) return;
        const filtered = pc3FilterPackages(PC3_PACKAGES);

        if (filtered.length === 0) {
            list.innerHTML = `
        <div class="pc3-empty-state">
          <div class="pc3-empty-state-icon">🔍</div>
          <div class="pc3-empty-state-title">No packages match your filter</div>
          <div class="pc3-empty-state-sub">Try a different category, country, or clear your search.</div>
        </div>`;
            pc3UpdateFloatingCta();
            pc3RenderBasket();
            return;
        }

        const sorted = pc3SortPackages(filtered);

        // If browse mode is active, group by country for clearer scanning
        const isBrowse = pc3Browse.activeCategory !== null && pc3Browse.activeCountry === 'ALL';
        let html = '';
        if (isBrowse) {
            // group by country
            const groups = {};
            sorted.forEach(p => {
                const k = pc3GetCountryCode(p);
                (groups[k] = groups[k] || []).push(p);
            });
            const order = ['TH', 'MY', 'VN'];
            const countryName = { TH: '🇹🇭 Thailand', MY: '🇲🇾 Malaysia', VN: '🇻🇳 Vietnam' };
            order.forEach(cc => {
                if (!groups[cc]) return;
                html += `<div class="pc3-group-head"><span>${countryName[cc]}</span><span class="pc3-group-count">${groups[cc].length}</span></div>`;
                html += pc3RenderCardListHtml(groups[cc]);
            });
        } else {
            html = pc3RenderCardListHtml(sorted);
        }
        list.innerHTML = html;

        // re-attach click handlers
        list.querySelectorAll('.pc3-card').forEach(el => {
            el.addEventListener('click', () => pc3ToggleSelect(el.dataset.id));
        });
        list.querySelectorAll('[data-reserve-id]').forEach(btn => {
            btn.addEventListener('click', (event) => {
                event.stopPropagation();
                pc3ReserveConsult(btn.dataset.reserveId);
            });
        });

        pc3UpdateFloatingCta();
        pc3RenderBasket();
    };

    // Helper to render a list of cards using the original card template
    function pc3RenderCardListHtml(pkgs) {
        return pkgs.map(p => {
            const isSelected = pc3.selectedIds.includes(p.id);
            const badgeHtml = (p.badges || []).map(b =>
                `<span class="pc3-card-badge ${b.type}">${b.label}</span>`
            ).join('');
            const highlightsHtml = (p.highlights || []).map(h => `
        <div class="pc3-card-highlight">
          <svg class="pc3-card-highlight-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg>
          <span>${h}</span>
        </div>
      `).join('');
            const monthly = Math.max(1, Math.round(p.price / 12));
            return `
        <div class="pc3-card ${isSelected ? 'active' : ''}" data-id="${p.id}">
          <div class="pc3-card-image pc3-card-image-${p.imageClass}">
            ${pc3ProcedureVisual(p)}
            <div class="pc3-card-checkbox">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg>
            </div>
            <div class="pc3-card-badges">${badgeHtml}</div>
            <div class="pc3-card-image-loc">${p.city}</div>
            <div class="pc3-card-image-flag">${p.flag}</div>
          </div>
          <div class="pc3-card-body">
            <div class="pc3-card-procedure">${p.procedure}</div>
            <div class="pc3-card-hospital">${p.hospital}</div>
            <div class="pc3-card-country">${p.country}</div>
            <div class="pc3-card-price-row">
              <span class="pc3-card-price">$${p.price.toLocaleString()}</span>
              <span class="pc3-card-price-old">$${p.originalPrice.toLocaleString()}</span>
              <span class="pc3-card-discount">−${p.discount}%</span>
            </div>
            <div class="pc3-card-plan-row">
              <span class="pc3-card-plan-tier">${pc3GetTierLabel(p)}</span>
              <span class="pc3-card-plan-month">From $${monthly.toLocaleString()}/month</span>
            </div>
            <div class="pc3-card-highlights">${highlightsHtml}</div>
            <div class="pc3-card-meta">
              <span class="pc3-card-meta-item">📅 <strong>${p.stay}</strong> stay</span>
              <span class="pc3-card-meta-item">⚡ <strong>${p.recoveryWeeks}</strong> recovery</span>
              <span class="pc3-card-meta-item">⭐ <strong>${p.valueScore}</strong>/10</span>
            </div>
            <div class="pc3-card-actions">
              <button class="pc3-card-action" data-reserve-id="${p.id}" type="button">Reserve Consult</button>
            </div>
          </div>
        </div>
      `;
        }).join('');
    }

    function pc3ReserveConsult(id) {
        const selected = PC3_PACKAGES.find(p => p.id === id);
        if (!selected) return;
        pc3Toast(`Concierge consult reserved for ${selected.short}`);
    }

    // ─── BASKET ────────────────────────────────────────────────────────
    function pc3RenderBasket() {
        const basket = document.getElementById('pc3Basket');
        const list = document.getElementById('pc3BasketList');
        const sub = document.getElementById('pc3BasketSub');
        if (!basket || !list) return;

        const n = pc3.selectedIds.length;

        // show/hide
        if (n === 0) {
            basket.classList.remove('show', 'expanded');
            list.innerHTML = `<div class="pc3-basket-empty">No packages selected yet.<br>Tap a card above to add it here.</div>`;
            if (sub) sub.textContent = 'Tap packages to add · max 4';
            const summary = document.getElementById('pc3BasketSummary');
            if (summary) summary.setAttribute('aria-expanded', 'false');
            return;
        }
        basket.classList.add('show');
        if (sub) sub.textContent = `${n} selected · tap to expand`;

        // build list
        const items = pc3.selectedIds
            .map(id => PC3_PACKAGES.find(p => p.id === id))
            .filter(Boolean);
        list.innerHTML = items.map(p => `
      <div class="pc3-basket-item" data-id="${p.id}">
        <span class="pc3-basket-flag">${p.flag}</span>
        <div class="pc3-basket-info">
          <div class="pc3-basket-name">${p.short} · ${p.procedure}</div>
          <div class="pc3-basket-meta">${p.country} · ${p.stay} stay</div>
        </div>
        <span class="pc3-basket-price">$${p.price.toLocaleString()}</span>
        <button class="pc3-basket-remove" data-remove="${p.id}" aria-label="Remove">
          <svg viewBox="0 0 24 24"><path d="M18 6 6 18M6 6l12 12"/></svg>
        </button>
      </div>
    `).join('');

        list.querySelectorAll('[data-remove]').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                const id = btn.dataset.remove;
                const itemEl = btn.closest('.pc3-basket-item');
                if (itemEl) itemEl.classList.add('removing');
                setTimeout(() => {
                    pc3.selectedIds = pc3.selectedIds.filter(x => x !== id);
                    pc3RenderCards(); // also re-renders basket
                }, 200);
            });
        });
    }

    function pc3ToggleBasket() {
        const basket = document.getElementById('pc3Basket');
        if (!basket || !basket.classList.contains('show')) return;
        basket.classList.toggle('expanded');
        const summary = document.getElementById('pc3BasketSummary');
        if (summary) summary.setAttribute('aria-expanded', String(basket.classList.contains('expanded')));
    }

    function pc3BumpBasket() {
        const basket = document.getElementById('pc3Basket');
        if (!basket) return;
        basket.classList.add('bump');
        setTimeout(() => basket.classList.remove('bump'), 500);
    }

    function pc3PlaceBasket() {
        const screen = document.getElementById('screen-20');
        const basket = document.getElementById('pc3Basket');
        if (!screen || !basket || basket.parentElement === screen) return;
        screen.appendChild(basket);
    }

    // ─── DUAL SEARCH MODE ──────────────────────────────────────────────
    function pc3SetSearchMode(mode) {
        const modeWrap = document.getElementById('pc3SearchMode');
        const browsePanel = document.getElementById('pc3BrowsePanel');
        const searchWrap = document.getElementById('pc3SearchWrap');
        if (!modeWrap) return;
        modeWrap.dataset.mode = mode;
        modeWrap.querySelectorAll('.pc3-mode-btn').forEach(b => {
            b.classList.toggle('active', b.dataset.mode === mode);
        });
        if (mode === 'browse') {
            if (browsePanel) browsePanel.classList.add('active');
            if (searchWrap) searchWrap.style.display = 'none';
            pc3RenderCategories();
        } else {
            if (browsePanel) browsePanel.classList.remove('active');
            if (searchWrap) searchWrap.style.display = '';
            // when leaving browse mode, clear category filters
            pc3Browse.activeCategory = null;
            pc3Browse.activeCountry = 'ALL';
            pc3RenderCountryFilter();
            pc3RenderCards();
        }
    }

    window.pc3OpenBrowseFilter = function (category, country, query) {
        pc3.searchText = query || '';
        pc3Browse.activeCategory = category || null;
        pc3Browse.activeCountry = country || 'ALL';
        const input = document.getElementById('pc3SearchInput');
        if (input) input.value = pc3.searchText;
        pc3SetSearchMode(category ? 'browse' : 'type');
        pc3RenderCategories();
        pc3RenderCountryFilter();
        pc3RenderCards();
        pc3UpdateFloatingCta();
        const screen = document.getElementById('screen-20');
        if (screen) screen.scrollTop = 0;
    };

    // Hook our new wiring into the existing init by extending pc3InitEvents
    const __origPc3InitEvents = pc3InitEvents;
    pc3InitEvents = function () {
        __origPc3InitEvents.apply(this, arguments);

        const summary = document.getElementById('pc3BasketSummary');
        if (!summary || summary.__pc3BasketEventsBound === true) return;
        summary.removeAttribute('data-events-bound');
        summary.__pc3BasketEventsBound = true;

        // Mode toggle
        const modeWrap = document.getElementById('pc3SearchMode');
        if (modeWrap) {
            modeWrap.querySelectorAll('.pc3-mode-btn').forEach(btn => {
                btn.addEventListener('click', () => pc3SetSearchMode(btn.dataset.mode));
            });
        }

        // Basket interactions
        const basket = document.getElementById('pc3Basket');
        if (summary && basket) {
            let isDragging = false;
            let isMouseDown = false;
            let startX, startY, initialTop, initialLeft;

            const dragStart = (e) => {
                if (basket.classList.contains('expanded')) return;
                if (e.target.closest('button')) return;

                isMouseDown = true;
                isDragging = false;
                startX = e.type === 'touchstart' ? e.touches[0].clientX : e.clientX;
                startY = e.type === 'touchstart' ? e.touches[0].clientY : e.clientY;

                initialTop = basket.offsetTop;
                initialLeft = basket.offsetLeft;

                document.addEventListener('touchend', dragEnd);
                document.addEventListener('touchmove', dragMove, { passive: false });
                document.addEventListener('mouseup', dragEnd);
                document.addEventListener('mousemove', dragMove);
            };

            const dragMove = (e) => {
                if (!isMouseDown) return;
                const clientX = e.type === 'touchmove' ? e.touches[0].clientX : e.clientX;
                const clientY = e.type === 'touchmove' ? e.touches[0].clientY : e.clientY;

                const dx = clientX - startX;
                const dy = clientY - startY;

                if (Math.abs(dx) > 8 || Math.abs(dy) > 8) {
                    isDragging = true;
                }

                if (isDragging) {
                    e.preventDefault();
                    basket.style.transition = 'none';
                    basket.style.bottom = 'auto';
                    basket.style.right = 'auto';
                    basket.style.top = (initialTop + dy) + 'px';
                    basket.style.left = (initialLeft + dx) + 'px';
                }
            };

            const dragEnd = (e) => {
                isMouseDown = false;
                if (isDragging) {
                    basket.style.transition = '';
                }
                document.removeEventListener('touchend', dragEnd);
                document.removeEventListener('touchmove', dragMove);
                document.removeEventListener('mouseup', dragEnd);
                document.removeEventListener('mousemove', dragMove);

                setTimeout(() => isDragging = false, 50);
            };

            summary.addEventListener('touchstart', dragStart, { passive: false });
            summary.addEventListener('mousedown', dragStart);

            summary.addEventListener('click', (e) => {
                if (isDragging) {
                    e.preventDefault();
                    e.stopPropagation();
                } else {
                    pc3ToggleBasket();
                }
            });
        }
        const clearBtn = document.getElementById('pc3BasketClearBtn');
        if (clearBtn) {
            clearBtn.addEventListener('click', () => {
                pc3.selectedIds = [];
                pc3RenderCards();
                pc3Toast('Basket cleared');
            });
        }

        // Initial render of browse UI (hidden until mode toggle)
        pc3RenderCategories();
        pc3RenderCountryFilter();

        // When the user picks a suggestion or types, also re-render via filter
        const input = document.getElementById('pc3SearchInput');
        if (input) {
            input.addEventListener('input', () => {
                pc3.searchText = input.value;
                pc3RenderCards();
            });
        }
    };

    // Wrap pc3ToggleSelect to add basket-bump animation
    const __origPc3ToggleSelect = pc3ToggleSelect;
    pc3ToggleSelect = function (id) {
        const wasSelected = pc3.selectedIds.includes(id);
        __origPc3ToggleSelect(id);
        const isSelected = pc3.selectedIds.includes(id);
        if (!wasSelected && isSelected) pc3BumpBasket();
        pc3RenderBasket();
    };

    // Wrap pc3UpdateFloatingCta to keep basket in sync
    const __origPc3UpdateFloatingCta = pc3UpdateFloatingCta;
    pc3UpdateFloatingCta = function () {
        __origPc3UpdateFloatingCta.apply(this, arguments);
        pc3RenderBasket();
    };

    // ── Init ──
    function pc3Init() {
        pc3PlaceBasket();
        const tierNav = document.getElementById('pc3TierNav');
        if (tierNav) {
            tierNav.querySelectorAll('.pc3-tier-btn').forEach(btn => {
                btn.classList.toggle('active', btn.dataset.tier === pc3.tier);
            });
        }
        if (window.__mhComparePreset) {
            pc3.searchText = window.__mhComparePreset.query || '';
            pc3Browse.activeCategory = window.__mhComparePreset.category || null;
            pc3Browse.activeCountry = window.__mhComparePreset.country || 'ALL';
            const input = document.getElementById('pc3SearchInput');
            if (input) input.value = pc3.searchText;
            const modeWrap = document.getElementById('pc3SearchMode');
            const browsePanel = document.getElementById('pc3BrowsePanel');
            const searchWrap = document.getElementById('pc3SearchWrap');
            if (modeWrap) {
                modeWrap.dataset.mode = pc3Browse.activeCategory ? 'browse' : 'type';
                modeWrap.querySelectorAll('.pc3-mode-btn').forEach(btn => {
                    btn.classList.toggle('active', btn.dataset.mode === modeWrap.dataset.mode);
                });
            }
            if (browsePanel) browsePanel.classList.toggle('active', !!pc3Browse.activeCategory);
            if (searchWrap) searchWrap.style.display = pc3Browse.activeCategory ? 'none' : '';
        }
        pc3RenderCards();
        pc3UpdateFloatingCta();
        pc3InitEvents();
    }

    // Expose for debugging
    window.pc3Init = pc3Init;

    // Run on load
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', pc3Init);
    } else {
        pc3Init();
    }

    // Re-init when screen 20 becomes active
    const __origGoTo = window.goTo;
    if (typeof __origGoTo === 'function') {
        window.goTo = function (n) {
            __origGoTo.apply(this, arguments);
            if (n === 20) {
                setTimeout(pc3Init, 100);
            }
            if (n === 16) {
                setTimeout(acc3Init, 100);
            }
        };
    }


    /* ════════════════════════════════════════════════════════════════════════
       MODULE 3 · ACCOUNT v3 — AI Upload + Payment Portfolio
       ════════════════════════════════════════════════════════════════════════ */

    const ACC3_PAYMENT_CATEGORIES = {
        surgery: { label: 'Surgery', icon: 'Procedure', mixLabel: 'Procedure', order: 1, note: 'Procedure, theatre, anesthesia, and package deposit review' },
        medication: { label: 'Medication', icon: 'Medicine', mixLabel: 'Medicine', order: 2, note: 'Prescription cost, refill timing, and discharge medicine tracking' },
        diagnostics: { label: 'Diagnostics', icon: 'Diagnostics', mixLabel: 'Diagnostics', order: 3, note: 'Lab, imaging, and specialist-report cost verification' },
        emergency: { label: 'Emergency care', icon: 'Urgent care', mixLabel: 'Urgent', order: 4, note: 'Urgent-care episode, triage bill, and follow-up routing' },
        preventive: { label: 'Preventive care', icon: 'Wellness', mixLabel: 'Wellness', order: 5, note: 'Screening, vaccination, and annual wellness planning' }
    };

    const ACC3_HIGH_COST_LIMIT = 2000;

    function acc3CreatePaymentRecord(date, category, provider, service, cost, source) {
        return {
            id: 'pay-' + date.replace(/[^0-9]/g, '') + '-' + Math.round(cost * 100) + '-' + Math.random().toString(36).slice(2, 7),
            date,
            year: Number(date.slice(0, 4)),
            category: ACC3_PAYMENT_CATEGORIES[category] ? category : 'diagnostics',
            provider,
            service,
            cost: Number(cost) || 0,
            source: source || 'Uploaded Medical Files'
        };
    }

    let acc3PaymentRecords = [
        acc3CreatePaymentRecord('2026-03-12', 'diagnostics', 'Bumrungrad International', 'Cardiac consultation and ECG review', 285, 'Receipt upload'),
        acc3CreatePaymentRecord('2026-02-08', 'diagnostics', 'Sunway Medical Centre', 'Lab tests and abdominal ultrasound', 142, 'Invoice upload'),
        acc3CreatePaymentRecord('2026-01-18', 'medication', 'Guardian Pharmacy', 'Atorvastatin supply, 3 months', 65, 'Receipt upload'),
        acc3CreatePaymentRecord('2025-11-02', 'surgery', 'Bumrungrad International', 'Coronary angioplasty package deposit', 6200, 'Hospital bill'),
        acc3CreatePaymentRecord('2025-09-21', 'emergency', 'Royal Phnom Penh Hospital', 'Emergency chest pain assessment', 930, 'ER invoice'),
        acc3CreatePaymentRecord('2025-05-16', 'preventive', 'Sunway Medical Centre', 'Annual executive health screening', 420, 'Receipt upload'),
        acc3CreatePaymentRecord('2024-08-30', 'surgery', 'Vinmec International Hospital', 'Orthopedic procedure and anesthesia', 4100, 'Hospital bill'),
        acc3CreatePaymentRecord('2024-04-14', 'diagnostics', 'Bumrungrad International', 'MRI knee study with radiology report', 780, 'Imaging invoice'),
        acc3CreatePaymentRecord('2023-10-04', 'medication', 'MedPark Pharmacy', 'Post-procedure medication set', 215, 'Pharmacy receipt'),
        acc3CreatePaymentRecord('2023-02-12', 'preventive', 'Calmette Clinic', 'Vaccination and travel health check', 160, 'Clinic receipt'),
        acc3CreatePaymentRecord('2022-07-19', 'diagnostics', 'Sunway Medical Centre', 'Cardiac stress test and blood panel', 510, 'Diagnostic invoice')
    ];

    let acc3PendingPaymentRecord = null;
    let acc3PendingUploadCats = [];
    let acc3PaymentFocusReturnTop = 0;
    let acc3PaymentFocusReturnCapturedAt = 0;

    function acc3FormatMoney(value) {
        return '$' + Math.round(Number(value) || 0).toLocaleString();
    }

    function acc3FormatDate(value) {
        const date = new Date(value + 'T00:00:00');
        if (Number.isNaN(date.getTime())) return value;
        return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
    }

    function acc3GroupedPaymentData() {
        const years = {};
        acc3PaymentRecords.forEach(record => {
            if (!years[record.year]) years[record.year] = { total: 0, records: [], categories: {} };
            years[record.year].total += record.cost;
            years[record.year].records.push(record);
            if (!years[record.year].categories[record.category]) {
                years[record.year].categories[record.category] = { total: 0, records: [] };
            }
            years[record.year].categories[record.category].total += record.cost;
            years[record.year].categories[record.category].records.push(record);
        });
        return years;
    }

    function acc3RenderRecord(record) {
        return `
      <div class="acc3-payment-record ${record.cost >= ACC3_HIGH_COST_LIMIT ? 'high-cost' : ''}">
        <div class="acc3-payment-record-date">${acc3FormatDate(record.date)}<br>${record.year}</div>
        <div class="acc3-payment-record-main">
          <div class="acc3-payment-record-title">${record.service}</div>
          <div class="acc3-payment-record-provider">${record.provider} · ${record.source}</div>
        </div>
        <div class="acc3-payment-record-cost">${acc3FormatMoney(record.cost)}</div>
      </div>
    `;
    }

    function acc3RenderPaymentPortfolio() {
        const timeline = document.getElementById('acc3PaymentTimeline');
        const rail = document.getElementById('acc3PaymentYearRail');
        if (!timeline || !rail) return;

        const years = acc3GroupedPaymentData();
        const yearKeys = Object.keys(years).map(Number).sort((a, b) => b - a);
        const total = acc3PaymentRecords.reduce((sum, record) => sum + record.cost, 0);
        const high = acc3PaymentRecords.reduce((max, record) => Math.max(max, record.cost), 0);

        const set = (id, value) => { const el = document.getElementById(id); if (el) el.textContent = value; };
        set('acc3PaymentTotal', acc3FormatMoney(total));
        set('acc3PaymentYears', String(yearKeys.length));
        set('acc3PaymentHigh', acc3FormatMoney(high));

        rail.innerHTML = yearKeys.map((year, index) => `
	      <button type="button" class="acc3-payment-year-chip ${index === 0 ? 'active' : ''}" onclick="acc3ScrollPaymentYear(${year})">${year}</button>
	    `).join('');

        timeline.innerHTML = yearKeys.map((year, yearIndex) => {
            const yearData = years[year];
            const records = yearData.records.slice().sort((a, b) => b.date.localeCompare(a.date));
            const categoryKeys = Object.keys(yearData.categories).sort((a, b) => ACC3_PAYMENT_CATEGORIES[a].order - ACC3_PAYMENT_CATEGORIES[b].order);
            const highEvents = records.filter(record => record.cost >= ACC3_HIGH_COST_LIMIT).length;
            const largestYearRecord = records.reduce((max, record) => record.cost > max.cost ? record : max, records[0]);
            const providerCount = new Set(records.map(record => record.provider)).size;
            const latestRecord = records[0];
            const categoryBars = categoryKeys.map(categoryKey => {
                const category = ACC3_PAYMENT_CATEGORIES[categoryKey];
                const categoryTotal = yearData.categories[categoryKey].total;
                const share = Math.max(8, Math.round((categoryTotal / Math.max(1, yearData.total)) * 100));
                return `<span class="acc3-payment-mix-segment" style="--share:${share};" title="${category.label} ${acc3FormatMoney(categoryTotal)}">${category.mixLabel}</span>`;
            }).join('');
            const chainRecords = records.slice(0, 4).map((record, index) => {
                const category = ACC3_PAYMENT_CATEGORIES[record.category];
                return `
			                            <span class="acc3-payment-chain-step ${record.cost >= ACC3_HIGH_COST_LIMIT ? 'major' : ''}">
			                                <i>${index + 1}</i>
			                                <span>
			                                    <strong>${acc3FormatDate(record.date)}</strong>
			                                    <em>${category.label} · ${acc3FormatMoney(record.cost)}</em>
			                                </span>
			                            </span>
			                        `;
            }).join('');
            return `
	      <section class="acc3-payment-year" id="acc3PayYear${year}">
	        <span class="acc3-payment-year-marker" aria-hidden="true"></span>
	        <div class="acc3-payment-year-card" data-open="true">
	          <button type="button" class="acc3-payment-year-head" onclick="acc3TogglePaymentYear(this)">
	            <span>
	              <span class="acc3-payment-year-title">${year}</span>
		              <span class="acc3-payment-year-sub">${records.length} records · ${categoryKeys.length} categories${highEvents ? ' · ' + highEvents + ' major event' + (highEvents > 1 ? 's' : '') : ''}</span>
		            </span>
		            <span>
		              <span class="acc3-payment-year-total">${acc3FormatMoney(yearData.total)}</span>
		              <span class="acc3-payment-chevron">⌄</span>
		            </span>
		          </button>
		          <div class="acc3-payment-provider-note">
		            <strong>Provider review</strong>
		            <span>${providerCount} care provider${providerCount > 1 ? 's' : ''} checked · latest ${latestRecord ? acc3FormatDate(latestRecord.date) : 'no date'} · claim-ready record trail</span>
		          </div>
		          <div class="acc3-payment-year-insight">
		            <div>
		              <span>Largest event</span>
		              <strong>${largestYearRecord ? largestYearRecord.provider : 'No provider'}</strong>
		            </div>
	            <em>${largestYearRecord ? acc3FormatMoney(largestYearRecord.cost) : '$0'}</em>
	          </div>
		          <div class="acc3-payment-mix" aria-label="Payment category mix">${categoryBars}</div>
		          <div class="acc3-payment-year-body">
		            <div class="acc3-payment-chain">
		              <div class="acc3-payment-chain-title">Care cost timeline</div>
		              <div class="acc3-payment-chain-track">${chainRecords}</div>
		            </div>
			                    ${categoryKeys.map(categoryKey => {
                const category = ACC3_PAYMENT_CATEGORIES[categoryKey];
                const categoryData = yearData.categories[categoryKey];
                const categoryRecords = categoryData.records.slice().sort((a, b) => b.date.localeCompare(a.date));
                const largest = categoryRecords.reduce((max, record) => record.cost > max.cost ? record : max, categoryRecords[0]);
                const highCost = categoryRecords.some(record => record.cost >= ACC3_HIGH_COST_LIMIT);
                const latest = categoryRecords[0];
                const providers = new Set(categoryRecords.map(record => record.provider)).size;
                return `
		              <article class="acc3-payment-category" data-year="${year}" data-category="${categoryKey}">
		                <button type="button" class="acc3-payment-category-head" onpointerdown="acc3RememberPaymentFocusReturn()" onclick="acc3OpenPaymentFocus(${year}, '${categoryKey}')"
		                  title="${category.label}: ${categoryRecords.length} records, largest ${largest.service} at ${acc3FormatMoney(largest.cost)}">
		                  <span class="acc3-payment-category-icon">${category.icon}</span>
	                  <span>
		                    <span class="acc3-payment-category-name">${category.label}</span>
		                    <span class="acc3-payment-category-preview">${latest.provider} · ${acc3FormatDate(latest.date)} · ${categoryRecords.length} records</span>
		                    <span class="acc3-payment-category-note">${providers} provider${providers > 1 ? 's' : ''} · ${category.note}</span>
		                    ${highCost ? '<span class="acc3-payment-event-dot">Major event</span>' : ''}
		                  </span>
		                  <span class="acc3-payment-category-total">${acc3FormatMoney(categoryData.total)}</span>
		                </button>
	                <div class="acc3-payment-category-actions">
                  <button type="button" class="acc3-payment-small-btn" onpointerdown="acc3RememberPaymentFocusReturn()" onclick="event.stopPropagation();acc3OpenPaymentFocus(${year}, '${categoryKey}')">See Full</button>
                </div>
              </article>
            `;
            }).join('')}
          </div>
        </div>
      </section>
    `;
        }).join('');
    }

    function acc3AddPaymentRecord(record) {
        acc3PaymentRecords.unshift(record);
        acc3RenderPaymentPortfolio();
        setTimeout(() => acc3ScrollPaymentYear(record.year), 80);
    }

    function acc3ScrollPaymentYear(year) {
        const target = document.getElementById('acc3PayYear' + year);
        if (!target) return;
        document.querySelectorAll('.acc3-payment-year-chip').forEach(chip => {
            chip.classList.toggle('active', chip.textContent.trim() === String(year));
        });
        const card = target.querySelector('.acc3-payment-year-card');
        if (card) card.dataset.open = 'true';
        target.scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'center' });
    }

    function acc3RestorePaymentFocusReturn() {
        const screen = document.getElementById('screen-16');
        if (!screen) return;
        const previousScrollBehavior = screen.style.scrollBehavior;
        screen.style.scrollBehavior = 'auto';
        screen.scrollTop = acc3PaymentFocusReturnTop;
        screen.scrollTo({ top: acc3PaymentFocusReturnTop, behavior: 'auto' });
        screen.style.scrollBehavior = previousScrollBehavior;
        queueAccountJourneySync();
    }

    function acc3RememberPaymentFocusReturn() {
        const screen = document.getElementById('screen-16');
        acc3PaymentFocusReturnTop = screen ? screen.scrollTop : 0;
        acc3PaymentFocusReturnCapturedAt = Date.now();
    }

    function acc3TogglePaymentYear(btn) {
        const card = btn.closest('.acc3-payment-year-card');
        if (!card) return;
        card.dataset.open = card.dataset.open === 'true' ? 'false' : 'true';
    }

    function acc3OpenPaymentFocus(year, categoryKey) {
        const focus = document.getElementById('acc3PaymentFocus');
        if (!focus) return;
        const screen = document.getElementById('screen-16');
        if (!acc3PaymentFocusReturnCapturedAt || Date.now() - acc3PaymentFocusReturnCapturedAt > 750) {
            acc3PaymentFocusReturnTop = screen ? screen.scrollTop : 0;
        }
        const phoneScreen = document.querySelector('.phone-screen');
        if (focus.parentElement !== document.body) {
            document.body.appendChild(focus);
        }
        if (phoneScreen) {
            const rect = phoneScreen.getBoundingClientRect();
            focus.style.position = 'fixed';
            focus.style.left = rect.left + 'px';
            focus.style.top = rect.top + 'px';
            focus.style.width = rect.width + 'px';
            focus.style.height = rect.height + 'px';
            focus.style.zIndex = '1000';
        }
        document.body.classList.add('acc3-payment-focus-open');
        const category = ACC3_PAYMENT_CATEGORIES[categoryKey];
        const records = acc3PaymentRecords
            .filter(record => record.year === Number(year) && record.category === categoryKey)
            .sort((a, b) => b.date.localeCompare(a.date));
        const total = records.reduce((sum, record) => sum + record.cost, 0);
        const highEvents = records.filter(record => record.cost >= ACC3_HIGH_COST_LIMIT).length;
        const set = (id, value) => { const el = document.getElementById(id); if (el) el.innerHTML = value; };
        set('acc3PaymentFocusKicker', year + ' provider payment review');
        set('acc3PaymentFocusTitle', category.label);
        set('acc3PaymentFocusMeta', `${records.length} records · ${acc3FormatMoney(total)} total · ${category.note}${highEvents ? ' · ' + highEvents + ' major event' + (highEvents > 1 ? 's' : '') : ''}`);
        set('acc3PaymentFocusList', records.map(acc3RenderRecord).join(''));
        focus.classList.add('active');
        focus.scrollTop = 0;
        const sheet = focus.querySelector('.acc3-payment-focus-sheet');
        if (sheet) sheet.scrollTop = 0;
        focus.setAttribute('aria-hidden', 'false');
        requestAnimationFrame(acc3RestorePaymentFocusReturn);
    }

    function acc3ClosePaymentFocus() {
        const focus = document.getElementById('acc3PaymentFocus');
        if (!focus) return;
        focus.classList.remove('active');
        document.body.classList.remove('acc3-payment-focus-open');
        focus.setAttribute('aria-hidden', 'true');
        requestAnimationFrame(acc3RestorePaymentFocusReturn);
        setTimeout(acc3RestorePaymentFocusReturn, 80);
    }

    window.acc3ScrollPaymentYear = acc3ScrollPaymentYear;
    window.acc3TogglePaymentYear = acc3TogglePaymentYear;
    window.acc3RememberPaymentFocusReturn = acc3RememberPaymentFocusReturn;
    window.acc3OpenPaymentFocus = acc3OpenPaymentFocus;
    window.acc3ClosePaymentFocus = acc3ClosePaymentFocus;

    // Sample categorization results (cycles through to demo variety)
    const ACC3_DEMO_RESULTS = [
        { hospital: 'Bumrungrad International', service: 'Cardiac consultation', cost: 285, date: '2026-03-12', category: 'diagnostics', categoryLabel: 'Diagnostics' },
        { hospital: 'Sunway Medical Centre', service: 'Lab tests + ultrasound', cost: 142, date: '2026-02-08', category: 'diagnostics', categoryLabel: 'Diagnostics' },
        { hospital: 'Bumrungrad International', service: 'Surgery package deposit', cost: 2400, date: '2026-04-18', category: 'surgery', categoryLabel: 'Surgery' },
        { hospital: 'Guardian Pharmacy', service: 'Atorvastatin (3 months)', cost: 65, date: '2026-01-22', category: 'medication', categoryLabel: 'Medication' },
    ];

    let acc3DemoIndex = 0;
    let acc3IsProcessing = false;

    function acc3SetState(state) {
        const aiu = document.getElementById('acc3Aiu');
        if (aiu) aiu.dataset.state = state;
    }

    function acc3StartProcessing() {
        if (acc3IsProcessing) return;
        acc3IsProcessing = true;
        acc3SetState('processing');

        // Reset progress steps
        const items = document.querySelectorAll('#acc3AiuProgress li');
        items.forEach(li => li.classList.remove('active', 'done'));

        // Animate steps sequentially
        const steps = ['ocr', 'hospital', 'cost', 'date', 'categorize'];
        let i = 0;
        const tick = () => {
            // Mark previous done
            if (i > 0) {
                const prev = document.querySelector(`#acc3AiuProgress li[data-step="${steps[i - 1]}"]`);
                if (prev) {
                    prev.classList.remove('active');
                    prev.classList.add('done');
                }
            }
            // Activate current
            if (i < steps.length) {
                const cur = document.querySelector(`#acc3AiuProgress li[data-step="${steps[i]}"]`);
                if (cur) cur.classList.add('active');
                i++;
                setTimeout(tick, 600);
            } else {
                // Finished — decide success vs manual fallback
                // 80% success rate for demo; 1 in 5 goes to manual
                const goSuccess = Math.random() > 0.2;
                setTimeout(() => {
                    if (goSuccess) {
                        acc3ShowSuccess();
                    } else {
                        acc3ShowManual();
                    }
                    acc3IsProcessing = false;
                }, 400);
            }
        };
        tick();
    }

    function acc3ShowSuccess() {
        const result = ACC3_DEMO_RESULTS[acc3DemoIndex % ACC3_DEMO_RESULTS.length];
        acc3DemoIndex++;
        acc3PendingPaymentRecord = acc3CreatePaymentRecord(result.date, result.category, result.hospital, result.service, result.cost, 'AI extraction');
        const set = (id, val) => { const e = document.getElementById(id); if (e) e.textContent = val; };
        set('acc3AiuValHospital', result.hospital);
        set('acc3AiuValService', result.service);
        set('acc3AiuValCost', '$' + result.cost.toLocaleString());
        set('acc3AiuValDate', result.date);
        set('acc3AiuValCategory', result.categoryLabel);
        acc3SetState('success');
        // Clear selection so user must re-pick on next upload
        Array.from(document.querySelectorAll('input[name="acc3UploadCats"]')).forEach(i => i.checked = false);
    }

    function acc3ShowManual() {
        acc3SetState('manual');
        // Pre-fill date with today
        const dateInput = document.getElementById('acc3AiuManualDate');
        if (dateInput) {
            const today = new Date();
            dateInput.value = today.toISOString().split('T')[0];
        }
        // Clear selection so user must re-pick on next upload
        Array.from(document.querySelectorAll('input[name="acc3UploadCats"]')).forEach(i => i.checked = false);
    }

    function acc3ResetIdle() {
        acc3SetState('idle');
        // ensure selections cleared
        Array.from(document.querySelectorAll('input[name="acc3UploadCats"]')).forEach(i => i.checked = false);
    }

    function acc3InitEvents() {
        const aiu = document.getElementById('acc3Aiu');
        if (!aiu) return;
        if (aiu.dataset.eventsBound === 'true') return;
        aiu.dataset.eventsBound = 'true';

        // Choose File button — prefer unified mrFileInput if present
        const uploadBtn = document.getElementById('acc3AiuUploadBtn');
        const fileInput = document.getElementById('acc3AiuFileInput');
        const mrFile = document.getElementById('mrFileInput');
        if (uploadBtn) {
            uploadBtn.addEventListener('click', () => {
                // Require at least one destination selected before uploading
                const selected = Array.from(document.querySelectorAll('input[name="acc3UploadCats"]:checked')).map(i => i.value);
                if (!selected.length) {
                    const err = document.getElementById('acc3AiuPickError');
                    if (err) { err.style.display = 'block'; setTimeout(() => err.style.display = 'none', 2600); }
                    return;
                }
                acc3PendingUploadCats = selected;
                // attach selected categories to the file input for downstream handling
                if (mrFile) { mrFile.dataset.uploadCats = selected.join(','); mrFile.click(); }
                else if (fileInput) { fileInput.dataset.uploadCats = selected.join(','); fileInput.click(); }
            });
        }
        // Wire change events — if mrFile exists it is handled by medRecord logic, otherwise use local handler
        if (!mrFile && fileInput) {
            fileInput.addEventListener('change', () => {
                if (fileInput.files && fileInput.files.length) {
                    acc3StartProcessing();
                }
            });
        }

        // Camera button
        const cameraBtn = document.getElementById('acc3AiuCameraBtn');
        if (cameraBtn) {
            cameraBtn.addEventListener('click', () => {
                const selected = Array.from(document.querySelectorAll('input[name="acc3UploadCats"]:checked')).map(i => i.value);
                if (!selected.length) {
                    const err = document.getElementById('acc3AiuPickError');
                    if (err) { err.style.display = 'block'; setTimeout(() => err.style.display = 'none', 2600); }
                    return;
                }
                acc3PendingUploadCats = selected;
                if (mrFile) {
                    mrFile.dataset.uploadCats = selected.join(',');
                    mrFile.setAttribute('capture', 'environment');
                    mrFile.click();
                } else if (fileInput) {
                    fileInput.dataset.uploadCats = selected.join(',');
                    fileInput.setAttribute('capture', 'environment');
                    fileInput.click();
                }
            });
        }

        // Drag & drop
        aiu.addEventListener('dragover', (e) => {
            e.preventDefault();
            if (aiu.dataset.state === 'idle') aiu.classList.add('dragover');
        });
        aiu.addEventListener('dragleave', (e) => {
            e.preventDefault();
            aiu.classList.remove('dragover');
        });
        aiu.addEventListener('drop', (e) => {
            e.preventDefault();
            aiu.classList.remove('dragover');
            if (aiu.dataset.state === 'idle' && e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files.length) {
                acc3PendingUploadCats = ['payment'];
                acc3StartProcessing();
            } else if (aiu.dataset.state === 'idle') {
                acc3PendingUploadCats = ['payment'];
                acc3StartProcessing(); // even without files — demo
            }
        });

        // Click on idle drop zone (excluding buttons) to upload
        const idleArea = aiu.querySelector('.acc3-aiu-idle');
        if (idleArea) {
            idleArea.addEventListener('click', (e) => {
                if (e.target.closest('button') || e.target.closest('input')) return;
                if (mrFile) mrFile.click();
                else if (fileInput) fileInput.click();
            });
        }

        // Success state actions
        const editBtn = document.getElementById('acc3AiuEditBtn');
        const confirmBtn = document.getElementById('acc3AiuConfirmBtn');
        if (editBtn) {
            editBtn.addEventListener('click', () => {
                // Move to manual with prefilled values
                acc3ShowManual();
                const result = ACC3_DEMO_RESULTS[(acc3DemoIndex - 1 + ACC3_DEMO_RESULTS.length) % ACC3_DEMO_RESULTS.length];
                const setVal = (id, val) => { const e = document.getElementById(id); if (e) e.value = val; };
                setVal('acc3AiuManualHospital', result.hospital);
                setVal('acc3AiuManualService', result.service);
                setVal('acc3AiuManualCost', result.cost);
                setVal('acc3AiuManualDate', result.date);
                setVal('acc3AiuManualCategory', result.category);
            });
        }
        if (confirmBtn) {
            confirmBtn.addEventListener('click', () => {
                if (acc3PendingPaymentRecord && (!acc3PendingUploadCats.length || acc3PendingUploadCats.includes('payment'))) {
                    acc3AddPaymentRecord(acc3PendingPaymentRecord);
                    acc3PendingPaymentRecord = null;
                }
                pc3Toast('✓ Added to your Payment Portfolio');
                setTimeout(acc3ResetIdle, 1200);
            });
        }

        // Manual state actions
        const manualCancel = document.getElementById('acc3AiuManualCancel');
        const manualSave = document.getElementById('acc3AiuManualSave');
        if (manualCancel) {
            manualCancel.addEventListener('click', acc3ResetIdle);
        }
        if (manualSave) {
            manualSave.addEventListener('click', () => {
                const hospital = document.getElementById('acc3AiuManualHospital');
                const cost = document.getElementById('acc3AiuManualCost');
                if (hospital && !hospital.value) {
                    pc3Toast('Please enter hospital name');
                    hospital.focus();
                    return;
                }
                if (cost && !cost.value) {
                    pc3Toast('Please enter cost');
                    cost.focus();
                    return;
                }
                const date = document.getElementById('acc3AiuManualDate');
                const service = document.getElementById('acc3AiuManualService');
                const category = document.getElementById('acc3AiuManualCategory');
                acc3AddPaymentRecord(acc3CreatePaymentRecord(
                    date && date.value ? date.value : new Date().toISOString().slice(0, 10),
                    category ? category.value : 'diagnostics',
                    hospital.value,
                    service && service.value ? service.value : 'Uploaded medical payment',
                    Number(cost.value),
                    'Manual entry'
                ));
                pc3Toast('✓ Saved manually to portfolio');
                setTimeout(acc3ResetIdle, 1200);
            });
        }
    }

    function acc3Init() {
        acc3RenderPaymentPortfolio();
        acc3InitEvents();
        acc3SetState('idle');
    }

    document.addEventListener('keydown', (event) => {
        if (event.key === 'Escape') acc3ClosePaymentFocus();
    });

    // Expose
    window.acc3Init = acc3Init;

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', acc3Init);
    } else {
        acc3Init();
    }

})();


/* ════════════════════════════════════════════════════════════════════════
   V4 · ACCOUNT EXTENSIONS · journey · medrecord · medication
   ════════════════════════════════════════════════════════════════════════ */
(function () {
    'use strict';

    /* ─────────────── 1) CARE JOURNEY · scroll-aware pointer ─────────────── */
    function initAccJourney() {
        const root = document.getElementById('accJourney');
        const list = document.getElementById('accJourneyList');
        const pointer = document.getElementById('accJourneyPointer');
        const fill = document.getElementById('accJourneyFill');
        const pctNum = document.getElementById('accJourneyPctNum');
        if (!root || !list || !pointer) return;

        const steps = Array.from(list.querySelectorAll('.acc-step'));
        const total = steps.length;
        if (!total) return;

        // Compute progress from completed + 0.5 * current
        const completed = steps.filter(s => s.classList.contains('completed')).length;
        const current = steps.filter(s => s.classList.contains('current')).length;
        const pct = Math.round(((completed + (current * 0.5)) / total) * 100);

        requestAnimationFrame(() => {
            if (fill) fill.style.width = pct + '%';
            if (pctNum) pctNum.textContent = pct + '%';
        });

        // Pointer follows the current step on initial render
        function moveToStep(stepEl) {
            if (!stepEl) return;
            const stepRect = stepEl.getBoundingClientRect();
            const listRect = list.getBoundingClientRect();
            // Align pointer center with dot center (dot center is ~25px from step top)
            const y = (stepRect.top - listRect.top) + 18;
            pointer.style.transform = 'translateY(' + y + 'px)';
            pointer.classList.add('active');
        }

        const initialActive = steps.find(s => s.classList.contains('current')) || steps[0];
        requestAnimationFrame(() => moveToStep(initialActive));

        // Click any step → make it the live pointer target (without changing the
        // logical "current" state). This gives users tactile feedback.
        steps.forEach(step => {
            step.addEventListener('click', () => {
                moveToStep(step);
            });
        });

        // Scroll-following: as the user scrolls inside the phone, find which
        // step is closest to the screen-content vertical centre and move pointer.
        const screen = root.closest('.screen-content');
        if (screen && 'IntersectionObserver' in window) {
            // Use scroll listener with rAF throttle on the scrollable parent
            let rafId = null;
            function onScroll() {
                if (rafId) return;
                rafId = requestAnimationFrame(() => {
                    rafId = null;
                    const screenRect = screen.getBoundingClientRect();
                    const focusY = screenRect.top + screenRect.height * 0.42; // upper-middle
                    // Only react when journey is roughly in view
                    const journeyRect = root.getBoundingClientRect();
                    if (journeyRect.bottom < screenRect.top || journeyRect.top > screenRect.bottom) return;
                    let bestStep = null;
                    let bestDist = Infinity;
                    steps.forEach(s => {
                        const r = s.getBoundingClientRect();
                        const c = r.top + r.height / 2;
                        const d = Math.abs(c - focusY);
                        if (d < bestDist) { bestDist = d; bestStep = s; }
                    });
                    if (bestStep) moveToStep(bestStep);
                });
            }
            screen.addEventListener('scroll', onScroll, { passive: true });
            // Also reset pointer when journey first enters viewport
            const io = new IntersectionObserver((entries) => {
                entries.forEach(e => {
                    if (e.isIntersecting) {
                        moveToStep(steps.find(s => s.classList.contains('current')) || steps[0]);
                    }
                });
            }, { root: screen, threshold: 0.15 });
            io.observe(root);
        }

        // Keep pointer aligned on window resize
        window.addEventListener('resize', () => {
            const active = steps.find(s => s.classList.contains('current')) || steps[0];
            moveToStep(active);
        });
    }

    /* ─────────────── 2) MEDRECORD · upload → confirm → categorise ─────────────── */
    function initMedRecord() {
        const card = document.getElementById('medRecordCard');
        const confirmBox = document.getElementById('mrConfirm');
        // Proceed only if the confirm overlay exists (we removed the visual wrapper)
        if (!confirmBox) return;
        const fileInput = document.getElementById('mrFileInput');
        const dropZone = document.getElementById('mrDropZone');
        const cancelBtn = document.getElementById('mrConfirmCancel');
        const saveBtn = document.getElementById('mrConfirmSave');
        const catOptions = document.getElementById('mrCatOptions');
        const flash = document.getElementById('mrFlash');
        const folders = document.querySelectorAll('.mr-folder');

        // Sample heuristics — file-name → guessed category + extracted fields
        const HEURISTICS = [
            { match: /(rx|prescription|tablet|pill|dose)/i, cat: 'medication', name: 'Prescription', source: 'Subang Jaya MC' },
            { match: /(invoice|bill|receipt|payment|paid)/i, cat: 'payment', name: 'Hospital invoice', source: 'Vinmec Hanoi' },
            { match: /(report|scan|mri|ct|xray|x-ray|lab|blood|test)/i, cat: 'medrecord', name: 'Medical report', source: 'Vinmec Hanoi' },
        ];

        function guess(file) {
            const fname = (file && file.name) || 'document.pdf';
            const size = file && file.size ? formatBytes(file.size) : '184 KB';
            let h = HEURISTICS.find(h => h.match.test(fname));
            if (!h) h = { cat: 'medrecord', name: 'Medical document', source: 'Uploaded by patient' };
            return {
                fname,
                size,
                cat: h.cat,
                docName: h.name,
                date: new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }),
                source: h.source
            };
        }

        function formatBytes(b) {
            if (b < 1024) return b + ' B';
            if (b < 1024 * 1024) return Math.round(b / 1024) + ' KB';
            return (b / 1024 / 1024).toFixed(1) + ' MB';
        }

        function openConfirm(meta) {
            // Populate fields
            document.getElementById('mrConfirmFile').textContent = meta.fname + ' · ' + meta.size;
            document.getElementById('mrExName').textContent = meta.docName;
            document.getElementById('mrExDate').textContent = meta.date;
            document.getElementById('mrExSource').textContent = meta.source;
            document.getElementById('mrExSize').textContent = meta.size;
            // Pre-select guessed category
            catOptions.querySelectorAll('.mr-cat-opt').forEach(b => {
                b.classList.toggle('active', b.dataset.cat === meta.cat);
            });
            // Update title verb
            const titleVerbs = {
                medication: 'a <em>prescription</em>',
                medrecord: 'a <em>medical record</em>',
                payment: 'a <em>payment receipt</em>'
            };
            document.getElementById('mrConfirmTitle').innerHTML = 'Looks like ' + titleVerbs[meta.cat];
            confirmBox.classList.add('active');
        }

        // selectedFolder: set when user clicks one of the visible folders
        let selectedFolder = null;

        function closeConfirm() { confirmBox.classList.remove('active'); }

        function flashSave(catLabel) {
            flash.textContent = '✓ Saved to ' + catLabel;
            flash.classList.add('show');
            setTimeout(() => flash.classList.remove('show'), 2200);
        }

        function bumpFolder(cat) {
            const folder = document.querySelector('.mr-folder[data-folder="' + cat + '"]');
            if (!folder) return;
            // Update count
            const countEl = folder.querySelector('.mr-folder-count');
            if (countEl) {
                const m = countEl.textContent.match(/(\d+)/);
                const current = m ? parseInt(m[1], 10) : 0;
                countEl.textContent = (current + 1) + ' files';
            }
            folder.classList.add('bumped');
            setTimeout(() => folder.classList.remove('bumped'), 1400);
        }

        // ── Wire up file input
        if (fileInput) {
            fileInput.addEventListener('change', (e) => {
                const file = e.target.files && e.target.files[0];
                // Demo: even if no file picked, we open confirm with stub data
                const meta = guess(file);
                // If user had actively selected a folder, prefer that category
                if (selectedFolder) meta.cat = selectedFolder;
                // Simulate processing delay
                dropZone.style.opacity = '0.5';
                dropZone.style.pointerEvents = 'none';
                setTimeout(() => {
                    dropZone.style.opacity = '';
                    dropZone.style.pointerEvents = '';
                    openConfirm(meta);
                }, 900);
                // Reset for next upload
                try { fileInput.value = ''; } catch (_) { }
            });
        }

        // ── Category selection (single-select)
        if (catOptions) {
            catOptions.addEventListener('click', (e) => {
                const btn = e.target.closest('.mr-cat-opt');
                if (!btn) return;
                catOptions.querySelectorAll('.mr-cat-opt').forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
            });
        }

        // ── Cancel
        if (cancelBtn) cancelBtn.addEventListener('click', closeConfirm);

        // ── Save → bump folder + flash
        if (saveBtn) {
            saveBtn.addEventListener('click', () => {
                const active = catOptions.querySelector('.mr-cat-opt.active');
                if (!active) return;
                const cat = active.dataset.cat;
                const labelMap = { medrecord: 'MedRecord', medication: 'Medication', payment: 'Payment' };
                closeConfirm();
                // Slight delay so the modal close motion feels intentional before the bump
                setTimeout(() => {
                    bumpFolder(cat);
                    flashSave(labelMap[cat] || 'Portfolio');
                }, 240);
            });
        }

        // ── Folder click: select destination for next upload + visual feedback
        folders.forEach(f => {
            f.addEventListener('click', () => {
                // mark selection
                folders.forEach(x => x.classList.remove('selected'));
                f.classList.add('selected');
                selectedFolder = f.dataset.folder;
                // minor bump animation
                f.classList.add('bumped');
                setTimeout(() => f.classList.remove('bumped'), 700);
            });
        });

        // Clicking the drop zone should require a selected folder first
        window.pickMrFile = function () {
            const err = document.getElementById('mr-pick-error');
            if (!selectedFolder) {
                if (err) { err.style.display = 'block'; setTimeout(() => err.style.display = 'none', 2600); }
                return;
            }
            if (err) err.style.display = 'none';
            if (fileInput) fileInput.click();
        };
    }

    /* ─────────────── 2b) RIGHT-SPINE: live pointer + active badge ─────────────── */
    function initRightSpine() {
        // Create spine UI
        let spine = document.querySelector('.mr-right-spine');
        if (!spine) {
            spine = document.createElement('div');
            spine.className = 'mr-right-spine';
            spine.innerHTML = '<div class="spine-line"><div class="spine-pointer" id="mrSpinePointer"></div></div>';
            document.body.appendChild(spine);
        }
        let badge = document.querySelector('.mr-active-badge');
        if (!badge) {
            badge = document.createElement('div');
            badge.className = 'mr-active-badge small';
            badge.id = 'mrActiveBadge';
            document.body.appendChild(badge);
        }

        const trackSelectors = ['.acc3-aiu', '.mr-upload-wrap', '.med-section', '.acc3-portfolio-card', '.acc3-portfolio-mini-card'];
        const tracks = Array.from(document.querySelectorAll(trackSelectors.join(','))).filter(Boolean);
        if (!tracks.length) return;

        // Map element -> label for badge
        const labelFor = el => {
            if (el.classList.contains('acc3-aiu')) return 'Upload Medical Files';
            if (el.classList.contains('mr-upload-wrap')) return 'Upload Destinations';
            if (el.id === 'medSection') return "Today's Medication";
            if (el.classList.contains('acc3-portfolio-card')) return 'Payment Portfolio';
            if (el.classList.contains('acc3-portfolio-mini-card')) return el.querySelector('.acc3-portfolio-label')?.textContent?.trim() || 'Portfolio';
            return el.getAttribute('aria-label') || el.querySelector('h3, h2, .serif')?.textContent?.trim() || 'Section';
        };

        function updatePointerFor(el) {
            const ptr = document.getElementById('mrSpinePointer');
            const badgeEl = document.getElementById('mrActiveBadge');
            if (!ptr || !badgeEl) return;
            const spineEl = document.querySelector('.mr-right-spine .spine-line');
            if (!spineEl) return;
            const spineRect = spineEl.getBoundingClientRect();
            const elRect = el.getBoundingClientRect();
            // compute relative center position of el within the viewport and map to spine height
            const viewTop = window.innerHeight * 0.08; // top offset
            const viewBottom = window.innerHeight * 0.92;
            const elCenter = elRect.top + elRect.height / 2;
            const pct = Math.max(0, Math.min(1, (elCenter - viewTop) / (viewBottom - viewTop)));
            const y = spineRect.top + pct * spineRect.height;
            // position pointer by translating
            const offset = y - spineRect.top;
            ptr.style.transform = 'translateY(' + (offset - 6) + 'px)';
            // update badge
            badgeEl.textContent = labelFor(el);
            badgeEl.style.display = 'block';
        }

        // IntersectionObserver to find the most visible track element
        const io = new IntersectionObserver(entries => {
            // pick entry with largest intersectionRatio
            let best = null; let bestRatio = 0;
            entries.forEach(en => {
                if (en.intersectionRatio > bestRatio) { bestRatio = en.intersectionRatio; best = en.target; }
            });
            if (best && bestRatio > 0.12) updatePointerFor(best);
        }, { threshold: [0, 0.12, 0.25, 0.5, 0.75] });

        tracks.forEach(t => {
            io.observe(t);
            // react to focus/hover for immediate pointer update
            t.addEventListener('focusin', () => updatePointerFor(t));
            t.addEventListener('mouseenter', () => updatePointerFor(t));
        });

        // rAF-throttled scroll updater to keep the pointer live while scrolling
        let scraf = null;
        function onSpineScroll() {
            if (scraf) return;
            scraf = requestAnimationFrame(() => {
                scraf = null;
                const focusY = window.innerHeight * 0.45;
                let best = null; let bestDist = Infinity;
                tracks.forEach(el => {
                    const r = el.getBoundingClientRect();
                    if (r.bottom < 0 || r.top > window.innerHeight) return;
                    const c = r.top + r.height / 2;
                    const d = Math.abs(c - focusY);
                    if (d < bestDist) { bestDist = d; best = el; }
                });
                if (best) updatePointerFor(best);
            });
        }
        window.addEventListener('scroll', onSpineScroll, { passive: true });
        window.addEventListener('resize', onSpineScroll);
        // run once to set initial pointer
        onSpineScroll();

        // Hide badge when scrolling fast to avoid overlap; show again after idle
        let tid = null;
        window.addEventListener('scroll', () => {
            const b = document.getElementById('mrActiveBadge');
            if (b) b.style.opacity = '0.9';
            if (tid) clearTimeout(tid);
            tid = setTimeout(() => { if (b) b.style.opacity = '1'; }, 120);
        }, { passive: true });
    }

    // Initialize spine after DOM ready
    document.addEventListener('DOMContentLoaded', initRightSpine);
    if (document.readyState !== 'loading') initRightSpine();

    // ────────────── In-phone right-edge pointer (inside the phone-screen) ──────────────
    function initInPhoneSpine() {
        const bar = document.getElementById('ip-journey-bar');
        if (!bar) return;
        // create spine container inside the bar
        let spine = bar.querySelector('.ip-spine');
        if (!spine) {
            spine = document.createElement('div');
            spine.className = 'ip-spine';
            spine.innerHTML = '<div class="ip-spine-line"><div class="ip-spine-pointer" id="ipSpinePointer"></div></div>';
            bar.appendChild(spine);
        }

        const pointer = document.getElementById('ipSpinePointer');
        const spineLine = bar.querySelector('.ip-spine-line');
        if (!pointer || !spineLine) return;

        // Track portfolio mini-cards inside the phone-screen
        const selectors = ['.acc3-portfolio-mini-card'];
        const tracks = Array.from(document.querySelectorAll(selectors.join(','))).filter(Boolean);
        if (!tracks.length) {
            // hide pointer if nothing to track
            pointer.style.display = 'none';
            return;
        }

        function labelFor(el) {
            return el.querySelector('.acc3-portfolio-label')?.textContent?.trim() || 'Section';
        }

        function updatePointerFor(el) {
            if (!el) return;
            const spineRect = spineLine.getBoundingClientRect();
            const elRect = el.getBoundingClientRect();
            // compute % position of element center within visible phone area
            const phoneTop = document.querySelector('.phone-screen')?.getBoundingClientRect().top || 0;
            const phoneHeight = document.querySelector('.phone-screen')?.getBoundingClientRect().height || window.innerHeight;
            const elCenter = elRect.top + elRect.height / 2;
            const pct = Math.max(0, Math.min(1, (elCenter - phoneTop) / phoneHeight));
            const y = spineRect.top + pct * spineRect.height;
            const offset = y - spineRect.top;
            pointer.style.transform = 'translate(-50%,' + (offset - 6) + 'px)';
            // active pulse
            pointer.classList.add('active');
            window.clearTimeout(pointer._rem); pointer._rem = window.setTimeout(() => { pointer.classList.remove('active'); }, 700);
        }

        // IntersectionObserver to detect most visible card
        const io = new IntersectionObserver(entries => {
            let best = null; let bestRatio = 0;
            entries.forEach(en => {
                if (en.intersectionRatio > bestRatio) { bestRatio = en.intersectionRatio; best = en.target; }
            });
            if (best && bestRatio > 0.08) updatePointerFor(best);
        }, { threshold: [0, 0.05, 0.12, 0.25, 0.5, 0.75] });

        tracks.forEach(t => {
            io.observe(t);
            t.addEventListener('mouseenter', () => updatePointerFor(t));
            t.addEventListener('focusin', () => updatePointerFor(t));
        });

        // rAF scroll loop to pick closest-to-center card for smooth updates
        let raf = null;
        function onScroll() {
            if (raf) return;
            raf = requestAnimationFrame(() => {
                raf = null;
                const focusY = (document.querySelector('.phone-screen')?.getBoundingClientRect().top || 0) + (document.querySelector('.phone-screen')?.getBoundingClientRect().height || window.innerHeight) * 0.48;
                let best = null; let bestDist = Infinity;
                tracks.forEach(el => {
                    const r = el.getBoundingClientRect();
                    if (r.bottom < 0 || r.top > window.innerHeight) return;
                    const c = r.top + r.height / 2;
                    const d = Math.abs(c - focusY);
                    if (d < bestDist) { bestDist = d; best = el; }
                });
                if (best) updatePointerFor(best);
            });
        }

        window.addEventListener('scroll', onScroll, { passive: true });
        window.addEventListener('resize', onScroll);
        // initial run
        onScroll();
    }

    // initialize in-phone spine after DOM ready
    document.addEventListener('DOMContentLoaded', initInPhoneSpine);
    if (document.readyState !== 'loading') initInPhoneSpine();

    /* ─────────────── 3) MEDICATION · tap-to-take + day summary ─────────────── */
    function initMedication() {
        const sec = document.getElementById('medSection');
        if (!sec) return;
        const cards = Array.from(sec.querySelectorAll('.med-pill-card'));
        const summary = document.getElementById('medDaySummary');
        const nowTimer = document.getElementById('medNowTimer');
        const nowLabel = document.getElementById('medNowLabel');
        const nowTime = document.getElementById('medNowTime');
        const nowName = document.getElementById('medNowName');
        let pinnedCard = null;
        let floatingTimerId = null;

        function recomputeSummary() {
            if (!summary) return;
            let taken = 0, upcoming = 0, missed = 0;
            cards.forEach(c => {
                if (c.classList.contains('taken')) taken++;
                else if (c.classList.contains('missed')) missed++;
                else upcoming++;
            });
            const set = (key, n) => {
                const el = summary.querySelector('[data-summary="' + key + '"]');
                if (el) el.textContent = n;
            };
            set('taken', taken);
            set('upcoming', upcoming);
            set('missed', missed);
            // Update next-dose banner to first upcoming pill
            const nextCard = Array.from(cards).find(c => c.classList.contains('upcoming'));
            const nameEl = document.getElementById('medNextName');
            const timeEl = document.getElementById('medNextTime');
            const cdEl = document.getElementById('medNextCountdown');
            if (nextCard && nameEl && timeEl) {
                const nm = nextCard.querySelector('.med-pill-name')?.textContent || '';
                const ds = nextCard.querySelector('.med-pill-dose')?.textContent.replace(/\s+/g, ' ').trim() || '';
                const period = nextCard.closest('.med-period');
                const periodName = period?.querySelector('.med-period-name')?.textContent || '';
                const periodTime = period?.querySelector('.med-period-time')?.textContent || '';
                nameEl.textContent = (nm + ' ' + ds.split('·')[0]).trim();
                timeEl.textContent = periodName + ' · ' + periodTime.split('·')[0].trim();
            } else if (nameEl && timeEl && cdEl) {
                nameEl.textContent = 'All doses taken';
                timeEl.textContent = 'Great job · see you tomorrow';
                cdEl.textContent = '✓';
            }
        }

        function formatElapsed(ms) {
            const total = Math.max(0, Math.floor(ms / 1000));
            const hrs = Math.floor(total / 3600);
            const mins = Math.floor((total % 3600) / 60);
            const secs = total % 60;
            if (hrs > 0) return `${hrs}h ${String(mins).padStart(2, '0')}m`;
            if (mins > 0) return `${mins}m ${String(secs).padStart(2, '0')}s`;
            return `${secs}s`;
        }

        function formatElapsedShort(ms) {
            const total = Math.max(0, Math.floor(ms / 1000));
            const hrs = Math.floor(total / 3600);
            const mins = Math.floor((total % 3600) / 60);
            const secs = total % 60;
            if (hrs > 0) return `${hrs}h ${mins}m`;
            if (mins > 0) return `${mins}m ${secs}s`;
            return `${secs}s`;
        }

        function getMedName(card) {
            return card?.querySelector('.med-pill-name')?.textContent?.trim() || 'Dose';
        }

        function setPinnedCard(card) {
            if (!card || !nowTimer) return;
            pinnedCard = card;
            cards.forEach(c => c.classList.toggle('pinned', c === card));
            updateFloatingTimer();
        }

        function updateFloatingTimer() {
            if (!nowTimer || !nowLabel || !nowTime || !nowName) return;
            // show multiple taken meds if available
            const takenCards = cards.filter(c => c.classList.contains('taken') && c.dataset.takenAt)
                .sort((a, b) => Number(b.dataset.takenAt) - Number(a.dataset.takenAt));

            const dueBanner = document.getElementById('medDueBanner');
            if (dueBanner) {
                if (takenCards.length > 0) {
                    const latest = takenCards[0];
                    const nm = latest.querySelector('.med-pill-name')?.textContent?.trim() || 'Dose';
                    const ds = latest.querySelector('.med-pill-dose')?.textContent.replace(/\s+/g, ' ').trim() || '';
                    const period = latest.closest('.med-period');
                    const periodName = period?.querySelector('.med-period-name')?.textContent || '';
                    const periodTime = period?.querySelector('.med-period-time')?.textContent || '';
                    const takenAt = Number(latest.dataset.takenAt);

                    const nameEl = document.getElementById('medDueName');
                    const timeEl = document.getElementById('medDueTime');
                    const cdEl = document.getElementById('medDueCountdown');

                    if (nameEl) nameEl.textContent = (nm + ' ' + ds.split('·')[0]).trim();
                    if (timeEl) timeEl.textContent = periodName + ' · ' + periodTime.split('·')[0].trim();
                    if (cdEl) cdEl.textContent = formatElapsedShort(Date.now() - takenAt) + ' ago';

                    dueBanner.style.display = 'flex';
                } else {
                    dueBanner.style.display = 'none';
                }
            }

            if (!pinnedCard && takenCards.length === 0) {
                nowTimer.classList.add('idle');
                nowLabel.textContent = 'Now';
                nowTime.textContent = 'Ready';
                nowName.textContent = 'Tap dose';
                return;
            }

            if (takenCards.length > 0) {
                nowTimer.classList.remove('idle');
                nowLabel.textContent = takenCards.length === 1 ? 'Since' : 'Taken';
                // Build list of taken meds (show up to 3, then +N more)
                const max = 3;
                nowName.innerHTML = '';
                const list = document.createElement('div');
                list.style.display = 'flex';
                list.style.gap = '8px';
                list.style.flexWrap = 'wrap';
                takenCards.slice(0, max).forEach(c => {
                    const nm = c.querySelector('.med-pill-name')?.textContent?.trim() || 'Dose';
                    const takenAt = c.dataset.takenAt ? Number(c.dataset.takenAt) : null;
                    const tag = document.createElement('div');
                    tag.style.background = 'linear-gradient(180deg, #fff, rgba(246,251,248,0.9))';
                    tag.style.border = '1px solid ' + getComputedStyle(document.documentElement).getPropertyValue('--border').trim();
                    tag.style.borderRadius = '10px';
                    tag.style.padding = '6px 8px';
                    tag.style.fontSize = '12px';
                    tag.style.display = 'flex';
                    tag.style.alignItems = 'center';
                    tag.style.gap = '6px';
                    tag.style.flexShrink = '1';
                    tag.style.maxWidth = '100%';

                    const status = document.createElement('div');
                    status.textContent = '✓';
                    status.style.color = 'var(--success)';
                    status.style.fontWeight = '800';
                    status.style.flexShrink = '0';

                    const infoWrap = document.createElement('div');
                    infoWrap.style.display = 'flex';
                    infoWrap.style.flexDirection = 'column';
                    infoWrap.style.minWidth = '0';

                    const top = document.createElement('div');
                    top.style.fontWeight = '700';
                    top.style.color = 'var(--ink)';
                    top.style.whiteSpace = 'normal';
                    top.textContent = nm;

                    const bottom = document.createElement('div');
                    bottom.style.fontSize = '11px';
                    bottom.style.color = 'var(--gray)';
                    if (takenAt) {
                        bottom.textContent = formatElapsedShort(Date.now() - takenAt) + ' ago';
                    } else {
                        bottom.textContent = 'Taken';
                    }

                    infoWrap.appendChild(top);
                    infoWrap.appendChild(bottom);

                    tag.appendChild(status);
                    tag.appendChild(infoWrap);
                    list.appendChild(tag);
                });
                if (takenCards.length > max) {
                    const more = document.createElement('div');
                    more.textContent = `+${takenCards.length - max} more`;
                    more.style.alignSelf = 'center';
                    more.style.color = 'var(--gray)';
                    more.style.fontWeight = '700';
                    list.appendChild(more);
                }
                nowName.appendChild(list);
                // show overall time summary in nowTime
                nowTime.textContent = takenCards.length === 1 ? formatElapsed(Date.now() - Number(takenCards[0].dataset.takenAt)) : `${takenCards.length} meds`;
                return;
            }

            // Fallback: show pinned card info
            const medName = getMedName(pinnedCard);
            nowName.textContent = medName;
            if (pinnedCard.classList.contains('taken') && pinnedCard.dataset.takenAt) {
                nowTimer.classList.remove('idle');
                nowLabel.textContent = 'Since';
                nowTime.textContent = formatElapsed(Date.now() - Number(pinnedCard.dataset.takenAt));
                return;
            }
            nowTimer.classList.add('idle');
            nowLabel.textContent = 'Pinned';
            nowTime.textContent = 'Due';
        }

        function startFloatingTimer() {
            if (floatingTimerId) clearInterval(floatingTimerId);
            floatingTimerId = setInterval(updateFloatingTimer, 1000);
            updateFloatingTimer();
        }

        // Per-pill elapsed timer UI
        let pillElapsedInterval = null;
        function renderElapsedFor(card) {
            if (!card) return;
            let el = card.querySelector('.med-pill-elapsed');
            if (!el) {
                el = document.createElement('div');
                el.className = 'med-pill-elapsed';
                const info = card.querySelector('.med-pill-info');
                if (info) info.appendChild(el);
            }
            if (card.dataset.takenAt) {
                const delta = Date.now() - Number(card.dataset.takenAt);
                el.textContent = 'Taken ' + formatElapsedShort(delta) + ' ago';
                el.style.display = '';
            } else {
                el.style.display = 'none';
            }
        }

        function startPillElapsedLoop() {
            if (pillElapsedInterval) clearInterval(pillElapsedInterval);
            pillElapsedInterval = setInterval(() => {
                cards.forEach(c => { if (c.classList.contains('taken') && c.dataset.takenAt) renderElapsedFor(c); });
            }, 1000);
            // initial render
            cards.forEach(c => { if (c.classList.contains('taken') && c.dataset.takenAt) renderElapsedFor(c); });
        }

        cards.forEach(card => {
            const btn = card.querySelector('.med-pill-btn');
            const lbl = card.querySelector('.med-pill-btn-label');
            card.addEventListener('click', () => setPinnedCard(card));
            if (!btn) return;
            btn.addEventListener('click', event => {
                event.stopPropagation();
                if (card.classList.contains('taken')) {
                    card.classList.remove('taken');
                    card.classList.add('upcoming');
                    btn.textContent = '○';
                    if (lbl) lbl.textContent = 'Tap when taken';
                    delete card.dataset.takenAt;
                    renderElapsedFor(card);
                } else {
                    card.classList.remove('upcoming', 'missed');
                    card.classList.add('taken');
                    btn.textContent = '✓';
                    if (lbl) lbl.textContent = 'Taken';
                    card.dataset.takenAt = String(Date.now());
                    renderElapsedFor(card);
                }
                setPinnedCard(card);
                recomputeSummary();
            });
        });

        cards.forEach((card, index) => {
            if (card.classList.contains('taken') && !card.dataset.takenAt) {
                const minutesAgo = index === 0 ? 46 : 18;
                card.dataset.takenAt = String(Date.now() - minutesAgo * 60 * 1000);
            }
        });

        // render elapsed badges for initial taken cards and start loop
        startPillElapsedLoop();

        const latestTaken = cards
            .filter(card => card.classList.contains('taken') && card.dataset.takenAt)
            .sort((a, b) => Number(b.dataset.takenAt) - Number(a.dataset.takenAt))[0];
        setPinnedCard(latestTaken || cards.find(card => card.classList.contains('upcoming')) || cards[0]);
        startFloatingTimer();
        // attach Preview / Hide toggle for the medication section
        (function attachMedToggle() {
            const toggleBtn = sec.querySelector('#medSectionToggle');
            if (!toggleBtn) return;
            const storageKey = 'medSectionCollapsed';
            const setCollapsed = (collapsed) => {
                sec.classList.toggle('collapsed', collapsed);
                toggleBtn.setAttribute('aria-expanded', String(!collapsed));
                toggleBtn.textContent = collapsed ? 'Preview' : 'Hide';
                try { sessionStorage.setItem(storageKey, collapsed ? '1' : '0'); } catch (e) { }
                if (typeof initRightSpine === 'function') setTimeout(() => initRightSpine(), 140);
            };
            // initialize state from sessionStorage (falls back to attribute)
            let collapsed = false;
            try {
                const s = sessionStorage.getItem(storageKey);
                if (s === '1') collapsed = true;
                else if (s === '0') collapsed = false;
                else collapsed = toggleBtn.getAttribute('aria-expanded') === 'false';
            } catch (e) {
                collapsed = toggleBtn.getAttribute('aria-expanded') === 'false';
            }
            setCollapsed(collapsed);
            toggleBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                const isCollapsed = sec.classList.contains('collapsed');
                setCollapsed(!isCollapsed);
            });
        })();

        // Initial sync
        recomputeSummary();
    }

    /* ─────────────── boot ─────────────── */
    function bootV4Account() {
        initAccJourney();
        initMedRecord();
        initMedication();
        // portfolio mini-cards
        try { initPortfolioCards(); } catch (e) { }
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', bootV4Account);
    } else {
        bootV4Account();
    }

    // Re-run journey alignment when Account screen becomes active
    // (the phone-frame navigation toggles .active classes between screens)
    const screen16 = document.getElementById('screen-16');
    if (screen16) {
        const mo = new MutationObserver(() => {
            if (screen16.classList.contains('active')) {
                // Slight delay so layout settles
                setTimeout(initAccJourney, 60);
            }
        });
        mo.observe(screen16, { attributes: true, attributeFilter: ['class'] });
    }

    // Initialize portfolio mini-card toggles (smooth expand/collapse)
    function initPortfolioCards() {
        const toggles = Array.from(document.querySelectorAll('.acc3-mini-toggle'));
        if (!toggles.length) return;
        toggles.forEach(btn => {
            const head = btn.closest('.acc3-portfolio-mini-card')?.querySelector('.acc3-portfolio-head');
            const body = btn.closest('.acc3-portfolio-mini-card')?.querySelector('.acc3-portfolio-body');
            if (!body) return;
            // collapse by default
            body.dataset.open = 'false';
            btn.addEventListener('click', () => {
                const isOpen = body.dataset.open === 'true';
                if (isOpen) {
                    // collapse: set explicit max-height to current then animate to 0
                    const cur = body.scrollHeight;
                    body.style.maxHeight = cur + 'px';
                    // ensure visible before starting animation
                    body.style.display = body.style.display || '';
                    requestAnimationFrame(() => {
                        body.style.transition = 'max-height .34s cubic-bezier(.2,.9,.2,1), opacity .28s';
                        body.style.maxHeight = '0px';
                        body.style.opacity = '0';
                    });
                    body.dataset.open = 'false';
                    btn.setAttribute('aria-expanded', 'false');
                    btn.textContent = 'View';
                    // after animation finish, hide completely to avoid reserved space
                    setTimeout(() => {
                        body.style.removeProperty('max-height');
                        body.classList.add('mini-collapsed');
                        body.style.display = 'none';
                    }, 380);
                } else {
                    // expand: make element measurable then animate to measured height
                    body.classList.remove('mini-collapsed');
                    // reveal for measurement
                    body.style.display = 'block';
                    body.style.opacity = '0';
                    body.style.maxHeight = '0px';
                    // allow layout to settle then measure
                    requestAnimationFrame(() => {
                        const h = body.scrollHeight;
                        body.style.transition = 'max-height .34s cubic-bezier(.2,.9,.2,1), opacity .28s';
                        body.style.maxHeight = h + 'px';
                        body.style.opacity = '1';
                    });
                    body.dataset.open = 'true';
                    btn.setAttribute('aria-expanded', 'true');
                    btn.textContent = 'Hide';
                    // clear explicit max-height after animation so content can resize naturally
                    setTimeout(() => { body.style.removeProperty('max-height'); }, 420);
                }
                // update spine immediately when toggling so pointer matches layout
                if (typeof initRightSpine === 'function') setTimeout(() => { initRightSpine(); }, 140);
            });
        });
    }

})();

(() => {
    let noteScreenReturn = 1;

    function getActiveScreenNumber() {
        const activeScreen = document.querySelector('.screen-content.active');
        if (!activeScreen) return 1;
        const match = activeScreen.id && activeScreen.id.match(/screen-(\d+)/);
        return match ? parseInt(match[1], 10) : 1;
    }

    function openNoteScreen() {
        if (typeof currentScreen === 'number' && currentScreen !== 16) {
            noteScreenReturn = currentScreen;
        } else {
            const active = getActiveScreenNumber();
            if (active !== 16) noteScreenReturn = active;
        }

        document.body.classList.add('note-workflow-open');
        goTo(16);
        const noteScreen = document.getElementById('screen-16');
        if (noteScreen) noteScreen.scrollTop = 0;
        return false;
    }

    function closeNoteScreen() {
        document.body.classList.remove('note-workflow-open');
        const target = noteScreenReturn && noteScreenReturn !== 16 ? noteScreenReturn : 1;
        goTo(target);
        return false;
    }

    window.openNoteScreen = openNoteScreen;
    window.closeNoteScreen = closeNoteScreen;
})();


/* ═══════════════════════════════════════════════════════════════════
   ACCOUNT v3.1 · Accordion behavior + label memory
   ──────────────────────────────────────────────────────────────────
   Capture-phase listener on the portfolio wrapper. When a toggle
   button is clicked, it runs BEFORE the existing initPortfolioCards
   handler. If the clicked card is currently closed (about to open),
   we synthesize clicks on any other open cards to close them first.
   Result: only one card open at a time. The existing handler still
   does the actual animation and aria management.

   Also: store the original button label ("View" or "Preview") so
   that when the existing handler swaps to "Hide" and back, the
   Summary card returns to "Preview" instead of getting "View".
   ═══════════════════════════════════════════════════════════════════ */
(function () {
    function initAccordion() {
        var wrappers = document.querySelectorAll('#screen-16 .acc3-portfolio-wrapper');
        if (!wrappers.length) return;

        wrappers.forEach(function (wrapper) {
            // Tag every toggle with its original label so we can restore it
            wrapper.querySelectorAll('.acc3-mini-toggle').forEach(function (btn) {
                if (!btn.dataset.originalLabel) {
                    btn.dataset.originalLabel = (btn.textContent || 'View').trim();
                }
            });

            // Capture-phase: runs BEFORE the bubble handler bound to the button
            wrapper.addEventListener('click', function (e) {
                var btn = e.target.closest('.acc3-mini-toggle');
                if (!btn || !wrapper.contains(btn)) return;

                var card = btn.closest('.acc3-portfolio-mini-card');
                var body = card && card.querySelector('.acc3-portfolio-body');
                if (!card || !body) return;

                var isOpen = body.dataset.open === 'true';

                // If user is closing an already-open card, the existing
                // handler will collapse it. Nothing else to do.
                // If user is opening a closed card, close any others first.
                if (!isOpen) {
                    wrapper.querySelectorAll('.acc3-portfolio-mini-card').forEach(function (otherCard) {
                        if (otherCard === card) return;
                        var otherBody = otherCard.querySelector('.acc3-portfolio-body');
                        var otherToggle = otherCard.querySelector('.acc3-mini-toggle');
                        if (otherBody && otherToggle && otherBody.dataset.open === 'true') {
                            // Synthetic click — triggers existing handler
                            // which will animate the collapse.
                            otherToggle.click();
                        }
                    });
                }

                // Schedule scroll-into-view for the opening card
                if (!isOpen) {
                    setTimeout(function () {
                        if (typeof card.scrollIntoView === 'function') {
                            card.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
                        }
                    }, 380);
                }
            }, true); // <-- capture phase

            // Patch the existing handler's text swap by observing aria-expanded
            // changes and restoring the original label on collapse.
            var labelObserver = new MutationObserver(function (mutations) {
                mutations.forEach(function (m) {
                    if (m.attributeName !== 'aria-expanded') return;
                    var btn = m.target;
                    if (!btn.classList || !btn.classList.contains('acc3-mini-toggle')) return;
                    var expanded = btn.getAttribute('aria-expanded') === 'true';
                    if (expanded) {
                        if (btn.textContent.trim() !== 'Hide') {
                            btn.textContent = 'Hide';
                        }
                    } else {
                        var orig = btn.dataset.originalLabel || 'View';
                        if (btn.textContent.trim() !== orig) {
                            btn.textContent = orig;
                        }
                    }
                });
            });
            wrapper.querySelectorAll('.acc3-mini-toggle').forEach(function (btn) {
                labelObserver.observe(btn, { attributes: true, attributeFilter: ['aria-expanded'] });
            });
        });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initAccordion);
    } else {
        // Defer one tick to ensure existing initPortfolioCards has bound first
        setTimeout(initAccordion, 0);
    }
})();
/* ═══════════════════════════════════════════════════════════════════
   END ACCOUNT v3.1 ACCORDION PATCH
   ═══════════════════════════════════════════════════════════════════ */

/* Minimal Back control: appears only while the reader is actively scrolling. */
(function initMinimalBackControl() {
    var SOURCE_ALL_SELECTOR = [
        '.screen-header .back-btn',
        '.mh-inline-back',
        '.md-hosp-back-btn'
    ].join(', ');

    var VISIBLE_SOURCE_SELECTOR = [
        '#screen-16.active .md-hosp-back-btn',
        '.screen-content.active .mh-inline-back',
        '.screen-content.active .screen-header .back-btn'
    ].join(', ');

    var hideTimer = null;
    var refreshFrame = null;
    var floatingBack = null;
    var phoneScreen = null;
    var lastTouchY = null;
    var trackedScrollContainers = new WeakSet();
    var backHistory = [];
    var suppressBackHistory = false;
    var backVisibleUntil = 0;
    var BACK_HIDE_DELAY_MS = 10000;
    var FALLBACK_PREVIOUS_SCREEN = {
        2: 1,
        3: 2,
        4: 3,
        5: 4,
        6: 5,
        7: 6,
        8: 7,
        9: 8,
        10: 9,
        11: 10,
        12: 11,
        13: 6,
        14: 13,
        15: 13,
        17: 5,
        18: 17,
        19: 16,

        21: 19
    };

    function getPhoneScreen() {
        if (!phoneScreen || !document.body.contains(phoneScreen)) {
            phoneScreen = document.querySelector('.phone-screen');
        }
        return phoneScreen;
    }

    function getFloatingBack() {
        var phone = getPhoneScreen();
        if (!phone) return null;
        if (!floatingBack || !document.body.contains(floatingBack)) {
            floatingBack = document.createElement('button');
            floatingBack.type = 'button';
            floatingBack.className = 'mh-floating-back';
            floatingBack.textContent = 'Back';
            floatingBack.setAttribute('aria-label', 'Back');
            floatingBack.hidden = true;
            floatingBack.addEventListener('click', function () {
                var action = getActiveBackAction();
                if (!action) return;
                suppressBackHistory = true;
                try {
                    action();
                } finally {
                    suppressBackHistory = false;
                }
            });
            phone.appendChild(floatingBack);
        }
        return floatingBack;
    }

    function getActiveScreenNumberForBack() {
        var activeScreen = document.querySelector('.screen-content.active');
        if (!activeScreen) return null;
        var match = activeScreen.id && activeScreen.id.match(/^screen-(\d+)$/);
        return match ? parseInt(match[1], 10) : null;
    }

    function getActiveBackSource() {
        return document.querySelector(VISIBLE_SOURCE_SELECTOR);
    }

    function goBackToScreen(screenNum) {
        if (typeof window.goTo !== 'function' || !screenNum) return;
        suppressBackHistory = true;
        try {
            window.goTo(screenNum);
        } finally {
            suppressBackHistory = false;
        }
    }

    function peekHistoryBackScreen(activeScreen) {
        for (var i = backHistory.length - 1; i >= 0; i -= 1) {
            var previous = backHistory[i];
            if (previous && previous !== activeScreen) return previous;
        }
        return null;
    }

    function consumeHistoryBackScreen(activeScreen) {
        for (var i = backHistory.length - 1; i >= 0; i -= 1) {
            var previous = backHistory[i];
            if (previous && previous !== activeScreen) {
                backHistory.length = i;
                return previous;
            }
        }
        backHistory = [];
        return null;
    }

    function getActiveBackAction() {
        var activeScreen = getActiveScreenNumberForBack();
        if (activeScreen === 1 || activeScreen === 16 || activeScreen === 20) return null;

        var source = getActiveBackSource();
        if (source) {
            return function () { source.click(); };
        }

        if (activeScreen === 17 && typeof window.goTo === 'function') {
            return function () { window.goTo(5); };
        }
        var historyScreen = peekHistoryBackScreen(activeScreen);
        if (historyScreen) {
            return function () {
                var current = getActiveScreenNumberForBack();
                goBackToScreen(consumeHistoryBackScreen(current) || historyScreen);
            };
        }
        var fallbackScreen = FALLBACK_PREVIOUS_SCREEN[activeScreen];
        if (fallbackScreen && typeof window.goTo === 'function') {
            return function () { goBackToScreen(fallbackScreen); };
        }
        return null;
    }

    function markBackSources() {
        document.querySelectorAll(SOURCE_ALL_SELECTOR).forEach(function (source) {
            source.classList.add('mh-source-back');
            if (!source.getAttribute('aria-label')) source.setAttribute('aria-label', 'Back');
            if (source.id === 'pc3ModalBack') source.setAttribute('aria-label', 'Back');
        });

    }

    function setFloatingVisible(isVisible) {
        var phone = getPhoneScreen();
        var button = getFloatingBack();
        if (!phone || !button) return;
        var action = getActiveBackAction();
        button.hidden = !action;
        phone.classList.toggle('mh-has-active-back', !!action);
        phone.classList.toggle('mh-back-visible', !!action && isVisible);
    }

    function showBackWhileScrolling(delay) {
        if (!getActiveBackAction()) {
            setFloatingVisible(false);
            return;
        }
        window.clearTimeout(hideTimer);
        backVisibleUntil = Date.now() + (delay || BACK_HIDE_DELAY_MS);
        setFloatingVisible(true);
        hideTimer = window.setTimeout(function () {
            backVisibleUntil = 0;
            setFloatingVisible(false);
        }, delay || BACK_HIDE_DELAY_MS);
    }

    function syncBackAvailability() {
        markBackSources();
        bindBackScrollContainers();
        var action = getActiveBackAction();
        var phone = getPhoneScreen();
        var button = getFloatingBack();
        if (button) button.hidden = !action;
        if (phone) phone.classList.toggle('mh-has-active-back', !!action);
        return !!action;
    }

    function refreshBackControl() {
        var hasAction = syncBackAvailability();
        setFloatingVisible(hasAction && Date.now() < backVisibleUntil);
    }

    function queueRefresh() {
        if (refreshFrame) window.cancelAnimationFrame(refreshFrame);
        refreshFrame = window.requestAnimationFrame(function () {
            refreshFrame = null;
            refreshBackControl();
        });
    }

    function isBackScrollContext(event) {
        if (!getActiveBackAction()) return false;
        if (!event || event.type === 'scroll' || event.type === 'wheel' || event.type === 'touchmove') return true;
        var path = typeof event.composedPath === 'function' ? event.composedPath() : [];
        if (path.some(function (node) {
            return node && node.nodeType === 1 && (
                node.matches('.screen-content.active, .up-scroll, .reviews-scroll, .pc3-modal.active, .md-overlay-card') ||
                node.matches('.phone-screen') ||
                (typeof node.closest === 'function' && node.closest('.screen-content.active, .up-scroll, .reviews-scroll, .pc3-modal.active, .md-overlay-card, .phone-screen'))
            );
        })) return true;

        if (event.type === 'scroll') return true;
        return !!(event.target && typeof event.target.closest === 'function' &&
            event.target.closest('.screen-content.active, .up-scroll, .reviews-scroll, .pc3-modal.active, .md-overlay-card, .phone-screen'));
    }

    function revealBackFromScroll(event, delay) {
        if (!isBackScrollContext(event)) return;
        syncBackAvailability();
        showBackWhileScrolling(delay || BACK_HIDE_DELAY_MS);
    }

    function handleTouchStart(event) {
        lastTouchY = event.touches && event.touches.length ? event.touches[0].clientY : null;
    }

    function handleTouchMove(event) {
        if (lastTouchY === null || !event.touches || !event.touches.length) {
            revealBackFromScroll(event, BACK_HIDE_DELAY_MS);
            return;
        }
        var distance = Math.abs(event.touches[0].clientY - lastTouchY);
        if (distance > 4) revealBackFromScroll(event, BACK_HIDE_DELAY_MS);
    }

    function bindBackScrollContainers() {
        document.querySelectorAll('.screen-content, .up-scroll, .reviews-scroll, .pc3-modal, .md-overlay-card').forEach(function (container) {
            if (trackedScrollContainers.has(container)) return;
            trackedScrollContainers.add(container);
            container.addEventListener('scroll', function (event) {
                revealBackFromScroll(event, BACK_HIDE_DELAY_MS);
            }, { passive: true });
        });
    }

    function installBackHistoryTracker() {
        if (typeof window.goTo !== 'function' || window.goTo.__mhBackHistoryWrapped) return;
        var originalGoTo = window.goTo;
        window.goTo = function (screenNum) {
            var fromScreen = getActiveScreenNumberForBack();
            var result = originalGoTo.apply(this, arguments);
            var toScreen = getActiveScreenNumberForBack();
            if (!suppressBackHistory && fromScreen && toScreen && fromScreen !== toScreen) {
                backHistory.push(fromScreen);
                if (backHistory.length > 20) backHistory.shift();
            }
            queueRefresh();
            return result;
        };
        window.goTo.__mhBackHistoryWrapped = true;
    }

    function setup() {
        installBackHistoryTracker();
        markBackSources();
        bindBackScrollContainers();
        getFloatingBack();
        refreshBackControl();

        document.addEventListener('scroll', revealBackFromScroll, true);
        document.addEventListener('wheel', revealBackFromScroll, { passive: true, capture: true });
        document.addEventListener('touchstart', handleTouchStart, { passive: true, capture: true });
        document.addEventListener('touchmove', handleTouchMove, { passive: true, capture: true });

        var observer = new MutationObserver(function (mutations) {
            var phone = getPhoneScreen();
            var onlyInternalBackState = mutations.every(function (mutation) {
                return mutation.target === phone || mutation.target === floatingBack;
            });
            if (onlyInternalBackState) return;
            queueRefresh();
        });
        observer.observe(document.body, {
            attributes: true,
            attributeFilter: ['class'],
            childList: true,
            subtree: true
        });
    }

    // ============= GLOBAL SEARCH INTERFACE =============
    const globalDatabase = [
        { id: 1, title: 'Cardiology (Heart)', type: 'disease', keyword: 'heart cardio disease cardiology' },
        { id: 2, title: 'Neurology (Brain)', type: 'disease', keyword: 'brain neuro nerve neurology' },
        { id: 3, title: 'Orthopedics (Bone & Joint)', type: 'disease', keyword: 'bone joint ortho orthopedics' },
        { id: 4, title: 'Oncology (Cancer)', type: 'disease', keyword: 'cancer tumor oncology' },
        { id: 5, title: 'Aesthetic Medicine (Beauty)', type: 'disease', keyword: 'beauty plastic surgery aesthetic skin' },

        { id: 6, title: 'Dr. Sarah Jenkins', type: 'doctor', keyword: 'sarah jenkins cardiology doctor specialist heart' },
        { id: 7, title: 'Dr. Marcus Webb', type: 'doctor', keyword: 'marcus webb neurology brain surgeon doctor' },
        { id: 8, title: 'Dr. Emily Chen', type: 'doctor', keyword: 'emily chen oncology cancer specialist doctor' },

        { id: 9, title: 'Aurelia Wellness Center', type: 'hospital', keyword: 'aurelia wellness hospital clinic kuala lumpur malaysia' },
        { id: 10, title: 'Horizon Medical Center', type: 'hospital', keyword: 'horizon medical hospital clinic bangkok thailand' },
        { id: 11, title: 'Zen Aesthetics Institute', type: 'hospital', keyword: 'zen aesthetics hospital clinic seoul korea' }
    ];

    window.handleGlobalSearchInput = function (query) {
        const dropdown = document.getElementById('mhGlobalSearchDropdown');
        if (!dropdown) return;

        if (!query || query.trim() === '') {
            dropdown.classList.remove('active');
            return;
        }

        const term = query.toLowerCase().trim();
        const results = globalDatabase.filter(item =>
            item.title.toLowerCase().includes(term) || item.keyword.toLowerCase().includes(term)
        );

        dropdown.innerHTML = '';

        if (results.length === 0) {
            dropdown.innerHTML = '<div class="mh-search-no-results">No results found for "' + query + '"</div>';
        } else {
            results.forEach(res => {
                let iconSvg = '';
                if (res.type === 'disease') {
                    iconSvg = '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path></svg>';
                } else if (res.type === 'doctor') {
                    iconSvg = '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>';
                } else if (res.type === 'hospital') {
                    iconSvg = '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 21h18M5 21V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v16M12 7v4M10 9h4"></path></svg>';
                }

                const div = document.createElement('div');
                div.className = 'mh-search-result-item';
                div.onclick = function () {
                    document.getElementById('mhGlobalSearchInput').value = res.title;
                    dropdown.classList.remove('active');
                    // Mock route to appointment page
                    if (window.mhOpenAppointment) {
                        setTimeout(() => window.mhOpenAppointment(), 300);
                    }
                };

                div.innerHTML = `
                    <div class="mh-search-result-icon">${iconSvg}</div>
                    <div class="mh-search-result-info">
                        <span class="mh-search-result-title">${res.title}</span>
                        <span class="mh-search-result-type">${res.type}</span>
                    </div>
                `;
                dropdown.appendChild(div);
            });
        }

        dropdown.classList.add('active');
    };

    const mhEscapeHtml = (value) => String(value || '').replace(/[&<>"']/g, (char) => ({
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#39;'
    }[char]));

    // Attach global search event listeners
    const renderHomeHighlightPackages = () => {
        const container = document.getElementById('mhHomePackagesContainer');
        if (!container) return;

        const homePackages = [
            { title: "Premium VIP Health Check", img: "./assets/images/packages/vip-health-check.jpg", type: "Medical", discount: "-15%", spec: "By Dr. Sarah Jenkins", oldPrice: "$850", newPrice: "$720", tier: "Elite Executive", rating: "4.9", concierge: "Private check-in" },
            { title: "Rhinoplasty Surgery Package", img: "./assets/images/treatments/aesthetic-treatment-suite.jpg", type: "Beauty", discount: "-10%", spec: "By Dr. Lee Min Ho", oldPrice: "$4,500", newPrice: "$4,050", tier: "Signature Beauty", rating: "4.8", concierge: "3D consult" },
            { title: "Comprehensive Heart Screening", img: "./assets/images/packages/heart-screening-package.jpg", type: "Medical", discount: "-20%", spec: "By Dr. Marcus Webb", oldPrice: "$1,200", newPrice: "$960", tier: "Cardiac Elite", rating: "5.0", concierge: "Specialist review" },
            { title: "Non-Surgical Facelift", img: "./assets/images/packages/non-surgical-facelift.jpg", type: "Beauty", discount: "-10%", spec: "By Dr. Chloe Adams", oldPrice: "$1,500", newPrice: "$1,350", tier: "Glow Suite", rating: "4.7", concierge: "Same-day plan" },
            { title: "LASIK Eye Surgery", img: "./assets/images/packages/lasik-eye-surgery.jpg", type: "Medical", discount: "-25%", spec: "By Dr. Elena Rostova", oldPrice: "$2,800", newPrice: "$2,100", tier: "Vision Select", rating: "4.9", concierge: "Eligibility check" },
            { title: "Dental Implant Package", img: "./assets/images/packages/dental-implant-package.jpg", type: "Medical", discount: "-15%", spec: "By Dr. James Wilson", oldPrice: "$1,600", newPrice: "$1,360", tier: "Smile Atelier", rating: "4.8", concierge: "CBCT mapping" },
            { title: "Breast Augmentation", img: "./assets/images/treatments/surgery-care-suite.jpg", type: "Beauty", discount: "-5%", spec: "By Dr. Park Jin", oldPrice: "$6,500", newPrice: "$6,175", tier: "Private Surgery", rating: "4.8", concierge: "Sizing consult" },
            { title: "Full Body MRI Scan", img: "./assets/images/packages/full-body-mri-scan.jpg", type: "Medical", discount: "-30%", spec: "By Horizon Radiology", oldPrice: "$2,200", newPrice: "$1,540", tier: "Imaging Elite", rating: "4.9", concierge: "Radiology brief" },
            { title: "Hair Transplant (FUE)", img: "./assets/images/treatments/aesthetic-treatment-suite.jpg", type: "Beauty", discount: "-12%", spec: "By Dr. Aisha Khan", oldPrice: "$3,400", newPrice: "$2,992", tier: "FUE Signature", rating: "4.7", concierge: "Hairline design" },
            { title: "Weight Loss Bariatric", img: "./assets/images/packages/non-surgical-facelift.jpg", type: "Medical", discount: "-10%", spec: "By Dr. Michael Chen", oldPrice: "$8,500", newPrice: "$7,650", tier: "Metabolic Care", rating: "4.8", concierge: "Risk board" },
            { title: "IV Drip Therapy Rejuvenation", img: "./assets/images/treatments/wellness-treatment-room.jpg", type: "Beauty", discount: "-20%", spec: "By Aurelia Wellness", oldPrice: "$250", newPrice: "$200", tier: "Recovery Lounge", rating: "4.6", concierge: "Wellness reset" },
            { title: "Knee Replacement Prep", img: "./assets/images/treatments/surgery-care-suite.jpg", type: "Medical", discount: "-8%", spec: "By Dr. Robert Vance", oldPrice: "$11,000", newPrice: "$10,120", tier: "Ortho Premier", rating: "4.9", concierge: "Implant consult" },
            { title: "Botox & Fillers Combo", img: "./assets/images/treatments/wellness-treatment-room.jpg", type: "Beauty", discount: "-15%", spec: "By Dr. Sofia Ruiz", oldPrice: "$800", newPrice: "$680", tier: "Subtle Refresh", rating: "4.8", concierge: "Dose control" },
            { title: "Oncology Second Opinion", img: "./assets/images/treatments/surgery-care-suite.jpg", type: "Medical", discount: "-10%", spec: "By Dr. Emily Stanton", oldPrice: "$950", newPrice: "$855", tier: "Tumor Board", rating: "5.0", concierge: "Case review" },
            { title: "Skin Laser Resurfacing", img: "./assets/images/treatments/aesthetic-treatment-suite.jpg", type: "Beauty", discount: "-18%", spec: "By Dr. Kenji Ito", oldPrice: "$1,400", newPrice: "$1,148", tier: "Skin Studio", rating: "4.7", concierge: "Texture plan" }
        ];

        const mhEscapeHtml = (value) => String(value || '').replace(/[&<>"']/g, (char) => ({
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#39;'
        }[char]));

        const mhPackageSpecifics = (pkg, index) => {
            const title = pkg.title.toLowerCase();
            const isBeauty = pkg.type === 'Beauty';
            const base = {
                duration: isBeauty ? '45 min - 3 hrs' : '1 day',
                recovery: isBeauty ? 'Same day to 7 days' : 'Report in 24-72 hrs',
                comfort: isBeauty ? 'Low to medium' : 'Clinician reviewed',
                result: isBeauty ? 'Visible refinement with natural-looking planning.' : 'Clear next-step guidance from a specialist team.',
                credibility: isBeauty ? 'Licensed clinic, photo review protocol, and follow-up check-in.' : 'Accredited partner facility, specialist review, and transparent care coordination.'
            };

            if (title.includes('heart')) return { ...base, duration: '2-3 hrs', recovery: '24-48 hr report', comfort: 'Cardiology safety review', result: 'Risk score, ECG/echo findings, and a clear cardiac action plan.' };
            if (title.includes('rhinoplasty')) return { ...base, duration: '2-3 hrs', recovery: '7-14 days', comfort: 'Medium', result: 'Balanced profile refinement with 3D planning and swelling timeline.' };
            if (title.includes('facelift')) return { ...base, duration: '45-60 min', recovery: '1-3 days', comfort: 'Low', result: 'Lifted, fresher appearance without surgical downtime.' };
            if (title.includes('lasik')) return { ...base, duration: '20 min', recovery: '1-2 days', comfort: 'Ophthalmologist cleared', result: 'Sharper day-to-day vision after eligibility screening.' };
            if (title.includes('dental')) return { ...base, duration: '1-2 visits', recovery: '3-7 days', comfort: 'Dental CT planned', result: 'Implant roadmap with bone, bite, and restoration planning.' };
            if (title.includes('breast')) return { ...base, duration: '2-3 hrs', recovery: '2-3 weeks', comfort: 'Medium', result: 'Proportion planning with implant sizing and recovery guidance.' };
            if (title.includes('mri')) return { ...base, duration: '90 min', recovery: 'No downtime', comfort: 'Radiologist reviewed', result: 'Whole-body screening summary with flagged follow-up priorities.' };
            if (title.includes('hair')) return { ...base, duration: '6-8 hrs', recovery: '7-10 days', comfort: 'Low to medium', result: 'Hairline design, graft plan, and staged growth expectation.' };
            if (title.includes('bariatric')) return { ...base, duration: '3-4 days', recovery: '2-4 weeks', comfort: 'Surgical risk review', result: 'Weight-loss pathway with labs, anesthesia review, and nutrition plan.' };
            if (title.includes('iv drip')) return { ...base, duration: '45 min', recovery: 'No downtime', comfort: 'Low', result: 'Hydration and glow support for travel fatigue or wellness reset.' };
            if (title.includes('knee')) return { ...base, duration: '2 visits', recovery: 'Plan in 48 hrs', comfort: 'Orthopedic review', result: 'Surgery readiness checklist, implant discussion, and rehab plan.' };
            if (title.includes('botox')) return { ...base, duration: '30 min', recovery: 'Same day', comfort: 'Low', result: 'Softened lines and refreshed contours with dose control.' };
            if (title.includes('oncology')) return { ...base, duration: '60 min review', recovery: 'Board note in 72 hrs', comfort: 'Tumor-board style review', result: 'Second opinion on diagnosis, staging, and treatment sequence.' };
            if (title.includes('laser')) return { ...base, duration: '45 min', recovery: '3-5 days', comfort: 'Low to medium', result: 'Brighter texture and smoother skin tone with aftercare plan.' };
            return base;
        };

        const mhBuildPackageDetail = (pkg, index) => {
            const isBeauty = pkg.type === 'Beauty';
            const specialist = pkg.spec.replace(/^By\s+/i, '');
            const specifics = mhPackageSpecifics(pkg, index);
            const title = pkg.title.toLowerCase();
            const reviewCaseImages = isBeauty
                ? [
                    './assets/images/treatments/aesthetic-treatment-suite.jpg',
                    './assets/images/packages/non-surgical-facelift.jpg',
                    './assets/images/treatments/wellness-treatment-room.jpg'
                ]
                : [
                    './assets/images/treatments/surgery-care-suite.jpg',
                    './assets/images/packages/vip-health-check.jpg',
                    './assets/images/packages/lasik-eye-surgery.jpg'
                ];
            const caseTopic = title.includes('rhinoplasty') ? 'rhinoplasty profile refinement'
                : title.includes('facelift') ? 'non-surgical lifting result'
                    : title.includes('breast') ? 'body proportion planning'
                        : title.includes('hair') ? 'FUE hairline growth journey'
                            : title.includes('botox') ? 'soft-line injectable refresh'
                                : title.includes('laser') ? 'skin texture improvement'
                                    : title.includes('iv drip') ? 'wellness glow recovery'
                                        : title.includes('heart') ? 'cardiac screening pathway'
                                            : title.includes('lasik') ? 'vision correction journey'
                                                : title.includes('dental') ? 'implant planning case'
                                                    : title.includes('mri') ? 'advanced imaging review'
                                                        : title.includes('bariatric') ? 'bariatric readiness case'
                                                            : title.includes('knee') ? 'knee replacement preparation'
                                                                : title.includes('oncology') ? 'oncology second-opinion review'
                                                                    : 'package review case';
            const gallery = isBeauty
                ? [
                    { img: reviewCaseImages[0], caption: `Review Case 01 · ${caseTopic}` },
                    { img: reviewCaseImages[1], caption: 'Review Case 02 · before / after planning' },
                    { img: reviewCaseImages[2], caption: 'Review Case 03 · recovery check and result expectation' }
                ]
                : [
                    { img: pkg.img, caption: `Review Case 01 · ${caseTopic}` },
                    { img: reviewCaseImages[0], caption: 'Review Case 02 · clinical documents reviewed' },
                    { img: reviewCaseImages[1], caption: 'Review Case 03 · specialist notes and next-step plan' }
                ];

            return {
                tone: isBeauty ? 'Beauty Clinic Package' : 'Medical Package',
                primaryCta: isBeauty ? 'Book Now' : 'Consult',
                badge: index % 3 === 0 ? 'Popular' : 'New',
                overview: isBeauty
                    ? `${pkg.title} is designed for patients who want visible, modern results with a clear plan, realistic expectations, and fast access to a trusted clinic team.`
                    : `${pkg.title} is arranged for patients who need a safer, clearer medical decision with specialist review, transparent inclusions, and coordinated next steps.`,
                gallery,
                metrics: [
                    ['Duration', specifics.duration],
                    [isBeauty ? 'Pain level' : 'Safety', specifics.comfort],
                    ['Recovery', specifics.recovery]
                ],
                benefits: isBeauty
                    ? ['Visual-result planning before booking', 'Fast consult-to-treatment workflow', 'Natural outcome discussion and suitability check', 'Private recovery guidance after the visit']
                    : ['Specialist-led review before treatment', 'Clear safety boundaries and escalation notes', 'Procedure and report pathway explained in plain language', 'Coordinator support before and after the appointment'],
                included: isBeauty
                    ? ['Aesthetic consultation and suitability screening', 'Photo or 3D planning where appropriate', 'Clinic procedure room and standard consumables', 'Recovery instructions and follow-up message', 'Coordinator support for schedule and language']
                    : ['Specialist consultation or clinical review', 'Standard package tests or procedure preparation', 'Nursing, facility, and report coordination', 'Medication and allergy history check', 'Medical summary support for family understanding'],
                social: isBeauty
                    ? [
                        ['Before / after', 'Preview angles, goals, and likely change before confirming treatment.'],
                        ['Trending tags', '#NaturalLook #FastGlow #SubtleRefinement'],
                        ['Duration', `${specifics.duration}, with recovery usually ${specifics.recovery.toLowerCase()}.`],
                        ['Quick review', 'Patients choose this when they want visible change without a confusing clinic journey.']
                    ]
                    : [
                        ['Safety info', 'Clinician review confirms whether this package fits your case before final pricing.'],
                        ['Recovery time', `${specifics.recovery}, depending on findings and doctor advice.`],
                        ['Doctor insight', 'Bring previous reports, medication lists, allergies, and timeline of symptoms.'],
                        ['Patient journey', 'Inquiry, document check, specialist review, appointment, report, follow-up.']
                    ],
                doctor: {
                    name: specialist,
                    role: isBeauty ? 'Aesthetic specialist / clinic team' : 'Lead specialist / hospital team',
                    note: isBeauty
                        ? 'Focuses on suitability, facial balance, trend-aware planning, and safe recovery expectations.'
                        : 'Focuses on clinical appropriateness, risk review, procedure clarity, and coordinated follow-up.'
                },
                credibility: specifics.credibility,
                expected: specifics.result,
                tags: isBeauty
                    ? ['Natural result', 'Fast access', 'Photo planning', 'Recovery check']
                    : ['Safety first', 'Transparent quote', 'Specialist review', 'Care coordinator'],
                reviews: isBeauty
                    ? [
                        ['Fast and clear', 'The clinic explained what would look natural and what not to overdo.'],
                        ['Good recovery plan', 'I understood swelling, aftercare, and when to send follow-up photos.']
                    ]
                    : [
                        ['More confidence', 'The package made the next medical step easier to understand before travel.'],
                        ['Clear inclusions', 'The coordinator explained what was included and what could change after review.']
                    ],
                faqs: isBeauty
                    ? [
                        ['Will I see the result immediately?', 'Some changes are visible quickly, but final results depend on swelling, healing, and the selected procedure.'],
                        ['Is the price final?', 'The displayed price is a package estimate. Final quote depends on doctor assessment and treatment scope.'],
                        ['Can I ask for a natural look?', 'Yes. The consult is built around suitability, proportion, and avoiding over-treatment.']
                    ]
                    : [
                        ['Is this a diagnosis?', 'No. It is a package pathway and specialist review support. Final medical decisions come from the treating doctor.'],
                        ['What can change the price?', 'Complexity, additional tests, extended stay, special devices, medicines, or complications can change final cost.'],
                        ['What should I prepare?', 'Bring previous reports, imaging, medication list, allergies, and questions for the specialist.']
                    ]
            };
        };

        window.homePackagesData = homePackages.map((pkg, index) => ({
            ...pkg,
            detail: mhBuildPackageDetail(pkg, index)
        })); // Expose to global for detail view

        container.innerHTML = window.homePackagesData.map((pkg, idx) => `
            <div class="mh-home-package-card" onclick="mhShowPackageDetail(${idx})">
                <div class="mh-pkg-img-wrap">
                    <div class="mh-pkg-discount-badge">${pkg.discount}</div>
                    <div class="mh-pkg-type-badge">${pkg.type}</div>
                    <img src="${mhEscapeHtml(pkg.img)}" alt="${mhEscapeHtml(pkg.title)}" loading="lazy">
                    <div class="mh-pkg-elite-ribbon">
                        <div>
                            <strong>${mhEscapeHtml(pkg.tier || 'Elite Access')}</strong>
                            <span>${mhEscapeHtml(pkg.concierge || 'Concierge review')}</span>
                        </div>
                        <div class="mh-pkg-elite-mark">M</div>
                    </div>
                </div>
                <div class="mh-pkg-body">
                    <div class="mh-pkg-kicker-row">
                        <div class="mh-pkg-kicker">${mhEscapeHtml(pkg.type)} privilege</div>
                        <div class="mh-pkg-rating">★ ${mhEscapeHtml(pkg.rating || '4.8')}</div>
                    </div>
                    <h3 class="mh-pkg-title">${mhEscapeHtml(pkg.title)}</h3>
                    <div class="mh-pkg-specialist">
                        <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" /><circle cx="9" cy="7" r="4" /><path d="M22 21v-2a4 4 0 0 0-3-3.87" /><path d="M16 3.13a4 4 0 0 1 0 7.75" /></svg>
                        ${mhEscapeHtml(pkg.spec)}
                    </div>
                    <div class="mh-pkg-mini-grid">
                        <div class="mh-pkg-mini"><span>Duration</span><strong>${mhEscapeHtml(pkg.detail.metrics[0][1])}</strong></div>
                        <div class="mh-pkg-mini"><span>${mhEscapeHtml(pkg.detail.metrics[1][0])}</span><strong>${mhEscapeHtml(pkg.detail.metrics[1][1])}</strong></div>
                        <div class="mh-pkg-mini"><span>Recovery</span><strong>${mhEscapeHtml(pkg.detail.metrics[2][1])}</strong></div>
                    </div>
                    <div class="mh-pkg-price-row">
                        <div>
                            <span class="mh-pkg-price-old">${mhEscapeHtml(pkg.oldPrice)}</span>
                            <span class="mh-pkg-price-new">${mhEscapeHtml(pkg.newPrice)}</span>
                            <span class="mh-pkg-price-note">member estimate</span>
                        </div>
                        <div class="mh-pkg-view">View</div>
                    </div>
                </div>
            </div>
        `).join('');
    };

    window.mhTogglePackageAccordion = (button) => {
        const item = button?.closest('.mh-pkg-accordion-item');
        if (!item) return;
        const isOpen = item.classList.toggle('open');
        button.setAttribute('aria-expanded', String(isOpen));
    };

    const mhRenderPackageList = (items) => `
        <ul class="mh-pkg-list">
            ${items.map((item) => `<li>${mhEscapeHtml(item)}</li>`).join('')}
        </ul>
    `;

    window.mhShowPackageDetail = (index) => {
        const pkg = window.homePackagesData[index];
        if (!pkg) return;
        const detail = pkg.detail;
        if (!detail) return;
        const screen24 = document.getElementById('screen-24');
        if (!screen24) return;

        screen24.classList.toggle('is-beauty', pkg.type === 'Beauty');
        document.getElementById('mhPkgTopTitle').innerText = pkg.title;
        document.getElementById('mhPkgDetailTitle').innerText = pkg.title;
        document.getElementById('mhPkgDetailType').innerText = detail.tone;
        document.getElementById('mhPkgOverview').innerText = detail.overview;
        document.getElementById('mhPkgDetailOldPrice').innerText = pkg.oldPrice;
        document.getElementById('mhPkgDetailNewPrice').innerText = pkg.newPrice;
        document.getElementById('mhPkgPriceNote').innerText = pkg.type === 'Beauty'
            ? 'Estimate before final clinic plan'
            : 'Final quote after specialist review';
        document.getElementById('mhPkgPrimaryCta').innerText = detail.primaryCta;

        const fallbackArt = `
            <span class="mh-pkg-fallback-art" aria-hidden="true">
                <svg viewBox="0 0 120 120">
                    <rect x="24" y="24" width="72" height="72" rx="20"></rect>
                    <path d="M42 62h16l7-15 11 29 7-14h15" class="accent"></path>
                    <path d="M43 43h34"></path>
                    <path d="M43 84h26"></path>
                </svg>
            </span>
        `;
        document.getElementById('mhPkgCarousel').innerHTML = detail.gallery.map((slide) => `
            <article class="mh-pkg-hero-slide">
                ${fallbackArt}
                <img class="is-loading" src="${mhEscapeHtml(slide.img)}" alt="${mhEscapeHtml(slide.caption)}" loading="lazy" onload="this.classList.remove('is-loading')" onerror="this.classList.remove('is-loading');this.classList.add('is-broken')" referrerpolicy="no-referrer">
                <div class="mh-pkg-case-label">Review Case</div>
                <div class="mh-pkg-slide-caption">${mhEscapeHtml(slide.caption)}</div>
            </article>
        `).join('');

        document.getElementById('mhPkgBadgeRow').innerHTML = `
            <span class="mh-pkg-detail-badge hot">${mhEscapeHtml(pkg.discount)} off</span>
            <span class="mh-pkg-detail-badge new">${mhEscapeHtml(detail.badge)}</span>
            <span class="mh-pkg-detail-badge">${mhEscapeHtml(pkg.type)}</span>
        `;

        document.getElementById('mhPkgMetaRow').innerHTML = detail.metrics.map(([label, value]) => `
            <div class="mh-pkg-meta-pill">
                <span>${mhEscapeHtml(label)}</span>
                <strong>${mhEscapeHtml(value)}</strong>
            </div>
        `).join('');

        const socialTitle = pkg.type === 'Beauty' ? 'Social result preview' : 'Safety and patient journey';
        const reviewTitle = pkg.type === 'Beauty' ? 'Quick reviews' : 'Patient confidence notes';
        const sections = [
            {
                key: 'benefits',
                index: '01',
                title: 'Key benefits',
                preview: detail.benefits.slice(0, 2).join(' · '),
                open: true,
                body: mhRenderPackageList(detail.benefits)
            },
            {
                key: 'included',
                index: '02',
                title: 'What is included',
                preview: detail.included.slice(0, 2).join(' · '),
                body: mhRenderPackageList(detail.included)
            },
            {
                key: 'social',
                index: '03',
                title: socialTitle,
                preview: detail.social.map(([title]) => title).slice(0, 3).join(' · '),
                body: `
                    <div class="mh-pkg-social-grid">
                        ${detail.social.map(([title, text]) => `
                            <article class="mh-pkg-social-card">
                                <strong>${mhEscapeHtml(title)}</strong>
                                <span>${mhEscapeHtml(text)}</span>
                            </article>
                        `).join('')}
                    </div>
                `
            },
            {
                key: 'doctor',
                index: '04',
                title: 'Doctor and credibility',
                preview: `${detail.doctor.name} · ${detail.doctor.role}`,
                body: `
                    <article class="mh-pkg-doctor-card">
                        <div class="mh-pkg-doctor-avatar">${mhEscapeHtml(detail.doctor.name.charAt(0) || 'M')}</div>
                        <div>
                            <strong>${mhEscapeHtml(detail.doctor.name)}</strong>
                            <span>${mhEscapeHtml(detail.doctor.role)}</span>
                            <span>${mhEscapeHtml(detail.doctor.note)}</span>
                        </div>
                    </article>
                    <div class="mh-pkg-review-card" style="margin-top:10px;">
                        <strong>Clinic credibility</strong>
                        <p>${mhEscapeHtml(detail.credibility)}</p>
                    </div>
                `
            },
            {
                key: 'results',
                index: '05',
                title: 'Expected results',
                preview: detail.expected,
                body: `
                    <p class="mh-pkg-detail-overview">${mhEscapeHtml(detail.expected)}</p>
                    <div class="mh-pkg-tag-row">
                        ${detail.tags.map((tag) => `<span class="mh-pkg-trend-tag">${mhEscapeHtml(tag)}</span>`).join('')}
                    </div>
                `
            },
            {
                key: 'reviews',
                index: '06',
                title: reviewTitle,
                preview: detail.reviews.map(([title]) => title).join(' · '),
                body: `
                    <div class="mh-pkg-faq-list">
                        ${detail.reviews.map(([title, text]) => `
                            <article class="mh-pkg-review-card">
                                <strong>${mhEscapeHtml(title)}</strong>
                                <p>${mhEscapeHtml(text)}</p>
                            </article>
                        `).join('')}
                    </div>
                `
            },
            {
                key: 'faq',
                index: '07',
                title: 'FAQs',
                preview: detail.faqs.map(([question]) => question).slice(0, 2).join(' · '),
                body: `
                    <div class="mh-pkg-faq-list">
                        ${detail.faqs.map(([question, answer]) => `
                            <article class="mh-pkg-faq-item">
                                <strong>${mhEscapeHtml(question)}</strong>
                                <p>${mhEscapeHtml(answer)}</p>
                            </article>
                        `).join('')}
                    </div>
                `
            }
        ];

        document.getElementById('mhPkgAccordion').innerHTML = sections.map((section) => `
            <section class="mh-pkg-accordion-item${section.open ? ' open' : ''}" data-section="${mhEscapeHtml(section.key)}">
                <button class="mh-pkg-accordion-head" type="button" aria-expanded="${section.open ? 'true' : 'false'}" onclick="mhTogglePackageAccordion(this)">
                    <span class="mh-pkg-accordion-label">
                        <span>${mhEscapeHtml(section.index)}</span>
                        <strong>${mhEscapeHtml(section.title)}</strong>
                        <em>${mhEscapeHtml(section.preview)}</em>
                    </span>
                    <span class="mh-pkg-accordion-icon">⌄</span>
                </button>
                <div class="mh-pkg-accordion-body">
                    <div class="mh-pkg-accordion-inner">${section.body}</div>
                </div>
            </section>
        `).join('');

        // Navigate to screen 24
        goTo(24);
    };

    window.mhTogglePromotionPopup = (btn) => {
        const popup = document.getElementById('mhPromotionPopup');
        if (!popup) return;
        const willOpen = !popup.classList.contains('active');
        popup.classList.toggle('active', willOpen);
        if (btn) btn.setAttribute('aria-expanded', String(willOpen));
    };

    const ensurePackageScreenContained = () => {
        const phoneScreen = document.querySelector('.phone-screen');
        const packageScreen = document.getElementById('screen-24');
        if (!phoneScreen || !packageScreen || packageScreen.parentElement === phoneScreen) return;
        phoneScreen.appendChild(packageScreen);
    };

    document.addEventListener('DOMContentLoaded', () => {
        ensurePackageScreenContained();
        renderHomeHighlightPackages();

        const searchInput = document.getElementById('mhGlobalSearchInput');
        if (searchInput) {
            searchInput.addEventListener('input', (e) => window.handleGlobalSearchInput(e.target.value));
            searchInput.addEventListener('focus', (e) => {
                if (e.target.value.trim() !== '') window.handleGlobalSearchInput(e.target.value);
            });
        }

        // Close dropdowns on click outside
        document.addEventListener('click', (e) => {
            const searchContainer = document.querySelector('.mh-global-search-container');
            const searchDropdown = document.getElementById('mhGlobalSearchDropdown');
            if (searchContainer && !searchContainer.contains(e.target) && searchDropdown) {
                searchDropdown.classList.remove('active');
            }

            const promoBtnWrap = document.querySelector('.mh-browse-trigger-wrap');
            const promoPopup = document.getElementById('mhPromotionPopup');
            if (promoBtnWrap && !promoBtnWrap.contains(e.target) && promoPopup) {
                promoPopup.classList.remove('active');
                const btn = promoBtnWrap.querySelector('.mh-promotion-btn');
                if (btn) btn.setAttribute('aria-expanded', 'false');
            }
        });
    });

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', setup);
    } else {
        setTimeout(setup, 0);
    }
})();

// Project-wide click feedback for static and dynamically rendered controls.
(function initMedhubInteractionFlow() {
    const interactiveSelector = [
        'button:not(:disabled)',
        'a[href]',
        '[role="button"]',
        '[onclick]',
        '.btn',
        '.back-btn',
        '.hospital-card',
        '.hosp-card',
        '.package-card',
        '.care-card',
        '.agreement-card',
        '.quick-action-card',
        '.g6-care-card',
        '.g6-agreement-accordion',
        '.ip-bottom-nav-item',
        '.ip-journey-seg',
        '.mh-market-card',
        '.mh-doctor-card',
        '.mh-home-package-card',
        '.mh-choice',
        '.mh-card-link',
        '.mh-detail-card',
        '.mh-content-index-item',
        '.mh-pkg-summary-card',
        '.mh-pkg-section-card',
        '.mh-pkg-social-card',
        '.mh-pkg-doctor-card',
        '.mh-pkg-review-card',
        '.mh-pkg-faq-item',
        '.pc3-card',
        '.pc3-cat-tile',
        '.pc3-chip',
        '.pc3-mode-btn',
        '.pc3-country-pill',
        '.pc3-rec-card',
        '.pc3-warn-card',
        '.pc3-basket-item',
        '.pc3-cmp-h-tile',
        '.acc3-portfolio-card',
        '.acc3-portfolio-mini-card',
        '.acc3-payment-year-card',
        '.acc3-payment-category-head',
        '.acc3-payment-small-btn',
        '.acc3-payment-year-chip',
        '.acc3-aiu',
        '.med-pill-card',
        '.med-section-toggle'
    ].join(',');

    const isUsableInteractive = (el) => {
        if (!el || !el.closest('.phone-screen')) return false;
        if (el.matches('input, textarea, select, option, label')) return false;
        if (el.closest('[disabled], [aria-disabled="true"]')) return false;
        return true;
    };

    const pulse = (el) => {
        if (!isUsableInteractive(el)) return;
        window.clearTimeout(el._mhPressTimer);
        window.clearTimeout(el._mhFlowTimer);
        el.classList.add('mh-pressing');
        el._mhPressTimer = window.setTimeout(() => {
            el.classList.remove('mh-pressing');
            el.classList.remove('mh-click-flow');
            void el.offsetWidth;
            el.classList.add('mh-click-flow');
            el._mhFlowTimer = window.setTimeout(() => el.classList.remove('mh-click-flow'), 340);
        }, 90);
    };

    document.addEventListener('pointerdown', (event) => {
        const el = event.target.closest(interactiveSelector);
        pulse(el);
    }, { passive: true });

    document.addEventListener('keydown', (event) => {
        if (event.key !== 'Enter' && event.key !== ' ') return;
        const el = event.target.closest(interactiveSelector);
        pulse(el);
    });
})();
