# Asset Architecture

This project keeps production media inside `assets/` and references it with relative paths only.

## Folder Map

- `assets/images/backgrounds/` - full-surface and decorative background photos
- `assets/images/hospitals/` - hospital, clinic, room, and facility photos
- `assets/images/packages/` - package and pricing card imagery
- `assets/images/treatments/` - treatment, surgery, wellness, and beauty imagery
- `assets/images/doctors/` - clinician portraits and doctor-specific imagery
- `assets/images/editorial/` - article, insight, and review imagery
- `assets/images/avatars/` - user profile avatars
- `assets/images/products/` - physical products or service product visuals
- `assets/images/ui/` - interface-specific raster assets
- `assets/icons/` - icon files
- `assets/logos/` - brand marks and partner logos
- `assets/svg/` - reusable SVG artwork
- `assets/fonts/` - local webfont files
- `assets/videos/` - local video assets
- `assets/tmp/` - temporary assets only; do not reference from production screens

## Path Rules

- From `index.html` and `js/app.js`, use `./assets/...`.
- From files inside `css/`, use `../assets/...`.
- Do not reference absolute local machine paths, third-party image URLs, or root-relative `/assets/...` paths.
- Use kebab-case filenames that describe the asset purpose, for example `premium-hospital-suite.jpg`.
- Store each reusable image once and point repeated UI references to the same file.
- Keep temporary or test files in `assets/tmp/` until they are approved for production placement.
