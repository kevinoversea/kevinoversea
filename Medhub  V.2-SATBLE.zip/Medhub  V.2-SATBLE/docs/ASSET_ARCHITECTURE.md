# Medhub Asset Architecture

The app now uses a local, portable asset workflow. Static images are stored under `assets/` and referenced with relative paths so the prototype can move between XAMPP, local file previews, and deployed hosting without depending on remote image services.

## Production Rules

1. Put every production visual in the correct `assets/` category before referencing it.
2. Use kebab-case names that describe the business context, not the original vendor filename.
3. Reuse an existing asset when the same image appears in multiple cards or data objects.
4. Use `./assets/...` from root HTML and JavaScript files.
5. Use `../assets/...` from CSS files.
6. Keep external URLs only for functional destinations such as Telegram, Facebook, payment links, or API/webhook endpoints.
7. Do not ship references to absolute machine paths such as `/Applications/...`, `file://...`, or drive-letter paths.

## Current Structure

```text
assets/
  fonts/
  icons/
  images/
    avatars/
    backgrounds/
    doctors/
    editorial/
    hospitals/
    packages/
    products/
    treatments/
    ui/
  logos/
  svg/
  tmp/
  videos/
```

## Maintenance Checklist

- Search for `https://images.` before shipping.
- Search for `/Applications/`, `file://`, and drive-letter paths before sharing the project.
- Confirm new CSS background paths are relative to the CSS file location.
- Keep `assets/tmp/` out of production references.
