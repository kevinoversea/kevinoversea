# Medhub24 V.2 Architecture

## Runtime Surface

This prototype is a static single-page app rooted at `index.html`.

- `index.html`: structural shell, screen markup, stable IDs/classes, and demo workflow anchors.
- `css/styles.css`: all visual styling, screen containment, responsive behavior, and state-driven presentation.
- `js/app.js`: navigation, state, generated UI, event handlers, demo data, and future API integration points.

The app runs inside `.phone-screen`. Each routed page is a `.screen-content` block with an ID like `screen-1`, `screen-16`, or `screen-20`. The `goTo(screenNumber)` function activates one screen, updates navigation state, and resets screen-specific body classes where needed.

## Active Workflows

- Home and appointment: `screen-1`, Home cards, browse popups, detail page, and appointment functions in the inline Home script.
- Account and Note: `screen-16`, `ACCOUNT_JOURNEY`, `scrollToAccountSection`, `syncJourneyUI`, and `note-workflow-open` body state.
- Health dashboard: `screen-19` and related year/hospital/doctor folder renderers in `js/app.js`.
- Price comparison: `screen-20` with the active `pc3` module only. Legacy `pc-` and `priceCompare*` code was removed because no active HTML anchors referenced it.
- AI upload: `screen-21`, `acc3Aiu`, upload state classes, manual entry fields, and Payment Portfolio update hooks.
- Package detail: `screen-24`, package detail renderers, and `goTo(24)` paths.

## Function Chains

- Navigation: user click -> `goTo(n)` -> active screen switch -> `syncJourneyUI(n)` -> screen-specific init if required.
- Language: language button -> `toggleLangDropdown()` -> `switchLang(lang)` -> translated text and labels refresh.
- Account journey: `goTo(16)` or account nav click -> `scrollToAccountSection(key)` -> `updateAccountJourney(key)` -> rail/drawer state updates.
- Price comparison: `goTo(20)` -> `pc3Init()` -> `pc3RenderCards()` -> package click -> `pc3ToggleSelect(id)` -> basket and compare CTA refresh -> `pc3CompareBtn` opens `pc3CompareModal`.
- Upload/payment demo: upload or manual bill action -> local demo state update -> render portfolio/payment sections. Replace this with real API persistence later.

## Backend Integration Points

Use `js/app.js` as the integration boundary. Recommended future service functions:

- `fetchHospitalPackages(filters)` for `pc3` package data.
- `saveComparison(selection)` for portfolio comparison saves.
- `fetchAccountJourney(patientId)` for account sections and active coordination tasks.
- `uploadMedicalFile(file, categories)` for AI upload extraction and folder assignment.
- `fetchHealthTimeline(patientId)` for health score/year/hospital folders.
- `createAppointmentRequest(payload)` for the Home appointment flow.

Keep API responses normalized before rendering. Existing IDs/classes should remain stable so current CSS and event wiring keep working.

## Cleanup Notes

Removed as dead production code:

- Legacy `pricePackages`, `switchPriceState`, `renderPackageCards`, `renderComparison`, and related `priceCompare*` handlers.
- Legacy `.pc-*` Price Compare CSS blocks that belonged to the removed workflow.
- Inline Home CSS was moved from `index.html` to `css/styles.css` under `HOME SCREEN INLINE STYLE MIGRATION`.

Do not delete active `pc3*`, `ACCOUNT_JOURNEY`, `mhHome*`, `md*`, `acc3*`, or `screen-24` code without a fresh reference check.
